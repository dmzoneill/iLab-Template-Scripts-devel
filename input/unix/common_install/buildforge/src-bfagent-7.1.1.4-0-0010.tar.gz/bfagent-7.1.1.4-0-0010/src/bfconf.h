/*
Copyright (C)2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef BFCONF_H
#define BFCONF_H

void bfconf_refresh(void);
void bfconf_set_path(const char *path);
const char *bfconf_get_path(void);
int bfconf_get_errno(void);

int bfconf_dump(void);
char *bfconf_get(const char *key, const char *def);
int bfconf_exists(const char *key);

typedef struct {
	int activity_log:1;
	int cc_suppress_server_root:1;
	int cygwin:1;
	int disable_cleanup_during_exit:1;
	int disable_telnet_support:1;
	int disable_transcode:1;
	int enable_agent_dll:1;
	int enable_deprecated_path_mapping:1;
	int fail_if_dot_source_fails:1;
	int fail_if_log_file_fails:1;
	int getaddrinfo_use_addrconfig:1;
	int ignore_clearcase_view:1;
	int leave_tmp_file:1;
	int map_drive_is_failure:1;
	int nologonshell:1;
	int no_preparse_command:1;
	int no_pty:1;
	int shellarg:1;
	int shell_compatible_undef_vars:1;
	int win_reexec_after_auth:1;
	int password_encrypt_module:1;
	int password_encrypt_config:1;
} bfconf_data_t;

#ifndef BFCONF_C
extern bfconf_data_t bfconf_data;
#endif

#define BFCONF_EXISTS(x) (bfconf_data.x)

#endif /* BFCONF_H */

