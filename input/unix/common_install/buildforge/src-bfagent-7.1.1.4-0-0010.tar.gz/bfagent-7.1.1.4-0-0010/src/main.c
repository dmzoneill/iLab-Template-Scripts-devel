/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"
#include "md5.h"

#ifdef WIN32
#define GETOPT_OPTIONS "e:df:vI:P:RS:"
#else
#define GETOPT_OPTIONS "e:df:sxvI:P:"
#endif /* WIN32 */

#ifdef WIN32
extern SOCKET hRemote = (SOCKET)INVALID_HANDLE_VALUE;
extern int agent_re_exec;
extern int win_sock;
#endif
extern int ofd;
extern int ifd;

extern int optind;
extern char *optarg;

int bfagent(void);
void bfdaemon(int);

const char *AGENT_VERSION = AGENT_ID_VERSION;

static void report_version(void) {
#ifdef HAVE_SSL
	char *ssl_protocol = NULL;
#endif /* HAVE_SSL */
	printf("IBM Rational Build Forge Agent\n");
	if (*AGENT_VERSION == '_') {
		printf("Development Internal Build!\n");
	} else {
		char *ver = strdup(AGENT_VERSION);
		char *ifx = NULL;
		char *bld = NULL;
		int ifix = 0;

		if (NULL != (ifx = strchr(ver, '-'))) {
			*ifx++ = '\0';
			if (NULL != (bld = strchr(ifx, '-'))) {
				*bld++ = '\0';
				ifix = atoi(ifx);
			} else {
				bld = ifx;
			}
		}

		if (ifix > 0) {
			printf("%s iFix %03d", ver, ifix);
		} else {
			printf("%s GA", ver);
		}
		if (NULL != bld)
			printf(" (Build %s)", bld);
		printf("\n");
		free(ver);
	}
#ifdef WIN32
	printf("Platform: Win32\n");
#else /* !WIN32 */
	printf("Platform: Unix\n");
#endif /* WIN32/! */
#ifdef HAVE_SSL
	ssl_protocol = bfconf_get("ssl_version", "TLSv1"); 
	printf("SSL: %s\n", ssl_protocol);
#endif /* WIN32 */
}

static int report_smd5(const char *pass, size_t len) {
	int		ret;
	char	smd5[64];
	char	*p = strdup(pass);

#ifdef ZOS
	convert_etoa_l(p, len);
#endif /* ZOS */

	ret = smd5_create(smd5, (const md5_byte_t *)p, len);
	free(p);
	if (ret != 0) {
		printf("!!! %d\n", ret);
	} else {
		printf("%s\n", smd5);
	}
	return ret;
}


#ifdef WIN32
BOOL CtrlHandler(DWORD fdwCtrlType) {
	switch (fdwCtrlType) {
		case CTRL_C_EVENT:
			send_msg("EXEC", "WinEventCtrlC", NULL);
			return TRUE;
		case CTRL_CLOSE_EVENT:
			send_msg("EXEC", "WinEventClose", NULL);
			return TRUE;
		case CTRL_BREAK_EVENT:
			send_msg("EXEC", "WinEventBreak", NULL);
			return FALSE;
		case CTRL_SHUTDOWN_EVENT:
			send_msg("EXEC", "WinEventShutdown", NULL);
			return FALSE;
		case CTRL_LOGOFF_EVENT:
			send_msg("EXEC", "WinEventLogOff", NULL);
			return TRUE;
		default:
			return FALSE;
	} 
}
#endif /* WIN32 */

static int addr_match(const char *addr, size_t addrlen, const char *maybe)
{
	size_t maybelen = strlen(maybe);

	/* Address string isn't long enough, so it can't possibly match. */
	if (maybelen > addrlen) { return 0; }

	/* Did not match the template from allow list. */
	if (0 != memcmp(addr, maybe, maybelen)) { return 0; }

	/* If the match address ends with a separator, then this is
	 * definitely a match; the edge case check below is not needed.
	 */
	switch(maybe[maybelen - 1]) {
		case '.':
		case ':':
		case '%':
			return 1;
	}

	/* Edge case check: If the match address doesn't have a trailing
	 * separator, then accept any separator as the next char in the
	 * address.  This prevents the allow entry 10.10.10 from matching
	 * 10.10.100.1 and so forth.
	 */
	switch (addr[maybelen]) {
		case '\0':
		case '.':
		case ':':
		case '%':
			return 1;
	}

	/* Failed the edge case check */
	return 0;
}

int checkIP(const char *addr) {
	char *  allow;
	char ** list;
	int     i;
	int     allowed = 0;
	size_t  addrlen;

	allow = bfconf_get("allow", NULL);
	if (NULL == allow) { return 1; }
	list = getArgs(allow);
	free(allow);
	if (NULL == list) { return 1; }

	if (NULL == *list) {
		allowed = 1;
	} else if ('\0' != *addr) {
		addrlen = strlen(addr);
		for (i=0; NULL != list[i]; ++i) {
			if (addr_match(addr, addrlen, list[i])) {
				allowed = 1;
				break;
			}
		}
	}

	freeArgs(list);
	return allowed;
}



#ifndef WIN32
static int isBusy(const char *updFile, int hasExt) {
	int retval = 0;
	size_t len = strlen(updFile);
	char *bsyFile = malloc(len + 8);

	memcpy(bsyFile, updFile, len + 1);
	strcpy(&bsyFile[hasExt ? (len-4) : len], ".bsy");
	if (0 == access(bsyFile, 0)) { retval = 1; }
	free(bsyFile);
	return retval;
}
#endif /* !WIN32 */


int main(int argc, char **argv) {
	int i;
	char *ip = NULL;
	char *password = NULL;
#ifndef WIN32
	int bf_daemon = 0;
	char *binpath, *updpath, *oldpath;
	struct stat sb;
#else /* WIN32 */
	WORD	wVer;
	WSADATA wsaData;

    /* set the control handler to catch logoff events */

    /* there is a return code here, but we don't want to quit */
    /* if there is some problem registering.  Just accept and */
    /* move on.                                               */
    SetConsoleCtrlHandler( (PHANDLER_ROUTINE) CtrlHandler, TRUE ); 

	wVer = MAKEWORD(2,2);
	WSAStartup(wVer,&wsaData);
	platform_map_clear();
#endif /* WIN32 */

	/* parse args */
	bfconf_set_path(NULL);
	while ((i = getopt(argc,argv,GETOPT_OPTIONS)) != EOF) {
		if (agent_debug_flag) {
			printf("DEBUG: arg: -%c\n", i);
		}
		switch (i) {
			case 'e':
#ifdef ZOS
				convert_etoa(optarg);
#endif
				encrypt_pwd(optarg, &password);
				printf("%s\n", password);
				return 0;

			case 'I':
				ip = optarg;
				continue;

			case 'v':
				report_version();
				return 0;

			case 'd':
				if (!agent_debug_flag) {
					char *activity_log = bfconf_get("activity_log", NULL);
					printf("DEBUG: Writing to activity log [%s]\n",
							(NULL != activity_log) ? activity_log : "(stderr)");
					agent_debug_flag = 1;
					free(activity_log);
				}
				continue;

#ifdef WIN32
			/* Only used on Win32.  Provides the socket number to use for
			 * talking to the remote client.  This socket was inherited
			 * from the bfdispatch process that spawned us.  Not compatible
			 * with -R.
			 */
			case 'S':
				if (win_sock || agent_re_exec) { break; }
				win_sock = 1;
				hRemote = (SOCKET)atoi(optarg);
				SetHandleInformation((HANDLE)hRemote, HANDLE_FLAG_INHERIT, 0);
				continue;

			/* Only used on Win32.  Provides the handle number to use for
			 * talking to the bfagent process that spawned us.  It is a
			 * pipe that is inherited from that process.  Not compatible
			 * with -S.
			 */
			case 'R':
				if (win_sock || agent_re_exec) { break; }
				agent_re_exec = 1;
				continue;
#else
			case 's':
				bf_daemon = 1;
				continue;

			case 'x':
				bf_daemon = 2;
				continue;
#endif

			case 'f':
				bfconf_set_path(optarg);
				continue;

			case 'P': {
				size_t len = strlen(optarg) + 1;
				char *buf = malloc(len << 2);
				int rc;

				len = convert_native_to_utf8(optarg, len, buf, len << 2);
				rc = report_smd5(buf, len - 1);
				free(buf);
				return rc;
			}
		}

		send_hello(CODE_HELLO);
		send_msg("ERROR", "InitBadArg", NULL);
		send_result(1);
		send_goodbye();
		return 1;
	}

	if (ip != NULL && !checkIP(ip)) {
		send_hello(CODE_HELLO);
		send_msg("ERROR", "InitAccessDenied", NULL);
		send_result(1);
		send_goodbye();
		return 1;
	}

#ifndef WIN32
	/*============================================================
	 * Update logic for non-Windows agents.  Note that this code
	 * operates entirely in the native character set, so it does
	 * not need to use platform_xxx functions.
	 *============================================================*/
	/* if this agent is in update mode and the update binary exists, we need to activate it */
	if (NULL != (updpath = getenv("BF_AGENT_UPDATE"))
			&& access(updpath,0) == 0
			&& !isBusy(updpath,1))
	{
		if (agent_debug_flag) {
			printf("DEBUG: Agent is in update mode\n");
		}

		/* build the list of pathnames */
		binpath = strdup(updpath);
		oldpath = strdup(updpath);
		strcpy(&oldpath[strlen(oldpath)-3], "old");
		binpath[strlen(binpath)-4] = 0;

		/* get the original mode bits */
		stat(binpath, &sb);

		/* move the current agent to .old */
		unlink(oldpath);
		link(binpath, oldpath);

		/* move the update to the current agent, fix the perms. */
		/* make sure the owner has permission to execute */
		unlink(binpath);
		link(updpath, binpath);
		chmod(binpath, sb.st_mode|S_IXUSR);
		chown(binpath, sb.st_uid, sb.st_gid);

		/* clean up the update and fire up the real agent */
		unlink(updpath);
		execv(binpath, argv);
		return 0;
	}

	/* if the update binary exists, start it in update mode */
	if (NULL != (binpath = bfconf_get("update_path",NULL)))
	{
		char *path = malloc(MAX_PATH);
		convert_utf8_to_native(binpath, CONVERT_ALL, path, MAX_PATH);
		path[MAX_PATH - 1] = '\0';
		free(binpath);
		binpath = path;
		if (!isBusy(binpath, 0)) {
			int len = strlen(binpath);
			updpath = calloc(1, len + 5);
			memcpy(updpath, binpath, len);
			strcpy(&updpath[len], ".upd");
			if (access(updpath, 0) == 0) {
				if (agent_debug_flag) {
					printf("DEBUG: Spawning new agent in update mode\n");
				}
				setenv("BF_AGENT_UPDATE", updpath, 1);
				/* make sure we can execute it; it might just be a file sitting there */
				stat(updpath, &sb);
				chmod(updpath, sb.st_mode|S_IXUSR|S_IRUSR);
				chown(updpath, getuid(), getgid());
				execv(updpath, argv);
				unlink(updpath); /* if the exec fails, stop trying */
			}
			free(updpath);
		}
		free(binpath);
	}
#endif /* !WIN32 */

	activity_open();
#ifndef WIN32
	/* Unix agents can run with a -s option to operate as a daemon.  On
	 * Windows, bfdispatch has this job, instead.
	 */
	if (bf_daemon) {
		if (agent_debug_flag) {
			printf("DEBUG: Starting bfagent as a daemon process.\n");
		}
		BFTRACE("=== STARTING DAEMON PROCESS ===");
		bfdaemon(bf_daemon);
	}
	else
#endif /* !WIN32 */
	{
		if (agent_debug_flag) {
			printf("DEBUG: Running agent as a one-shot.\n");
		}
		BFTRACE("=== NEW AGENT ===");
		bfagent();
	}
	platform_unmap_drives(1);
	BFTRACE("--- EXITING ---");
	exit(0);
}

