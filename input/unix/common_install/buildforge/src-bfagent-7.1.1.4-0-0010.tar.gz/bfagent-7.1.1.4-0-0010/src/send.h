/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef SEND_H
#define SEND_H

/*
 *  result codes and messages 
 */
#define CODE_HELLO_MSG           "HELLO - BuildForge Agent v" AGENT_ID_VERSION
#define CODE_SECURE_HELLO_MSG    "HELLO TLS - BuildForge Agent v" AGENT_ID_VERSION
#define CODE_CERTIFIED_HELLO_MSG "HELLO TLS - BuildForge Agent v" AGENT_ID_VERSION
#define CODE_GOODBYE_MSG         "GOODBYE - BuildForge Agent v" AGENT_ID_VERSION



int send_cache_init(int size);
int send_cache_flush(void);
int send_checkpoint(const char *type, uint32_t crc32,
		long mtime, const uint8_t *md5, const char *path);
int send_cont(const char *msg);
int send_debug(const char *message);
int send_dir(int mode, long mtime, const char *path);
int send_file_data(const uint8_t *bytes, size_t len);
int send_file_info(off_t offset, long bytes, int mode,
		long size, long mtime, const char *path);
int send_goodbye(void);
int send_heartbeat(void);
int send_hello(int code);
int send_log(const char *bucket, const char *msg);
int send_missing(const char *cmd, const char *tag);
int send_msg(const char *bucket, const char *key, const char *fmt, ...);
int send_result(int rc);
int send_script(const char *dir, char *cmd, int verbose);



#endif /* SEND_H */

