/*
Copyright (C)2007-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef ENV_H
#define ENV_H

#define env_expand_var(src, ignore_escapes) \
   env_expand_var_impl(src, ignore_escapes, 0)
#define env_expand_hidden(src, ignore_escapes) \
   env_expand_var_impl(src, ignore_escapes, 1)

void env_clear(void);
char *env_expand_var_impl(const char *src, int ignore_escapes, int do_hidden_check);
const char *env_get_encrypted(const char *name);
int env_is_encrypted(const char *name);
int env_is_hidden(const char *name);
void env_report_locale(void);

#endif /* ENV_H */

