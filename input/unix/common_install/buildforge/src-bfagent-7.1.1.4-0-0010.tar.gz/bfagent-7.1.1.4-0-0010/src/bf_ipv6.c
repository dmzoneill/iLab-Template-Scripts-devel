/*
Copyright (C)2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

/****************************************************************
 * Initialization
 ****************************************************************/

#include "bf_agent.h"
#include <stdarg.h>

/*
 * To get extensive debugging information from the replacement functions in
 * this file, compile with DEBUG_BF_IPV6 defined.
 */

#undef D
#ifdef DEBUG_BF_IPV6
#  define D(x) x
# else
#  define D(x) /**/
#endif



/* Make sure we can get to h_errno */
#ifndef HAVE_H_ERRNO
extern int h_errno;
#endif /* HAVE_H_ERRNO */




/****************************************************************
 * inet_addr
 ****************************************************************/

#ifndef HAVE_INET_ADDR
in_addr_t bf_inet_addr(const char *cp) {
	struct in_addr ret;
	int ok = inet_aton(cp, &ret);
	D(activity_write(BFHERE "bf_inet_addr: [%s] ok=%d", cp, ok));
	return ok ? ret.s_addr : INADDR_NONE;
}
#endif /* !HAVE_INET_ADDR */



/****************************************************************
 * inet_aton
 ****************************************************************/

#ifndef HAVE_INET_ATON
int bf_inet_aton(const char *cp, struct in_addr *inp)
{
	const char *p = cp;
	static const char *DOTS = "...";
	uint32_t addr = 0;
	unsigned int x;
	int i;

	for (i=0; i<4; ++i) {
		if (!isdigit((int)*p)) {
			D(BFTRACE("bf_inet_aton: octet started with non-digit"));
			return 0;
		}
		x = 0;
		do {
			x = x*10 + *p++ - '0';
			if (x > 255) {
				D(BFTRACE("bf_inet_aton: octet exceeded 255"));
				return 0;
			}
		} while (isdigit((int)*p));
		if (*p++ != DOTS[i]) {
			D(BFTRACE("bf_inet_aton: bad octet termination"));
			return 0;
		}
		addr = (addr << 8) + x;
	}

	D(activity_write(BFHERE "bf_inet_aton: [%s] ok", cp));
	inp->s_addr = htonl(addr);
	return 1;
}
#endif /* !HAVE_INET_ATON */



/****************************************************************
 * inet_ntoa
 ****************************************************************/

#ifndef HAVE_INET_NTOA
char *bf_inet_ntoa(struct in_addr in)
{
	static char buf[16];
	uint32_t addr;

	addr = ntohl(in.s_addr);
	sprintf( buf, "%d.%d.%d.%d",
			(addr >> 24) & 0xFF,
			(addr >> 16) & 0xFF,
			(addr >> 8) & 0xFF,
			(addr) & 0xFF );
	D(activity_write(BFHERE "bf_inet_ntoa: -> [%s]", buf));
	return buf;
}

#else

/*
 * This exists to prevent us from getting warnings about this being
 * an empty source file on systems that already provide all of this
 * functionality.  The inet_ntoa function is the one that is least
 * likely to be missing.
 */
int bf_ipv6_dummy(void) { return 0; }

#endif /* !HAVE_INET_NTOA */



/****************************************************************
 * gai_strerror
 ****************************************************************/

#ifndef HAVE_GAI_STRERROR
#  undef XEAI
#  define XEAI(err) case err: return #err
/* This implementation just returns stringified versions of the error
 * symbol.
 */
const char *bf_gai_strerror(int err) {
	switch (err) {
		case 0: return "0";
		XEAI(EAI_ADDRFAMILY);
		XEAI(EAI_AGAIN);
		XEAI(EAI_BADFLAGS);
		XEAI(EAI_FAIL);
		XEAI(EAI_FAMILY);
		XEAI(EAI_MEMORY);
		XEAI(EAI_NODATA);
		XEAI(EAI_NONAME);
		XEAI(EAI_OVERFLOW);
		XEAI(EAI_SERVICE);
		XEAI(EAI_SOCKTYPE);
		XEAI(EAI_SYSTEM);
	}
	return "???";
}
#  undef XEAI
#endif /* !HAVE_GAI_STRERROR */



/****************************************************************
 * getnameinfo
 ****************************************************************/

#ifndef HAVE_GETNAMEINFO

/* host half of getnameinfo */
static int bf_gni_host(
		const struct in_addr *addr,
		char *host,
		size_t hostlen,
		int flags)
{
	struct hostent *he = NULL;
	const char *n;

	/* Unless they told us to give them the address as octets, try to find
	 * something better...
	 */
	if (! (flags & NI_NUMERICHOST)) {
		he = gethostbyaddr(addr, sizeof(struct in_addr), AF_INET);
	}

	if (NULL != he) {
		/* Got an actual hostname! */
		n = he->h_name;
	} else if (flags & NI_NAMEREQD) {
		/* Didn't find a hostname, and that's what the caller wants. */
		D(BFTRACE("bf_getnameinfo: host not found"));
		return EAI_NONAME;
	} else {
		/* Falling back on octets */
		n = inet_ntoa(*addr);
	}

	/* Make sure we have room, then save the result. */
	if (strlen(n) >= hostlen) {
		D(BFTRACE("bf_getnameinfo: host buffer overflow"));
		return EAI_OVERFLOW;
	}
	strcpy(host, n);

	/* Success! */
	D(activity_write(BFHERE "bf_getnameinfo: host -> [%s]", host));
	return 0;
}


/* service half of getnameinfo */
static int bf_gni_serv(in_port_t port, char *serv, size_t servlen, int flags)
{
	struct servent *se = NULL;
	const char *s;
	char sbuf[16];

	if (! (flags & NI_NUMERICSERV)) {
		se = getservbyport(port, (flags & NI_DGRAM) ? "udp" : "tcp");
	}

	if (NULL != se) {
		s = se->s_name;
	} else {
		sprintf(sbuf, "%d", ntohs(port));
		s = sbuf;
	}

	if (strlen(s) >= servlen) {
		D(BFTRACE("bf_getnameinfo: service buffer overflow"));
		return EAI_OVERFLOW;
	}
	strcpy(serv, s);
	D(activity_write(BFHERE "bf_getnameinfo: service -> [%s]", serv));
	return 0;
}


int bf_getnameinfo(
		const struct sockaddr *sa, socklen_t salen,
		char *host, size_t hostlen,
		char *serv, size_t servlen,
		int flags)
{
	const struct sockaddr_in *sin = (const struct sockaddr_in *)sa;
	const char *n, *s;
	char sbuf[8]; 
	int saved_errno = errno;
	int saved_h_errno = h_errno;
	int ret = 0;

	/* You have to request something... */
	if (NULL == host && NULL == serv) { return EAI_NONAME; }

	/* We only know how to handle sockets with AF_INET addresses, and
	 * the length of the sock address better match what we expect out
	 * of AF_INET, too.
	 */
	if (AF_INET != sin->sin_family) { return EAI_FAMILY; }
	if (sizeof(struct sockaddr_in) != salen) { return EAI_FAMILY; }

	/* Try to resolve the address first. */
	if (NULL != host) {
		ret = bf_gni_host(&sin->sin_addr, host, hostlen, flags);
	}

	/* If that was okay, then try to resolve the service.  If we
	 * can't, that's fine; we'll just use the port number.
	 */
	if (NULL != serv && 0 == ret) {
		ret = bf_gni_serv(sin->sin_port, serv, servlen, flags);
	}

	D(activity_write( BFHERE "bf_getnameinfo: ret=%d [%s]",
				ret, gai_strerror(ret) ));
	errno = saved_errno;
	h_errno = saved_h_errno;
	return ret;
}

#endif /* !HAVE_GETNAMEINFO */



/****************************************************************
 * getaddrinfo
 ****************************************************************/

#ifndef HAVE_GETADDRINFO

/* service half of getaddrinfo */
static int bf_gai_serv(
		const char *service,
		const struct bf_addrinfo *hints,
		in_port_t *port)
{
	const char *p = service;
	unsigned int x = 0;

	/* Try to interpret the service as a port number */
	while (isdigit((int)(*p))) {
		x = x*10 + *p++ - '0';
		if (x > 65535) {
			D(BFTRACE("bf_getaddrinfo: service exceeded 65535"));
			return EAI_SERVICE;
		}
	}

	if ('\0' == *p) {
		/* Valid port number. */
		*port = htons((uint16_t)x);
	} else if (hints->ai_flags & AI_NUMERICSERV) {
		/* Not a port number, but AI_NUMERICSERV was given. */
		D(activity_write( BFHERE
				"bf_getaddrinfo: AI_NUMERICSERV, but service=[%s]",
				service ));
		return EAI_NONAME;
	} else {
		/* Not a port number; try to look up service. */
		const char *proto = (hints->ai_socktype == SOCK_DGRAM) ? "udp" : "tcp";
		struct servent *se = getservbyname(service, proto);
		if (NULL == se) {
			/* No such service */
			D(activity_write( BFHERE
					"bf_getaddrinfo: service not found: [%s]",
					service ));
			return EAI_SERVICE;
		}
		*port = se->s_port;
	}

	D(activity_write(BFHERE
			"bf_getaddrinfo: service=[%d]",
			(int)ntohs(*port) ));
	return 0;
}


/* host half of getaddrinfo */
static int bf_gai_node(
		const char *node,
		in_port_t port,
		const struct bf_addrinfo *hints,
		struct bf_addrinfo **res)
{
	const char *cname = NULL;
	char *cname_copy = NULL;
	struct hostent *he;
	struct in_addr iaddr;
	struct in_addr *iaddr_ptr = &iaddr;
	struct in_addr **iaddrs = &iaddr_ptr;
	struct sockaddr_in *sa, *sa_head = NULL;
	struct bf_addrinfo *ai, *ai_head = NULL;
	size_t count = 1;
	int i;

	if (NULL == node) {
		/* No node name given.  Use 0.0.0.0 or 127.0.0.1 depending on whether
		 * the request indicated that it intends to use this for a passive
		 * connection or not.
		 */
		if (hints->ai_flags & AI_PASSIVE) {
			D(BFTRACE("bf_getaddrinfo: NULL + AI_PASSIVE -> INADDR_ANY"));
			iaddr.s_addr = htonl(INADDR_ANY);
		} else {
			D(BFTRACE("bf_getaddrinfo: NULL -> INADDR_LOOPBACK"));
			iaddr.s_addr = htonl(INADDR_LOOPBACK);
		}
	} else if (inet_aton(node, &iaddr)) {
		/* The node name was a valid IPv4 address.  Try to find its CNAME, if
		 * the caller requested it.
		 */
		D(activity_write( BFHERE
				"bf_getaddrinfo: resolved as octets: node=[%s]",
				node ));
		if ( hints->ai_flags & AI_CANONNAME &&
				!(hints->ai_flags & AI_NUMERICHOST) )
		{
			he = gethostbyaddr(&iaddr, sizeof(iaddr), AF_INET);
			cname = (NULL != he) ? he->h_name : node;
			D(activity_write(BFHERE "bf_getaddrinfo: cname -> [%s]", cname));
		}
	} else if (hints->ai_flags & AI_NUMERICHOST) {
		/* The node name was given; it is not a valid IPv4 address; but
		 * the caller hinted that it was.
		 */
		D(activity_write(BFHERE
					"bf_getaddrinfo: AI_NUMERICHOST, but node=[%s]",
					node));
		return EAI_NONAME;
	} else {
		/* Do a host lookup on the node name and use the address list
		 * that gets returned.  Also grab the CNAME, if one was requested.
		 */
		h_errno = 0;
		he = gethostbyname(node);
		if (NULL == he) {
			/* Host lookup failed. */
			D(BFTRACE("bf_getaddrinfo: host lookup failed"));
			switch (h_errno) {
				case HOST_NOT_FOUND:
					return EAI_NONAME;
#ifdef NO_ADDRESS
#  if NO_ADDRESS != NO_DATA
				case NO_ADDRESS:
#  endif /* NO_ADDRESS != NO_DATA */
#endif /* NO_ADDRESS */
				case NO_DATA:
					return EAI_NODATA;
				case TRY_AGAIN:
					return EAI_AGAIN;
				default:
					return EAI_FAIL;
			}
		}

		/* Make sure it really did give us a valid result, and note
		 * the CNAME if there is one.
		 */
		iaddrs = (struct in_addr **)he->h_addr_list;
		if (NULL == he->h_addr_list[0]) {
			/* PARANOID */
			D(BFTRACE("bf_getaddrinfo: gethostbyname returned empty list"));
			return EAI_NODATA;
		}
		while (NULL != he->h_addr_list[count]) { ++count; }
		if (hints->ai_flags & AI_CANONNAME) { cname = he->h_name; }
		D(activity_write( BFHERE
				"bf_getaddrinfo: count=%d, cname=[%s]",
				(int)count,
				(NULL != cname) ? cname : "NULL" ));
	}

	/* At this point, we have
	 * - iaddrs:  array of (struct in_addr *) items
	 * - count :  number of entries in iaddrs
	 * - cname :  the canonical name, or NULL
	 *
	 * To reduce the work for alloc, we grab the memory for all items of
	 * the same type at once.  That is, we allocate a single array and
	 * link together the elements of that array as opposed to building
	 * a linked list of individually allocated items.
	 */
	ai_head = calloc(count, sizeof(struct addrinfo));
	if (NULL == ai_head) { return EAI_MEMORY; }
	sa_head = calloc(count, sizeof(struct sockaddr_in));
	if (NULL == sa_head) {
		free(ai_head);
		return EAI_MEMORY;
	}
	if (NULL != cname) {
		cname_copy = strdup(cname);
		if (NULL == cname_copy) {
			free(ai_head);
			free(sa_head);
			return EAI_MEMORY;
		}
	}

	/* Now that we've successfully allocated all the memory that we need,
	 * populate the values to return to the caller.
	 */
	ai = ai_head;
	sa = sa_head;
	for (i=0; i<count; ++i, ++ai, ++sa) {
		ai->ai_family = PF_INET;
		ai->ai_socktype = hints->ai_socktype;
		ai->ai_protocol = hints->ai_protocol;
		ai->ai_addr = (struct sockaddr *)sa;
		ai->ai_addrlen = sizeof(struct sockaddr_in);
		ai->ai_next = &ai[1];

		sa->sin_family = AF_INET;
		sa->sin_port = port;
		memcpy(&sa->sin_addr, iaddrs[i], sizeof(struct in_addr));
	}

	/* Special case for the first entry */
	ai_head[0].ai_canonname = cname_copy;

	/* Special case for the last entry */
	ai_head[count-1].ai_next = NULL;

	/* Success! */
	*res = ai_head;
	return 0;
}

/* The settings we use if NULL is passed as getaddrinfo's hints param. */
const struct bf_addrinfo DEFAULT_HINTS = {
	0,          /* ai_flags */
	PF_UNSPEC,  /* ai_family */
	0,          /* ai_socktype */
	0,          /* ai_protocol */
	0,          /* ai_addrlen */
	NULL,       /* ai_addr */
	NULL,       /* ai_canonname */
	NULL        /* ai_next */
};

int bf_getaddrinfo(
		const char *node,
		const char *service,
		const struct bf_addrinfo *hints,
		struct bf_addrinfo **res)
{
	int saved_errno = errno;
	int saved_h_errno = h_errno;
	int ret = 0;
	struct sockaddr_in sa;
	in_port_t port;

	/* Treat empty strings the same way we treat NULL */
	if (NULL != node && '\0' == *node) { node = NULL; }
	if (NULL != service && '\0' == *service) { service = NULL; }

	/* The caller needs to actually ask for something... */
	if (NULL == node && NULL == service) {
		D(BFTRACE("bf_getaddrinfo: node and service were both empty/NULL"));
		return EAI_NONAME;
	}

	/* Make sure the hints are sane. */
	if (NULL != hints) {
		/* Since we're providing glue to IPv4 calls, only INET and UNSPEC
		 * can be provided.
		 */
		if (PF_INET != hints->ai_family && PF_UNSPEC != hints->ai_family) {
			return EAI_FAMILY;
		}

		/* Socket type has to be stream (TCP), datagram (UDP), or unspecified
		 * (for which we'll try TCP).
		 */
		switch (hints->ai_socktype) {
			case 0:
			case SOCK_STREAM:
			case SOCK_DGRAM:
				break;
			default:
				D(BFTRACE("bf_getaddrinfo: unsupported socket type"));
				return EAI_SOCKTYPE;
		}
	} else {
		D(BFTRACE("bf_getaddrinfo: using default hints"));
		hints = &DEFAULT_HINTS;
	}

	/* Resolve the service port number */
	port = htons(0);
	if (NULL != service) {
		ret = bf_gai_serv(service, hints, &port);
	}

	/* Resolve the socket address.  NULL is ok. */
	if (0 == ret) {
		ret = bf_gai_node(node, port, hints, res);
	}

	D(activity_write( BFHERE "bf_getaddrinfo: ret=%d [%s]",
				ret, gai_strerror(ret) ));
	errno = saved_errno;
	h_errno = saved_h_errno;
	return ret;
}


void bf_freeaddrinfo(struct bf_addrinfo *res) {
	if (NULL != res) {
		if (NULL != res->ai_canonname) { free(res->ai_canonname); }
		free(res->ai_addr);
		free(res);
	}
}

#endif /* HAVE_GETADDRINFO */
