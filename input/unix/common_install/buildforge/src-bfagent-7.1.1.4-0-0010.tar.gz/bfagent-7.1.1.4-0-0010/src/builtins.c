/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#define BF_USE_REGEX
#include "bf_agent.h"

bf_internal_t internals[] = {
	{ ".strsub",    &builtinStrsub,     0 },
	{ ".edit",      &builtinEdit,       0 },
	{ ".mkdir",     &builtinMkdir,      0 },
	{ ".rmdir",     &builtinRmdir,      0 },
	{ ".require",   &builtinRequire,    0 },
	{ ".monitor",   &builtinMonitor,    0 },
	{ ".alive",     &builtinAlive,      0 },
	{ NULL, NULL, 0 }
};

int builtinMkdir(
		char *          paths,
		int             timeout,
		int *           timed_out,
		const char *    flags )
{
	char	**pathlist;
	int 	i, len;
	int		ret = 0;
	char    *buf = malloc(BFBUFSIZ);
	char    *root = malloc(MAX_PATH);

	BFTRACE("FUNC .mkdir");
	pathlist = getArgs(paths);
	platform_getcwd(root, MAX_PATH);

	for (i=0; pathlist && pathlist[i]; ++i) {
		CleanUnixPath(pathlist[i]);
		len = strlen(root);
		memcpy(buf, root, len);
		buf[len++] = '/';
		strcpy(&buf[len], pathlist[i]);
		CleanUnixPath(buf);
		if (isDir(buf)) {
			CleanPath(buf);
			send_msg("MKDIR", "MkdirExists", "s", buf);
			continue;
		}
		CleanPath(buf);
		if (BFCreateDirectoryRelative(pathlist[i], 0) != 0) {
			send_msg("MKDIR", "MkdirFail", "s", buf);
			ret = 0;
			break;
		}
		send_msg("MKDIR", "MkdirOk", "s", buf);
	}

	freeArgs(pathlist);
	free(root);
	free(buf);

	/* Timing out is not implemented for a .mkdir ... */
	if (NULL != timed_out) { *timed_out = timeout * 0; }
	return ret;
}

int builtinRmdir(
		char *          paths,
		int             timeout,
		int *           timed_out,
		const char *    flags )
{
	char	*dir, **pathlist;
	int 	i, len, ret = 0;
	char	*buf = malloc(BFBUFSIZ);
	char    *root = malloc(MAX_PATH);
	const char *reason = NULL;

	BFTRACE("FUNC .rmdir");
	pathlist = getArgs(paths);
	platform_getcwd(root, MAX_PATH);

	for (i = 0 ; pathlist && pathlist[i] ; i++) {
		dir = pathlist[i];
		len = strlen(root);
		memcpy(buf, root, len);
		buf[len++] = '/';
		strcpy(&buf[len], dir);
		CleanPath(buf);

		if (0 != platform_access(buf, 0)) {
			switch (errno) {
				case EACCES:  reason = "RmdirNoAccess";     break;
				case ENOENT:  reason = "RmdirNotFound";     break;
				case ENOTDIR: reason = "RmdirNotDir";       break;
				default:      reason = "RmdirSystemError";  break;
			}
			send_msg("RMDIR", reason, "s", buf);
			ret = 1;
		} else {
			BFRemoveDirectory(buf);
			if (0 == platform_access(buf, 0)) {
				send_msg("RMDIR", "RmdirFail", "s", buf);
				ret = 1;
				break;
			}
			send_msg("RMDIR", "RmdirOk", "s", buf);
		}
	}

	freeArgs(pathlist);
	free(root);
	free(buf);

	/* Timing out is not implemented for a .rmdir ... */
	if (NULL != timed_out) { *timed_out = timeout * 0; }
	return ret;
}

static int require_disk(char *req)
{
	char *path = &req[4]; /* disk**** */
	char *p;
	platform_sysconf_disk_t *disk;
	int rc = 0;
	long have;
	long need;

	if (*path == '(') {
		/* disk(/path/name)=**** */
		path++;
		if (NULL == ( p = strchr(path, ')') )) {
			send_msg("ERROR", "RequireDiskMalformed", "s", req);
			return 3;
		}
		*p++ = 0;
		if (NULL != ( p = strchr(p, '=') )) { *p++ = 0; }
		need = atol(p);
	} else {
		/* disk=**** */
		need = atol(++path);
		path = ".";
	}

	if (NULL == ( disk = platform_sysconf_disk_new(path) )) {
		send_msg("WARNING", "RequireDiskUnsupp", NULL);
		return 0;
	}
	have = (long)(disk->disk_free / DISK_REPORT_SIZE);
	platform_sysconf_disk_destroy(disk);

	if (have < 0) {
		rc = 2;
		send_msg("ERROR", "RequireDiskBadPath", "s", path);
	} else if (have < need) {
		rc = 1;
		send_msg("ERROR", "RequireDiskInsuff", "sii", path, have, need);
	} else {
		send_msg("EXEC", "RequireDiskOk", "sii", path, have, need);
	}

	return rc;
}

static int require_mem(const char *req)
{
	platform_sysconf_mem_t *mem;
	int rc = 0;
	long need = atol(&req[4]); /* mem=**** */
	long have;

	if (NULL == ( mem = platform_sysconf_mem_new() )) {
		send_msg("WARNING", "RequireMemUnsupp", NULL);
		return 0;
	}
	have = (long)(mem->mem_total / MEM_REPORT_SIZE);
	platform_sysconf_mem_destroy(mem);

	if (have < need) {
		rc = 1;
		send_msg("ERROR", "RequireMemInsuff", "ii", have, need);
	} else {
		send_msg("EXEC", "RequireMemOk", "ii", have, need);
	}
	return rc;
}

int builtinRequire(
		char *          cl,
		int             timeout,
		int *           timed_out,
		const char *    flags )
{
	char ** argv;
	int     argc;
	int     result;
	int     negate;

	BFTRACE("FUNC .require");
	result = 0;
	negate = 0;
	argv = getArgs(cl);
	for (argc=0; argv && argv[argc]; ++argc) {
		if (strncmp(argv[argc], "-n", 2) == 0) {
			negate = 1;
			send_msg("EXEC", "RequireNeg", NULL);
			continue;
		}

		if (strncmp(argv[argc], "disk", 4) == 0) {
			int rc = require_disk(argv[argc]);
			if (0 != rc) { result = rc; }
			continue;
		}
		
		if (strncmp(argv[argc], "mem=", 4) == 0) {
			int rc = require_mem(argv[argc]);
			if (0 != rc) { result = rc; }
			continue;
		}

		send_msg("ERROR", "RequireMalformed", "s", argv[argc]);
		freeArgs(argv);
		return -1;
	}

	freeArgs(argv);

	/* Timing out is not implemented for a .require ... */
	if (NULL != timed_out) { *timed_out = timeout * 0; }
	return negate ? !result : result;
}

int builtinMonitor(
		char *          cl,
		int             timeout,
		int *           timed_out,
		const char *    flags )
{
	char	**argv, *path;
	int 	argc, delay, waitforit, docat;
	struct stat sb;
	size_t	lastsize;
	time_t	now, expires;
	FILE	*f;

	BFTRACE("FUNC .monitor");
	argv = getArgs(cl);
	waitforit = docat = 0;
	for (argc = 0 ; argv && argv[argc] ; argc++) {
		if (strcmp(argv[argc], "-w") == 0) {
			waitforit = 1;
			free(shiftArgs(argv));
			argc--;
		}
		else if (strcmp(argv[argc], "-c") == 0) {
			docat = 1;
			free(shiftArgs(argv));
			argc--;
		}
	}

	if (argc < 2) {
		send_msg("MON", "MonitorUsage", NULL);
		freeArgs(argv);
		return -1;
	}
	delay = atoi(argv[0]);
	path = argv[1];

	if (delay < 1) {
		send_msg("MON", "MonitorUsage", NULL);
		freeArgs(argv);
		return -1;
	}

	if (waitforit) {
		time(&now);
		expires = now + timeout;
		send_msg("MON", "MonitorWaiting", "s", path);

		while (0 != platform_stat(path, &sb)) {
			time(&now);
			if (timeout && now > expires) {
				if (NULL != timed_out) { *timed_out = timeout; }
				send_msg("MON", "MonitorTimeout", "s", path);
				freeArgs(argv);
				return -1;
			}
			platform_sleep(delay);
		}
	}

	lastsize = (size_t)-1;
	if (0 != platform_stat(path, &sb)) {
		send_msg("MON", "MonitorStatFail", "s", path);
		freeArgs(argv);
		return -1;
	}

	while ((unsigned long)lastsize != (unsigned long)sb.st_size) {
		lastsize = sb.st_size;
		send_msg("MON", "MonitorSizeOk", "sl",
				path, (long)lastsize);
		platform_sleep(delay);
		platform_stat(path, &sb);
	}
	send_msg("MON", "MonitorStopped", "sl",
			path, (long)lastsize, delay);

	if (docat) {
		f = platform_fopen(path, "r");
		if (f != NULL) {
			char *msg = malloc(BFBUFSIZ);
			while (NULL != platform_fgets(msg, BFBUFSIZ, f)) {
				RemoveNewline(msg);
				send_log("MON", msg);
			}
			fclose(f);
			free(msg);
		}
	}

	freeArgs(argv);

	/* Timing out is not implemented for a .monitor ... */
	if (NULL != timed_out) { *timed_out = timeout * 0; }
	return 0;
}

typedef enum {
	ACR_OK,
	ACR_BADHOST,
	ACR_NOSOCKET,
	ACR_FAILED
} attempt_connect_result_t;

static attempt_connect_result_t attempt_connect(
		struct addrinfo *ai_head,
		int poll_timeout)
{
	struct addrinfo *ai;
	attempt_connect_result_t result = ACR_BADHOST;
	int rc;

	if (poll_timeout < 0) { poll_timeout = 0; }

	for (ai=ai_head; NULL != ai; ai=ai->ai_next) {
		int sock = socket(ai->ai_family, ai->ai_socktype, ai->ai_protocol);
		if (sock == -1) {
			result = ACR_NOSOCKET;
		} else {
			platform_alarm(poll_timeout);
			rc = connect(sock, ai->ai_addr, ai->ai_addrlen);
			platform_alarm(0);
			platform_closesocket(sock);
			if (0 == rc) {
				result = ACR_OK;
				break;
			}
			result = ACR_FAILED;
		}
	}
	return result;
}

/*
 * Poll a remote location for connections.
 */
static int polling_connect(
		const char *target_hostname,
		const char *target_port,
		int poll_timeout,
		int master_timeout)
{
	attempt_connect_result_t result = ACR_FAILED;
	time_t  deadline = time(NULL) + master_timeout;
	int     rc = 0;
	int     count = 0;
	struct  addrinfo hints;
	struct  addrinfo *ai;

	/* resolve hostname and port */
	memset(&hints, 0, sizeof(hints));
	if (BFCONF_EXISTS(getaddrinfo_use_addrconfig)) {
		hints.ai_flags = AI_ADDRCONFIG;
	}
	hints.ai_socktype = SOCK_STREAM;
	if (0 != getaddrinfo(target_hostname, target_port, &hints, &ai)) {
		send_msg("ERROR", "AliveBadHost", "s", target_hostname);
		return 1;
	}

	platform_signals_catch("bfagent");
	while (time(NULL) <= deadline) {
		send_msg("EXEC", "AliveAttempt", "sii",
				target_hostname, target_port, ++count);
		result = attempt_connect(ai, poll_timeout);
		if (ACR_OK == result) { break; }
		platform_sleep(poll_timeout);
	}
	freeaddrinfo(ai);

	switch (result) {
		case ACR_OK:
			rc = 0;
			send_msg("EXEC", "AliveOk", "si",
					target_hostname, target_port);
			break;
		case ACR_BADHOST:
			rc = 1;
			send_msg("ERROR", "AliveBadHost", "s", target_hostname);
			break;
		case ACR_NOSOCKET:
			rc = 2;
			send_msg("ERROR", "AliveNoSocket", "i", errno);
			break;
		default:
			rc = 3;
			send_msg("ERROR", "AliveFailed", "si",
					target_hostname, target_port);
			break;
	}
	platform_signals_release();
	return rc;
}

int builtinAlive(
		char *          cl,
		int             master_timeout,
		int *           timed_out,
		const char *    flags )
{
	char ** argv;
	char *  target_hostname;
	char *  target_port;
	int 	rc = 1;
	int     poll_timeout = 0;

	BFTRACE("FUNC .alive");

	/* Parse command line args */
	argv = getArgs(cl);

	/* set the overall timeout to default 5m or the passed in value.
	 * unlike most steps, the user is not permitted to specify an
	 * infinite timeout value for .alive commands, because then there
	 * would be no way for .alive to ever fail.  It would either
	 * connect successfully or never return.  It's important to know
	 * when to give up.
	 */
	if (master_timeout == 0) { master_timeout = 300; }
	*timed_out = 0;

	/* parse/set the args: hostname port poll_timeout */
	if (!argv || !*argv) { goto done; }
	target_hostname = *argv++;
	if (!*argv || '\0' == target_hostname) { goto done; }
	target_port = *argv++;
	if (!*argv || '\0' == target_port) { goto done; }
	poll_timeout = atoi(*argv);
	if (poll_timeout <= 0) { goto done; }

	rc = polling_connect(target_hostname, target_port,
			poll_timeout, master_timeout);

done:
	if (rc == 1) {
		send_msg("ERROR", "AliveUsage", NULL);
	}
	freeArgs(argv);
	if (NULL != timed_out) { *timed_out = rc; }
	return rc;
}


/*
 * args:  /srch/repl/ pathname
 *
 */
int builtinEdit(
		char *          arg,
		int             timeout,
		int *           timed_out,
		const char *    flags )
{
	FILE *inf = NULL;
	FILE *outf = NULL;
	bf_regex_t *srch;
	char *path = NULL;
	char *tmpname = NULL;
	char *spat = NULL;
	char *repl = NULL;
	char *target = NULL;
	char **args = NULL;
	char *out_utf8 = NULL;
	char *cl = NULL;
	char *in_native = NULL;
	char *in_utf8, *out_native;
	int i, lines, changes, ret=0;
	int transcode = platform_utf8_is_native() ? 0 : 1;
	char *transcode_in = NULL;
	char *transcode_out = NULL;
	char *regex_buf = NULL;

	BFTRACE("FUNC .edit");
	cl = strdup(arg);

	in_native = calloc(1, BFBUFSIZ);
	if (transcode) {
		transcode_in = calloc(1, BFBUFSIZ);
		transcode_out = calloc(1, BFBUFSIZ);
	}
	srch = NULL;
	repl = target = spat = NULL;

	if (0 != bf_regex_prep(&srch, &spat, &repl, &target, cl)) {
		send_msg("EDIT", "EditSyntax", "ks", target, arg);
		ret = -1;
		goto done;
	}

	args = getArgs(target);
	if (NULL == args || NULL == args[0]) {
		send_msg("EDIT", "EditSyntax", "ks", "EditNoFiles", arg);
		ret = -1;
		goto done;
	}

	regex_buf = malloc(strlen(spat) + strlen(repl) + 3);
	format_message(regex_buf, "%s%c%s%c", spat, *spat, repl, *spat);

	for (i=0; NULL != args[i]; ++i) {
		path = args[i];
		CleanPath(path);
		send_msg("EDIT", "EditApply", "ss", regex_buf, path);

		inf = platform_fopen(path, "rb");
		if (NULL == inf) {
			send_msg("EDIT", "ReplReadFailOrig", "is", errno, path);
			ret = 2;
			goto done;
		}
	
		/* make a tmp file copy */
		tmpname = platform_tempnam();
		outf = platform_fopen(tmpname, "wb");
		if (NULL == outf) {
			send_msg("EDIT", "ReplWriteFailTemp", "is", errno, path);
			ret = 3;
			goto done;
		}
	
		/* copy the contents */
		errno = 0;
		while (NULL != fgets(in_native, BFBUFSIZ, inf)) {
			if (fputs(in_native, outf) == EOF) {
				send_msg("EDIT", "ReplWriteFailTemp", "is", errno, tmpname);
				ret = 4;
				goto done;
			}
		}
		if (!feof(inf) && errno) {
			send_msg("EDIT", "ReplWriteFailTemp", "is", errno, tmpname);
			ret = 5;
			goto done;
		}
	
		/* close the handles */
		fclose(inf);
		fclose(outf);
		inf = outf = NULL;
	
		/* now do the replacement */
		inf = platform_fopen(tmpname, "rb");
		if (NULL == inf) {
			send_msg("EDIT", "ReplReadFailTemp", "is", errno, tmpname);
			ret = 6;
			goto done;
		}

		outf = platform_fopen(path, "wb");
		if (NULL == outf) {
			send_msg("EDIT", "ReplWriteFailOrig", "iss",
					errno, path, tmpname);
			ret = 7;
			goto done;
		}
	
		/* copy the contents, doing substitution */
		errno = 0;
		lines = changes = 0;
		while (NULL != fgets(in_native, BFBUFSIZ >> 1, inf)) {
			++lines;

			/* Save a copy of the original line */
			if (transcode) {
				convert_native_to_utf8(in_native, CONVERT_ALL, transcode_in, BFBUFSIZ);
				transcode_in[BFBUFSIZ-1] = '\0';
				in_utf8 = transcode_in;
			} else {
				in_utf8 = in_native;
			}

			/* Get result of substitution and report any changes */
			out_utf8 = bf_regex_apply(in_utf8, srch, repl);
			if (NULL != out_utf8) {
				++changes;
				if (transcode) {
					convert_utf8_to_native(out_utf8, CONVERT_ALL, transcode_out, BFBUFSIZ);
					out_native = transcode_out;
				} else {
					out_native = out_utf8;
				}
			} else {
				out_native = in_native;
			}

			/* Write (possibly) modified line */
			if (fputs(out_native, outf) == EOF) {
				send_msg("EDIT", "ReplWriteFailOrig", "iss",
						errno, path, tmpname);
				ret = 8;
				goto done;
			}

			if (NULL != out_utf8) {
				RemoveNewline(in_utf8);
				RemoveNewline(out_utf8);
				send_msg("EDIT", "ReplBefore", "is", lines, in_utf8);
				send_msg("EDIT", "ReplAfter", "s", out_utf8);
				free(out_utf8);
				out_utf8 = NULL;
			}
		}

		if (!feof(inf) && errno) {
			send_msg("EDIT", "ReplReadFailTemp", "is", errno, tmpname);
			ret = 9;
			goto done;
		}

		send_msg("EDIT", "ReplDone", "ii", lines, changes);
	}

	/* clean up! */
done:
	if (NULL != inf) { fclose(inf); }
	if (NULL != outf) { fclose(outf); }
	if (NULL != tmpname) {
		platform_unlink(tmpname);
		free(tmpname);
	}
	if (NULL != in_native) { free(in_native); }
	/* in_utf8 is either in_native or transcode_in */
	/* out_native is either out_utf8 or transcode_out */
	if (NULL != out_utf8) { free(out_utf8); }
	if (NULL != transcode_in) { free(transcode_in); }
	if (NULL != transcode_out) { free(transcode_out); }
	if (NULL != regex_buf) { free(regex_buf); }
	if (NULL != args) { freeArgs(args); }
	if (NULL != srch) { bf_regex_free(srch); }
	if (NULL != spat) { free(spat); }
	if (NULL != repl) { free(repl); }
	if (NULL != target) { free(target); }
	if (NULL != cl) { free(cl); }

	/* Timing out is not implemented for a .edit ... */
	if (NULL != timed_out) { *timed_out = timeout * 0; }
	return ret;
}


/*
 * args: search replace pathname
 * this was the original .strsub routine from 3.1 agents.
 *
 */
#define BF_STRSUB_BLOCK_SIZE (BFBUFSIZ >> 1)
int builtinStrsub(
		char *          arg,
		int             timeout,
		int *           timed_out,
		const char *    flags )
{
	FILE *  inf             = NULL;
	FILE *  outf            = NULL;
	char *  tmpname         = NULL;
	char *  in_utf8         = NULL;
	char *  out_utf8        = NULL;
	char *  in_native       = NULL;
	char *  out_native      = NULL;
	char *  srch            = NULL;
	char *  repl            = NULL;
	char *  path            = NULL;
	char ** args            = NULL;
	char *  p;
	char *  q;
	char *  s;
	int     transcode       = platform_utf8_is_native() ? 0 : 1;
	char *  transcode_in    = NULL;
	char *  transcode_out   = NULL;
	int     i;
	int     lines;
	int     changes;
	int     ret             = 0;
	size_t  srchlen;
	size_t  repllen;

	BFTRACE("FUNC .strsub");

	args = (NULL != strchr(flags, 'x')) ? getArgsI(arg) : getArgs(arg);
	if ( NULL == arg ||
			NULL == args ||
			NULL == args[0] ||
			NULL == args[1] ||
			NULL == args[2] )
	{
		send_msg("STRSUB", "StrsubUsage", NULL);
		ret = 1;
		goto done;
	}

	srch = args[0];  srchlen = strlen(srch);
	repl = args[1];  repllen = strlen(repl);

	tmpname = platform_tempnam();
	in_native = calloc(1, BF_STRSUB_BLOCK_SIZE);
	out_utf8 = calloc(1, BF_STRSUB_BLOCK_SIZE);
	if (transcode) {
		transcode_in = calloc(1, BF_STRSUB_BLOCK_SIZE);
		transcode_out = calloc(1, BF_STRSUB_BLOCK_SIZE);
	}

	for (i=2; NULL != args[i]; ++i) {
		path = args[i];
		CleanPath(path);

		/* open the original file */
		inf = platform_fopen(path, "rb");
		if (NULL == inf) {
			send_msg("STRSUB", "ReplReadFailOrig", "is", errno, path);
			ret = 2;
			goto done;
		}
	
		/* make a tmp file copy */
		outf = platform_fopen(tmpname, "wb");
		if (NULL == outf) {
			send_msg("STRSUB", "ReplWriteFailTemp", "is", errno, tmpname);
			ret = 3;
			goto done;
		}
	
		/* copy the contents */
		errno = 0;
		while (NULL != fgets(in_native, BF_STRSUB_BLOCK_SIZE, inf)) {
			if (fputs(in_native, outf) == EOF) {
				send_msg("STRSUB", "ReplWriteFailTemp", "is",
						errno, tmpname);
				ret = 4;
				goto done;
			}
		}
		if (!feof(inf) && errno) {
			send_msg("STRSUB", "ReplWriteFailTemp", "is", errno, path);
			ret = 5;
			goto done;
		}
	
		/* close the handles */
		fclose(inf);
		fclose(outf);
		inf = outf = NULL;
	
		/* now do the replacement */
		inf = platform_fopen(tmpname, "rb");
		if (NULL == inf) {
			send_msg("STRSUB", "ReplReadFailTemp", "is", errno, tmpname);
			ret = 6;
			goto done;
		}

		outf = platform_fopen(path, "wb");
		if (NULL == outf) {
			send_msg("STRSUB", "ReplWriteFailOrig", "iss",
					errno, path, tmpname);
			ret = 7;
			goto done;
		}
	
		/* copy the contents, doing substitution */
		errno = 0;
		send_msg("STRSUB", "StrsubApply", "sss",
				srch, repl, path);

		lines = changes = 0;
		while (NULL != fgets(in_native, BF_STRSUB_BLOCK_SIZE, inf)) {
			++lines;
			if (transcode) {
				convert_native_to_utf8(in_native, CONVERT_ALL, transcode_in, BF_STRSUB_BLOCK_SIZE);
				transcode_in[BF_STRSUB_BLOCK_SIZE-1] = '\0';
				in_utf8 = transcode_in;
			} else {
				in_utf8 = in_native;
			}

			s = in_utf8;
			q = out_utf8;
			while ('\0' != *s) {
				p = strstr(s, srch);
				if (NULL == p) {
					strcpy(q, s);
					break;
				}
				if (p > s) {
					int len = p - s;
					memcpy(q, s, len);
					s += len;
					q += len;
				}
				memcpy(q, repl, repllen);
				s += srchlen;
				q += repllen;
				++changes;
				*q = '\0';
			}

			if (0 != strcmp(in_utf8, out_utf8)) {
				send_msg("STRSUB", "ReplBefore", "is",
						lines, in_utf8);
				send_msg("STRSUB", "ReplAfter", "s", out_utf8);
				if (transcode) {
					convert_utf8_to_native(out_utf8, CONVERT_ALL, transcode_out, BF_STRSUB_BLOCK_SIZE);
					out_native = transcode_out;
				} else {
					out_native = out_utf8;
				}
			} else {
				out_native = in_native;
			}

			if (fputs(out_native, outf) == EOF) {
				send_msg("STRSUB", "ReplWriteFailOrig", "iss",
						errno, path, tmpname);
				ret = 8;
				goto done;
			}
		}

		if (!feof(inf) && errno) {
			send_msg("STRSUB", "ReplReadFailTemp", "is", errno, tmpname);
			ret = 9;
			goto done;
		}

		fclose(inf);
		fclose(outf);
		inf = outf = NULL;
		send_msg("STRSUB", "ReplDone", "ii", lines, changes);
	}

	/* clean up! */
done:
	if (NULL != inf) { fclose(inf); }
	if (NULL != outf) { fclose(outf); }
	if (NULL != tmpname) {
		platform_unlink(tmpname);
		free(tmpname);
	}
	
	if (NULL != in_native) { free(in_native); }
	/* in_utf8 is either in_native or transcode_in */
	/* out_native is either out_utf8 or transcode_out */
	if (NULL != out_utf8) { free(out_utf8); }
	if (NULL != transcode_in) { free(transcode_in); }
	if (NULL != transcode_out) { free(transcode_out); }
	if (NULL != args) { freeArgs(args); }

	/* Timing out is not implemented for a .strsub ... */
	if (NULL != timed_out) { *timed_out = timeout * 0; }
	return ret;
}


