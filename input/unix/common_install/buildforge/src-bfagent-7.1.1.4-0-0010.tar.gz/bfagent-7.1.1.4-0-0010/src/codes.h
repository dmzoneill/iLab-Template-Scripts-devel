/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/


#define CMD_EXEC    "exec"
#define CMD_EXPAND  "expand"
#define CMD_MKDIR   "mkdir"
#define CMD_PING    "ping"
#define CMD_READ    "read"
#define CMD_RMDIR   "rmdir"
#define CMD_SHOW    "showmethegopi"
#define CMD_SYSCONF "sysconf"
#define CMD_UNLINK  "unlink"
#define CMD_WRITE   "write"



#define CODE_HELLO              200
#define CODE_SECURE_HELLO       201
#define CODE_CERTIFIED_HELLO    202
#define CODE_GOODBYE            210

#define CODE_RESULT             251
#define CODE_EOR                260

#define CODE_HEARTBEAT          300
#define CODE_DEBUG              303
#define CODE_LOG                310
#define CODE_MESSAGE            320

#define CODE_NOCOMMAND          400
#define CODE_BADCOMMAND         402
#define CODE_TOOMANYTAGS        404
#define CODE_TOOLONGTAG         405

