/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"

#ifdef HAVE_LIBPAM
/*
  bfagent   auth       required     /usr/lib/security/pam_unix_auth.so
  bfagent   account    required     /usr/lib/security/pam_unix_acct.so
*/

#ifdef HAVE_SECURITY_PAM_APPL_H
#include <security/pam_appl.h>
#endif

#ifdef HAVE_PAM_PAM_APPL_H
#include <pam/pam_appl.h>
#endif


struct _bfdata {
	const char	*username;
	const char	*password;
	pam_handle_t *pamh;
};
struct _bfdata pam_glob_data;
int 	pam_session_open = 0;
int 	pam_open = 0;


int pam_converse(int n, const struct pam_message **msg, struct pam_response **resp, void *data)
{
	*resp = calloc(n, sizeof **resp);
	resp[0]->resp_retcode = 0;
	resp[0]->resp = NULL;
	switch (msg[0]->msg_style) {
		case PAM_PROMPT_ECHO_ON:
			resp[0]->resp = strdup(((struct _bfdata *)data)->username);
			break;
		case PAM_PROMPT_ECHO_OFF:
			resp[0]->resp = strdup(((struct _bfdata *)data)->password);
			break;
		default:
			break;
	}
	return (PAM_SUCCESS);
} 

static struct pam_conv conv = {
	(int (*)())pam_converse,
	(void *)&pam_glob_data
};

void valid_credentials_release(void) {
	if (pam_session_open)
		pam_close_session(pam_glob_data.pamh, 0);
	if (pam_open)
		pam_end(pam_glob_data.pamh, 0);
	pam_session_open = 0;
	pam_open = 0;
}

int valid_credentials(const char *session, const char *user, const char *passwd)
{
	BFTRACE("AUTH using PAM");
	pam_glob_data.username = user;
	pam_glob_data.password = passwd;
	pam_glob_data.pamh = NULL;

    if (pam_start(session, user, &conv, &pam_glob_data.pamh) != PAM_SUCCESS)
		return SU_PAMSESSIONERROR;

	if (pam_authenticate(pam_glob_data.pamh, 0) != PAM_SUCCESS) {
		pam_end(pam_glob_data.pamh, 0);
		return SU_UNKNOWNUSER;
	}

	if (pam_acct_mgmt(pam_glob_data.pamh, 0) != PAM_SUCCESS) {
		pam_end(pam_glob_data.pamh, 0);
		return SU_ACCOUNTINVALID;
    }

	if (pam_setcred(pam_glob_data.pamh, PAM_ESTABLISH_CRED) != PAM_SUCCESS) {
		pam_end(pam_glob_data.pamh, 0);
		return SU_NOCRED;
    }

	/* these sets work around a solaris8 bug. */
	pam_set_item(pam_glob_data.pamh, PAM_RHOST, "localhost");
	pam_set_item(pam_glob_data.pamh, PAM_TTY, "/dev/tty");

	if (pam_open_session(pam_glob_data.pamh, 0) == PAM_SUCCESS)
		pam_session_open = 1;
	pam_open = 1;
	pam_glob_data.password = NULL;
	return SU_OK;
}

#else

#ifdef ZOS
#  include <pwd.h>
#endif
#ifdef _AIX
#  include <usersec.h>
#endif

int valid_credentials(
		const char *session,
		const char *user,
		const char *passwd)
{
#if defined(ZOS)
	{
		BFTRACE("AUTH __passwd (z/OS)");
		if (__passwd(user, passwd, NULL) != 0) {
			switch (errno) {
				case ESRCH:
					return SU_UNKNOWNUSER;
				case EACCES:
					return SU_ILLEGAL;
				case EMVSEXPIRE:
					return SU_ACCOUNTINVALID;
			}
			return -1;
		}
	}
#elif defined(_AIX)
	{
		char *u = strdup(user);
		char *p = strdup(passwd);
		int reenter, failed, err;
		char *msg;

		BFTRACE("AUTH authenticate (AIX)");
		do {
			failed = authenticate(u, p, &reenter, &msg);
			err = errno;
			free(msg);
		} while (failed && reenter);

		if (!failed) {
			failed = passwdexpired(u, &msg);
			err = errno;
			free(msg);
		}

		free(p);
		free(u);

		if (failed) {
			switch (err) {
				case ENOENT:
				case EINVAL:
					return SU_UNKNOWNUSER;
				case EPERM:
				case ESAD:
					return SU_ILLEGAL;
			}
			return -1;
		}
	}
#else /* !ZOS && !_AIX */
	BFTRACE("AUTH no PAM (Insecure!)");
#endif /* ZOS/_AIX/! */

	return SU_OK;
}

void valid_credentials_release(void) {
	/* Not possible in the UNIX world. */
}

#endif
