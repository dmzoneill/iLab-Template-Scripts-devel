/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"

int FuncPing(void)
{
	int 	result, timeout_occurred;
	int 	mapfail;

	mapfail = BFCONF_EXISTS(map_drive_is_failure);
	if ((platform_map_drives(defMapStr) != 0 && mapfail) ||
			(platform_map_drives(mapStr) != 0 && mapfail))
	{
		platform_unmap_drives(0);
		send_msg("MAP", "MapFail", NULL);
		return 1;
	}

	ClobberPasswords();

	env_report_locale();
	result = platform_spawn(
			"/", "exit 0", 10,
			NULL, NULL, 0,
			&timeout_occurred, 1);
	send_log("PLAT", platform_id());

	platform_unmap_drives(0);
	if (result == 0) {
		BFTRACE("PING ok");
		send_msg("PING", "PingOk", NULL);
	} else {
		BFTRACE("PING failed");
	}
	return result;
}

