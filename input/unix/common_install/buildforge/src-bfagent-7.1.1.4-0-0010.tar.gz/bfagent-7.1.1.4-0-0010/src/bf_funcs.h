/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef BF_FUNCS_H
#define BF_FUNCS_H

#define CMD_FLAG_PTY         (1 << 0)
#define CMD_FLAG_CC          (1 << 1)
#define CMD_FLAG_ENV         (1 << 2)
#define CMD_FLAG_NO_REEXEC   (1 << 3)


typedef struct {
	char    buf[BFBUFSIZ];
	char    ptyname[256];
	int     mfd;
	int     sfd;
} bf_command_state_t;

typedef int (*bf_command_fn_t)(void);
typedef struct {
	const char *      cmd;
	bf_command_fn_t   func;
	int               flags;
} bf_command_t;

int FuncCCChanges   (void);
int FuncDumpConf    (void);
int FuncExec        (void);
int FuncExpand      (void);
int FuncMkdir       (void);
int FuncPing        (void);
int FuncRead        (void);
int FuncRmdir       (void);
int FuncSysConf     (void);
int FuncUnlink      (void);
int FuncWrite       (void);



typedef int (*bf_internal_fn_t)(char *, int, int *, const char *);
typedef struct {
	char *            cmd;
	bf_internal_fn_t  func;
	int               flags;
} bf_internal_t;
#define BF_INTERNAL_IGNORE_ESCAPES  (1<<0)

#undef BF_INT_DECL
#define BF_INT_DECL(fn) \
	int builtin##fn(\
			char *args, \
			int timeout, \
			int *timed_out, \
			const char *flags)

BF_INT_DECL(Mkdir);
BF_INT_DECL(Rmdir);
BF_INT_DECL(Require);
BF_INT_DECL(Monitor);
BF_INT_DECL(Alive);
BF_INT_DECL(Strsub);
BF_INT_DECL(Edit);
#undef BF_INT_DECL

#endif /* !def BF_FUNCS_H */
