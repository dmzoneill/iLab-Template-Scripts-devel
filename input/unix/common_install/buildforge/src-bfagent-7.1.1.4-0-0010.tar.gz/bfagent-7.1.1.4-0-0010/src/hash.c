/*-
 * Copyright (c) 2005,2007 Chris Fuller <crf@grandecom.net>
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 *
 * License Exception:
 *
 * International Business Machines, Corp. (IBM) is hereby exempted from
 * license condition 2.  Specifically, IBM may redistribute this software
 * in binary form without reproducing this notice in the software or its
 * documentation.
 */

/*
 * HASH_DEBUG dumps output to stdout for most of the basic operations on
 * a hash table.  It makes the assumption that all keys are strings, and
 * a SIGSEGV is likely if the keys are something else.
 */

#include "bf_agent.h"

#ifdef HASH_DEBUG
#define D(x) x
#else
#define D(x) /**/
#endif

/** Checks for whether or not a hash_table was modified by some
  * means other than a remove using this iterator.
  */
static int modified(hash_iter *hi)
{
	hash_table *ht = hi->ht;

	if (hi->version != ht->version) {
		ht->ctx->err = HE_CORRUPTED_STATE;
		return 1;
	}
	return 0;
}

/** Locates the reference to the requested entry in the hash table. */
static hash_linked_list **find_entry(
		hash_table *ht,
		const void *key, size_t keylen)
{
	hash_ctx *ctx = ht->ctx;
	unsigned int hash = (*ctx->hash_fn)(key, keylen);
	unsigned int idx = hash % ht->size;
	hash_equals_fn_t equals_fn = ctx->equals_fn;
	hash_linked_list **lptr = &ht->data[idx];
	hash_linked_list *list = *lptr;

	while (list != NULL) {
		if ((*equals_fn)(key, keylen, list->key, list->keylen))
			return lptr;
		lptr = &list->next;
		list = *lptr;
	}

	return NULL;
}

/** A nice, quick, and simple hashing function with a good spread. */
unsigned int hash_default_hash_fn(const void *data, size_t len)
{
	unsigned int hash = 0;

	if (data != NULL) {
		const unsigned char *s = data;
		while (len-- > 0)
			hash = (hash << 6) + (hash << 16) - hash + (unsigned int)*s++;
	}
	return hash;
}

/** Default key equivalence test. */
int hash_default_equals_fn(
		const void *s1, size_t len1,
		const void *s2, size_t len2)
{
	return len1 != len2 ? 0 : (s1 == s2 || 0 == memcmp(s1, s2, len1));
}

/** A freeing function that does not actually release memory.
 * This is intended for use in cases where the keys are constant
 * strings.
 */
void hash_ignore_free_fn(void *x) { /* Do nothing */ }

/** A freeing function that just calls free. */
void hash_default_free_fn(void *x) { free(x); }

/** Initial state for new hash contexts.  None of the function
 * pointers should be changed once the context has tables.  The
 * table count should not be modified directly, either.
 */
static const hash_ctx HASH_CONTEXT_INITIALIZER = {
	0,
	HE_NO_ERROR,
	0.75f,
	hash_default_hash_fn,
	hash_default_equals_fn,
	hash_default_free_fn,
	hash_default_free_fn
};




HashError hash_get_error(const hash_ctx *ctx)
{
	return ctx == NULL ? HE_NO_CONTEXT : ctx->err;
}

HashError hash_clear_error(hash_ctx *ctx)
{
	HashError err;
	if (ctx == NULL) return HE_NO_CONTEXT;
	err = ctx->err;
	ctx->err = HE_NO_ERROR;
	return err;
}



hash_ctx *hash_ctx_new(void) {
	hash_ctx *ctx = malloc(sizeof(hash_ctx));
	if (ctx != NULL)
		*ctx = HASH_CONTEXT_INITIALIZER;
	D(printf("hash_ctx_new: %p\n", ctx));
	return ctx;
}

int hash_ctx_destroy(hash_ctx *ctx) {
	D(printf("hash_ctx_destroy: %p\n", ctx));
	if (ctx->table_count != 0) {
		ctx->err = HE_ACTIVE_CONTEXT;
		return 0;
	}
	free(ctx);
	return 1;
}



hash_table *hash_new(hash_ctx *ctx, int size) {
	hash_table *ht;
	hash_linked_list **data = NULL;
	
	if (size <= 0) {
		ctx->err = HE_INVALID_SIZE;
		return NULL;
	}

	
	if (NULL == (ht = malloc(sizeof(hash_table))) ||
			NULL == (data = calloc(size, sizeof(hash_linked_list *))) )
	{
		free(ht);
		ctx->err = HE_OUT_OF_MEMORY;
		return NULL;
	}

	ctx->table_count++;

	ht->ctx = ctx;
	ht->size = size;
	ht->count = 0;
	ht->version = 1;
	ht->data = data;
	D(printf("hash_new: ctx=%p size=%d -> ht=%p\n", ctx, (int)size, ht));
	return ht;
}

int hash_resize(hash_table *ht, int size) {
	hash_ctx *ctx = ht->ctx;
	hash_hash_fn_t hash_fn = ctx->hash_fn;
	uint32_t hash;
	int i;
	hash_linked_list **data;
	hash_linked_list *list;
	hash_linked_list *next;

	if (size <= 0) {
		ctx->err = HE_INVALID_SIZE;
		D(printf("hash_resize: ht=%p size=%d -> 0 (HE_INVALID_SIZE)\n", ht, (int)size));
		return 0;
	}

	if (size == ht->size) {
		D(printf("hash_resize: ht=%p size=%d -> 1 (Unchanged)\n", ht, (int)size));
		return 1;
	}

	data = calloc(size, sizeof(hash_linked_list *));
	if (data == NULL) {
		ctx->err = HE_OUT_OF_MEMORY;
		D(printf("hash_resize: ht=%p size=%d -> 0 (HE_OUT_OF_MEMORY)\n", ht, (int)size));
		return 0;
	}

	for (i=0; i<ht->size; i++) {
		list = ht->data[i];
		while (list != NULL) {
			hash = (*hash_fn)(list->key, list->keylen) % size;
			next = list->next;
			list->next = data[hash];
			data[hash] = list;
			list = next;
		}
	}

	free(ht->data);
	++ht->version;
	ht->data = data;
	ht->size = size;
	D(printf("hash_resize: ht=%p size=%d -> 1 (Ok)\n", ht, (int)size));
	return 1;
}

void hash_clear(hash_table *ht) {
	hash_ctx *ctx = ht->ctx;
	hash_linked_list **data = ht->data;
	hash_linked_list *list, *next;
	hash_free_fn_t free_key_fn = ctx->free_key_fn;
	hash_free_fn_t free_value_fn = ctx->free_value_fn;
	int i;

	D(printf("hash_clear: ht=%p\n", ht));
	for (i=0; i<ht->size; i++) {
		list = data[i];
		while (list != NULL) {
			next = list->next;
			(*free_value_fn)(list->value);
			(*free_key_fn)(list->key);
			free(list);
			list = next;
		}
		data[i] = NULL;
	}

	++ht->version;
	ht->count = 0;
}

void hash_destroy(hash_table *ht) {
	hash_ctx *ctx = ht->ctx;

	D(printf("hash_destroy: ht=%p\n", ht));
	hash_clear(ht);
	free(ht->data);
	free(ht);
	ctx->table_count--;
}



int hash_put(
		hash_table *ht,
		void *key, size_t keylen,
		void *value)
{
	hash_ctx *ctx = ht->ctx;
	unsigned int hash = (*ctx->hash_fn)(key, keylen);
	unsigned int idx = hash % ht->size;
	hash_linked_list *entry = malloc(sizeof(hash_linked_list));
	hash_linked_list **lptr;
	hash_linked_list *list = ht->data[idx];
	hash_equals_fn_t equals_fn = ctx->equals_fn;
	float load, loadf;

	if (entry == NULL) {
		ctx->err = HE_OUT_OF_MEMORY;
		D(printf("hash_put: ht=%p key=\"%s\" keylen=%d value=%p"
				" -> 0 (HE_OUT_OF_MEMORY)\n",
				ht, (char *)key, (int)keylen, value));
		return 0;
	}

	++ht->version;
	ht->data[idx] = entry;
	entry->key = key;
	entry->keylen = keylen;
	entry->value = value;
	entry->next = list;
	lptr = &entry->next;


	while (list != NULL) {
		if ((*equals_fn)(key, keylen, list->key, list->keylen)) {
			*lptr = list->next;
			(*ctx->free_value_fn)(list->value);
			(*ctx->free_key_fn)(list->key);
			free(list);
			D(printf("hash_put: ht=%p key=\"%s\" keylen=%d value=%p"
					" -> 1 (Replaced)\n",
					ht, (char *)key, (int)keylen, value));
			return 1;
		}
		lptr = &list->next;
		list = *lptr;
	}

	load = ++ht->count / (float)ht->size;
	loadf = ctx->load_factor;
	if (loadf <= 0.0f)
		loadf = ctx->load_factor = 0.75f;
	if (load >= loadf) {
		int size = (ht->size << 1) + 1;
		while ((load = ht->count / (float)size) > ctx->load_factor)
			size = (size << 1) + 1;
		if (hash_resize(ht, size)) {
			D(printf("hash_put: ht=%p key=\"%s\" keylen=%d value=%p"
					" -> 3 (Resized)\n",
					ht, (char *)key, (int)keylen, value));
			return 3;
		} else {
			D(printf("hash_put: ht=%p key=\"%s\" keylen=%d value=%p"
					" -> 4 (Resize failed)\n",
					ht, (char *)key, (int)keylen, value));
			return 4;
		}
	}
	D(printf("hash_put: ht=%p key=\"%s\" keylen=%d value=%p"
			" -> 2 (Added)\n",
			ht, (char *)key, (int)keylen, value));
	return 2;
}

int hash_put_str(hash_table *ht, char *key, void *value)
{
	return hash_put(ht, key, strlen(key) + 1, value);
}


void *hash_get(
		hash_table *ht,
		const void *key, size_t keylen)
{
	hash_linked_list **lptr = find_entry(ht, key, keylen);
	D(printf("hash_get: ht=%p key=\"%s\" keylen=%d -> %p\n",
			ht, (char *)key, (int)keylen,
			lptr == NULL ? NULL : (*lptr)->value));
	return lptr == NULL ? NULL : (*lptr)->value;
}

void *hash_get_str(hash_table *ht, const char *key)
{
	return hash_get(ht, key, strlen(key) + 1);
}


int hash_contains_key(
		hash_table *ht,
		const void *key, size_t keylen)
{
	hash_linked_list **lptr = find_entry(ht, key, keylen);
	int ret = (lptr == NULL) ? 0 : 1;
	D(printf("hash_contains_key: ht=%p key=\"%s\" keylen=%d -> %d\n",
			ht, (char *)key, (int)keylen, ret));
	return ret;
}

int hash_contains_key_str(hash_table *ht, const char *key)
	{ return hash_contains_key(ht, key, strlen(key) + 1); }
		

int hash_del(
		hash_table *ht,
		const void *key, size_t keylen)
{
	hash_ctx *ctx = ht->ctx;
	hash_linked_list **lptr = find_entry(ht, key, keylen);
	hash_linked_list *entry;

	if (lptr == NULL)  {
		D(printf("hash_del: ht=%p key=\"%s\" keylen=%d -> 0 (Not found)\n",
				ht, (char *)key, (int)keylen));
		return 0;
	}
	entry = *lptr;

	(*ctx->free_value_fn)(entry->value);
	(*ctx->free_key_fn)(entry->key);
	*lptr = entry->next;
	free(entry);
	++ht->version;
	--ht->count;
	D(printf("hash_del: ht=%p key=\"%s\" keylen=%d -> 1 (Deleted)\n",
			ht, (char *)key, (int)keylen));
	return 1;
}

int hash_del_str(hash_table *ht, const char *key)
	{ return hash_del(ht, key, strlen(key) + 1); }



hash_iter *hash_iter_new(hash_table *ht)
{
	hash_iter *hi = malloc(sizeof(hash_iter));
	hi->ht = ht;
	hi->version = ht->version;
	hi->bucket = -1;
	hi->entry = NULL;
	hi->ref = NULL;

	if (hi == NULL) {
		ht->ctx->err = HE_OUT_OF_MEMORY;
		D(printf("hash_iter_new: ht=%p -> NULL (HE_OUT_OF_MEMORY)\n", ht));
		return NULL;
	}

	D(printf("hash_iter_new: ht=%p -> hi=%p\n", ht, hi));
	return hi;
}

void hash_iter_destroy(hash_iter *hi)
{
	D(printf("hash_iter_destroy: hi=%p\n", hi));
	free(hi);
}


int hash_iter_next(hash_iter *hi)
{
	hash_table *ht = hi->ht;
	hash_linked_list *entry;

	/* Check for concurrent modification */
	if (modified(hi)) {
		hi->bucket = -1;
		hi->entry = NULL;
		hi->ref = NULL;
		D(printf("hash_iter_next: hi=%p -> 0 (HE_CORRUPTED_STATE)\n", hi));
		return 0;
	}

	/* Check for more entries in the same linked list */
	if (NULL != (entry = hi->entry)) {
		if (NULL != entry->next) {
			hi->entry = entry->next;
			hi->ref = &entry->next;
			D(printf("hash_iter_next: hi=%p -> 1 (next in LL: key=%s)\n",
					hi, (char *)hi->entry->key));
			return 1;
		}
	}
	/* Check for saved reference from a remove */
	else if (NULL != hi->ref && NULL != *hi->ref) {
		hi->entry = *hi->ref;
		D(printf("hash_iter_next: hi=%p -> 1 (saved from remove: key=%s)\n",
				hi, (char *)hi->entry->key));
		return 1;
	}

	/* Find the next linked list that has entries */
	do {
		/* Out of entries */
		if (++hi->bucket >= ht->size) {
			hi->bucket = -1;
			hi->entry = NULL;
			hi->ref = NULL;
			D(printf("hash_iter_next: hi=%p -> 0 (no more entries)\n", hi));
			return 0;
		}
	} while (NULL == (entry = ht->data[hi->bucket]));

	/* Found the next entry */
	hi->entry = entry;
	hi->ref = &ht->data[hi->bucket];
	D(printf("hash_iter_next: hi=%p -> 1 (next bucket: key=%s)\n",
			hi, (char *)entry->key));
	return 1;
}

void hash_iter_remove(hash_iter *hi)
{
	hash_table *ht = hi->ht;
	hash_ctx *ctx = ht->ctx;
	hash_linked_list *entry = hi->entry;

	if (entry == NULL) {
		D(printf("hash_iter_remove: hi=%p (HE_INVALID_REMOVE)\n", hi));
		ctx->err = HE_INVALID_REMOVE;
		return;
	}
	if (modified(hi)) {
		D(printf("hash_iter_remove: hi=%p (HE_CORRUPTED_STATE)\n", hi));
		return;
	}

	D(printf("hash_iter_remove: hi=%p (Removed: key=%s)\n",
			hi, (char *)entry->key));
	hi->entry = NULL;
	*hi->ref = entry->next;
	(*ctx->free_value_fn)(entry->value);
	(*ctx->free_key_fn)(entry->key);
	free(entry);
	++hi->version;
	++ht->version;
	--ht->count;
}


#ifdef HASH_DEBUG
/** Warning: This function assumes that only strings are
  	used as keys and values in the hash. */
void hash_debug(hash_table *ht, int strings) {
	hash_ctx *ctx = ht->ctx;
	hash_linked_list *list;
	int i;

	printf("hash_debug: ht=%p\n", ht);
	printf("  ctx=%p (table_count=%u load_factor=%f)\n"
			"  ht->count/ht->size (load)=%u/%u (%f)\n",
			ctx,
			ctx->table_count,
			ctx->load_factor,
			ht->count,
			ht->size,
			ht->count / (float)ht->size);


	for (i=0; i<ht->size; i++) {
		printf("  %3d:", i);
		list = ht->data[i];
		while (list != NULL) {
			printf(strings ? "  %s-> \"%s\"" : " %s-> %p",
					(char *)list->key,
					(char *)list->value);
			list = list->next;
		}
		printf("\n");
	}
	printf("\n");
}
#endif


#ifdef HASH_TEST
static const char *OUT_OF_MEMORY   = "Out of memory.";
static const char *INVALID_SIZE    = "The hash table size must be positive.";
static const char *INVALID_REMOVE  = "Called remove without a successful next.";
static const char *CORRUPTED_STATE = "Iterator state corrupted.";
static const char *ACTIVE_CONTEXT  = "Cannot free an active hash context.";

static void check_error(hash_ctx *ctx)
{
	int err = ctx == NULL ? HE_OUT_OF_MEMORY : ctx->err;
	const char *s = NULL;

	switch (err) {
		case HE_NO_ERROR: return;
		case HE_OUT_OF_MEMORY:   s = OUT_OF_MEMORY;   break;
		case HE_INVALID_SIZE:    s = INVALID_SIZE;    break;
		case HE_INVALID_REMOVE:  s = INVALID_REMOVE;  break;
		case HE_CORRUPTED_STATE: s = CORRUPTED_STATE; break;
		case HE_ACTIVE_CONTEXT:  s = ACTIVE_CONTEXT;  break;
		default:
			fprintf(stderr, "??? %d\n", err);
			exit(2);
	}
	fprintf(stderr, "%s\n", s);
	exit(1);
}

/** Warning: This function assumes that only strings are
  	used as keys in the hash. */
static void free_key(void *x) {
	printf("free_key: %s\n", (char *)x);
}

/** Warning: This function assumes that only strings are
  	used as values in the hash. */
static void free_value(void *x) {
	printf("free_value: %s\n", (char *)x);
}

int main(int argc, char *argv[]) {
	hash_table *ht;
	hash_ctx *ctx;
	
	ctx = hash_ctx_new();
	check_error(ctx);
	ctx->free_key_fn = free_key;
	ctx->free_value_fn = free_value;

	ht = hash_new(ctx, 5);
	check_error(ctx);
	printf("--- Initial table\n");
	hash_debug(ht, 1);

	hash_put_str(ht, "key1", "value1");
	check_error(ctx);
	printf("--- Added key1\n");
	hash_debug(ht,1);

	hash_put_str(ht, "key2", "value2");
	hash_put_str(ht, "key3", "value3");
	check_error(ctx);
	printf("--- Added key2, key3\n");
	hash_debug(ht,1);

	hash_put_str(ht, "keyA", "valueA");
	hash_put_str(ht, "keyB", "valueB");
	hash_put_str(ht, "keyC", "valueC");
	check_error(ctx);
	printf("--- Added more keys A-C\n");
	hash_debug(ht,1);


	hash_resize(ht, 7);
	check_error(ctx);
	printf("--- After resize to 7\n");
	hash_debug(ht,1);

	hash_resize(ht, 3);
	check_error(ctx);
	printf("--- After resize to 3\n");
	hash_debug(ht,1);

	printf("--- deleted key2: %d\n", hash_del_str(ht, "key2"));
	check_error(ctx);
	hash_debug(ht,1);

	printf("--- deleted keyX: %d\n", hash_del_str(ht, "keyX"));
	check_error(ctx);
	hash_debug(ht,1);

	printf("--- deleted keyB: %d\n", hash_del_str(ht, "keyB"));
	check_error(ctx);
	hash_debug(ht,1);

	printf("--- deleted key3: %d\n", hash_del_str(ht, "key3"));
	check_error(ctx);
	hash_debug(ht,1);

	hash_put_str(ht, "key1", "newValue1");
	check_error(ctx);
	printf("--- Replaced key1\n");
	hash_debug(ht,1);

	hash_put_str(ht, "key4", "value4");
	printf("--- Added key4\n");
	hash_debug(ht,1);
	check_error(ctx);

	hash_resize(ht, 1);
	check_error(ctx);
	printf("--- After resize to 1\n");
	hash_debug(ht,1);

	printf("--- destroying hash...\n");
	hash_destroy(ht);
	check_error(ctx);

	printf("\n--- destroying context...\n");
	if (!hash_ctx_destroy(ctx))
		check_error(ctx);

	printf("\n*** TESTS COMPLETE\n");
	return 0;
}


#endif /* HASH_TEST */

