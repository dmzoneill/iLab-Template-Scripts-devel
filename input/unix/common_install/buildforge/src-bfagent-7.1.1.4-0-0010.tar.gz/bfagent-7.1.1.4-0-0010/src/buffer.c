/*
Copyright (C)2007-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "buffer.h"
#include "convert.h"

#undef DEBUG_FORMAT_MESSAGE
#ifdef DEBUG_FORMAT_MESSAGE
#  define DFM(x) x
#else
#  define DFM(x) /**/
#endif
typedef enum {
	FT_UNUSED = 0,
	FT_C,
	FT_S,
	FT_P,
	FT_D,
	FT_LD,
	FT_O,
	FT_LO,
	FT_U,
	FT_LU,
	FT_X,
	FT_X_UPPER,
	FT_LX,
	FT_LX_UPPER
} format_type_t;

typedef union {
	char c;
	const char *s;
	const void *p;
	int d;
	long ld;
	unsigned int u;
	unsigned long lu;
} format_data_t;

#define MAX_MSG_ARGS 10
#define MAX_MSG_FIELDS 24
/* This is a bit like sprintf, but with limited functionality.
 * Only the c, s, p, d, ld, u, and lu formats are supported.
 * We call sprintf to do the real work for all formats except
 * %s.  The positional parameter convention of %1$s, %2$ld, etc.
 * is supported, but a maximum of 9 arguments may be used in any
 * case.  Flags, width, precision, '*', and formats other than
 * those listed above will produce the message "[!!!c]", where
 * 'c' is the character that was not understood.
 *
 * The obvious question is "Why we are doing this?"  The answer is
 * that sprintf is generally aware of your locale.  This will not
 * be a problem in most circumstances, but (on Windows in particular)
 * sprintf might do the wrong thing when passed a UTF-8 format
 * string.  The last byte of the UTF-8 literal may be a DBCS lead
 * byte and swallow up the '%' that follows it, leading to the use
 * of the wrong arguments and potentially a crash.
 *
 * There does not appear to be any reliable and portable way to
 * avoid this problem except by using something other than sprintf
 * to handle the literal UTF-8 data.  Fortunately, since we control
 * the format strings, we don't have to completely reimplement
 * sprintf, here -- we only implement the functionality that we
 * actually need/use.  If at any point we see something we don't
 * understand, we pass the whole thing off to vsprintf just in
 * case.
 */
int format_message(char *buf, const char *msg, ...) {
	const char *lit_beg[MAX_MSG_FIELDS];
	int lit_len[MAX_MSG_FIELDS];
	int field_arg[MAX_MSG_FIELDS];
	format_data_t arg_data[MAX_MSG_ARGS];
	format_type_t arg_type[MAX_MSG_ARGS];
	const char *m = msg, *mark;
	char *b = buf;
	int maxarg = 0, fields = 0;
	int i, arg = 0, len;
	va_list va;

	memset(arg_type, 0, sizeof(arg_type));
	va_start(va, msg);

	/* Step 1: Parse message format and count args */
	while (NULL != (m = strchr(mark = m, '%'))) {
		/* Step 1a: Save range of literal text before % */
		DFM(printf("format_message: field=%d lit_len=%d lit_beg->%p[%s]\n",
					fields, (int)(m-mark), mark, mark));
		lit_beg[fields] = mark;
		lit_len[fields] = m - mark;

		/* Step 1b: Deal with %% by using the first % in the literal */
		/*   and not consuming an arg. */
		if (*++m == '%') {
			DFM(printf("format_message: %%%%\n"));
			++lit_len[fields];
			++m;
			field_arg[fields++] = 0;
			continue;
		}

		/* Step 1c: Figure out which arg this is */
		if (*m > '0' && *m <= '9') {
			arg = *m++ - '0';
			if (*m != '$') {
				DFM(printf("format_message: 1c: Numbers, but no $: [%s]\n", msg));
				return vsprintf(buf, msg, va);
			}
			DFM(printf("format_message: positional: arg=%d\n", arg));
			++m;
		} else {
			++arg;
			DFM(printf("format_message: ordered: arg=%d\n", arg));
		}
		if (maxarg < arg)
			maxarg = arg;
		field_arg[fields++] = arg;

		/* Step 1d: Decode the type.  Only c, s, d, u, ld, and lu are allowed. */
		switch (*m++) {
			case 's':  arg_type[arg] = FT_S;  break;
			case 'd':
			case 'i':  arg_type[arg] = FT_D;  break;
			case 'l':
				switch (*m++) {
					case 'd':  arg_type[arg] = FT_LD;  break;
					case 'u':  arg_type[arg] = FT_LU;  break;
					case 'x':  arg_type[arg] = FT_LX;  break;
					case 'X':  arg_type[arg] = FT_LX_UPPER;  break;
					case 'o':  arg_type[arg] = FT_LO;  break;
					default: return vsprintf(buf, msg, va);
				}
				break;
			case 'c':  arg_type[arg] = FT_C;  break;
			case 'u':  arg_type[arg] = FT_U;  break;
			case 'x':  arg_type[arg] = FT_X;  break;
			case 'X':  arg_type[arg] = FT_X_UPPER;  break;
			case 'o':  arg_type[arg] = FT_O;  break;
			case 'p':  arg_type[arg] = FT_P;  break;
			default:
				DFM(printf("format_message: 1d: bad arg_type during parse: [%s]\n", msg));
				return vsprintf(buf, msg, va);
		}
		DFM(printf("format_message: arg type='%c' -> %d\n", m[-1], arg_type[arg]));
	}

	/* Step 2: Take care of the leftover literal.  If that's all we have, then
	 *   all we need to do is copy the message and be done with it.
	 */
	if (0 == fields) {
		DFM(printf("format_message: literal only\n"));
		len = strlen(msg);
		memcpy(buf, msg, len + 1);
		return len;
	}
	DFM(printf("format_message: literal assigned to field=%d\n", fields));
	lit_beg[fields] = mark;
	lit_len[fields] = strlen(mark);
	field_arg[fields++] = 0;

	/* Step 3: Read in the args */
	for (arg=1; arg<=maxarg; ++arg) {
		DFM(printf("format_message: reading arg=%d type=%d\n", arg, arg_type[arg]));
		switch (arg_type[arg]) {
			case FT_S:
				arg_data[arg].s = va_arg(va, const char *);
				break;
			case FT_D:
			case FT_C:
				arg_data[arg].d = va_arg(va, int);
				break;
			case FT_LD:
				arg_data[arg].ld = va_arg(va, long);
				break;
			case FT_U:
			case FT_X:
			case FT_X_UPPER:
			case FT_O:
				arg_data[arg].u = va_arg(va, unsigned int);
				break;
			case FT_LU:
			case FT_LX:
			case FT_LX_UPPER:
			case FT_LO:
				arg_data[arg].lu = va_arg(va, unsigned long);
				break;
			case FT_P:
				arg_data[arg].p  = va_arg(va, const void *);
				break;
			default:
				DFM(printf("format_message: 3: Bad arg_type during output: [%s]\n", msg));
				return vsprintf(buf, msg, va);
		}
	}
	va_end(va);

	/* Step 4: Output phase */
	for (i=0; i<fields; ++i) {
		int arg = field_arg[i];
		DFM(printf("format_message: writing field #%d lit_beg=%d lit_len=%d\n",
					i, lit_beg[i] - msg, lit_len[i]));
		len = lit_len[i];
		if (len > 0) {
			memcpy(b, lit_beg[i], len);
			b += len;
		}
		if (arg > 0) {
			switch (arg_type[arg]) {
				case FT_S:   strcpy(b, arg_data[arg].s); b += strlen(b);  break;
				case FT_D:   b += sprintf(b, "%d",  arg_data[arg].d );    break;
				case FT_C:   *b++ = (char)arg_data[arg].d;                break;
				case FT_LD:  b += sprintf(b, "%ld", arg_data[arg].ld);    break;
				case FT_U:   b += sprintf(b, "%u",  arg_data[arg].u );    break;
				case FT_O:   b += sprintf(b, "%o",  arg_data[arg].u );    break;
				case FT_X:   b += sprintf(b, "%x",  arg_data[arg].u );    break;
				case FT_X_UPPER:
							 b += sprintf(b, "%X",  arg_data[arg].u );    break;
				case FT_LU:  b += sprintf(b, "%lu", arg_data[arg].lu);    break;
				case FT_LX:  b += sprintf(b, "%lx", arg_data[arg].lu);    break;
				case FT_LX_UPPER:
							 b += sprintf(b, "%lX", arg_data[arg].lu);    break;
				case FT_LO:  b += sprintf(b, "%lo", arg_data[arg].lu);    break;
				case FT_P:   b += sprintf(b, "%p",  arg_data[arg].p );    break;
				default:
					/* PARANOID */
					DFM(printf("format_message: 4: Bad format: [%s]\n", msg));
					return vsprintf(buf, msg, va);
			}
		}
	}
	*b = '\0';
	DFM(printf("format_message: ret=%d\n", b - buf));
	return b - buf;
}


int buffer_ensure_capacity(
		char **bufptr,
		size_t *lenptr,
		size_t size)
{
	char *buf;
	size_t len = *lenptr;
	if (len >= size) { return 1; }

	/* Quantize to 4096-byte boundary, making sure
	 * that there is at least one byte left over.
	 */
	len = (size & ~0x0FFF) + 0x1000;

	/* Check for overflow of size_t data type */
	if (len >= size) {
		buf = realloc(*bufptr, size);
		if (NULL != buf) {
			*bufptr = buf;
			*lenptr = size;
			return 1;
		}
	}

	/* Out of memory :( */
	free(*bufptr);
	*bufptr = NULL;
	*lenptr = 0;
	return 0;
}


#define UTF8_QUOTE (0x22)
#define UTF8_PERCENT (0x25)
#define UTF8_IS_CTRL(c) ( ((c) & 0xE0) == 0 )
static char UTF8_HEX[] = {
	0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,
	0x38, 0x39, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46
};
int buffer_append_escaped_utf8(
		char **bufptr,
		size_t *blenptr,
		size_t *bidxptr,
		const char *s)
{
	const char *p = s;
	int bidx = *bidxptr;
	int len = 0;

	BUFFER_ENSURE_CAPACITY(bufptr, blenptr, bidx + 32);

	(*bufptr)[bidx++] = UTF8_QUOTE;
	while (*p != '\0' ) {
		/* Scan for the first char that can't simply be copied as-is */
		while (!UTF8_IS_CTRL(*p)
				&& *p != UTF8_QUOTE
				&& *p != UTF8_PERCENT) { ++p; }
		len = p - s;
		if (len > 0) {
			BUFFER_ENSURE_CAPACITY(bufptr, blenptr, bidx + len + 32);
			memcpy(&(*bufptr)[bidx], s, len);
			bidx += len;
		}
		if (*p == 0) { break; }
		BUFFER_ENSURE_CAPACITY(bufptr, blenptr, bidx + 32);
		(*bufptr)[bidx++] = UTF8_PERCENT;
		(*bufptr)[bidx++] = UTF8_HEX[(*p >> 4) & 0x0F];
		(*bufptr)[bidx++] = UTF8_HEX[*p & 0x0F];
		s = ++p;
	}
	(*bufptr)[bidx++] = UTF8_QUOTE;
	*bidxptr = bidx;
	return 1;

out_of_memory:
	return 0;
}


/* buffer_append_escaped_normal operates in terms of literal UTF-8.
 * We have to convert the string from EBCDIC-escaped UTF-8 to real
 * UTF-8, process it, and then EBCDIC-escape the UTF-8 output.
 */
#ifdef ZOS
int buffer_append_escaped_zos(
		char **bufptr,
		size_t *blenptr,
		size_t *bidxptr,
		const char *s)
{
	char *z;
	int ret;
	size_t orig_idx = *bidxptr;
	size_t slen = strlen(s) + 1;

	z = malloc(slen);
	if (NULL == z) { return 0; }

	memcpy(z, s, slen);
	convert_etoa_l(z, slen);
	ret = buffer_append_escaped_utf8(bufptr, blenptr, bidxptr, z);
	if (NULL != *bufptr && *bidxptr > orig_idx) {
		convert_atoe_l(&(*bufptr)[orig_idx], *bidxptr - orig_idx);
	}
	free(z);

	return ret;
}
#endif /* ZOS/! */

char *buffer_format(
		size_t *lenptr,
		const char *bucket,
		const char *msgkey,
		const char *fmt,
		...)
{
	va_list va;
	char *ret;

	va_start(va, fmt);
	ret = buffer_format_v(lenptr, bucket, msgkey, fmt, va);
	va_end(va);
	return ret;
}

char *buffer_format_v(
		size_t *lenptr,
		const char *bucket,
		const char *msgkey,
		const char *fmt,
		va_list va)
{
	char *buf;
	size_t bidx = 0;
	size_t blen;
#ifdef ZOS
	char *z, *zos_s;
#endif /* ZOS */

	if (NULL == msgkey) { return NULL; }
	blen = strlen(msgkey) + 128;
	buf = malloc(blen);
	if (NULL == buf) { return NULL; }

	bidx = format_message(buf, "320 %s %s[",
			(NULL != bucket) ? bucket : "*",
			msgkey);
	if (NULL == fmt || '\0' == *fmt) {
		buf[bidx - 1] = '\n';
		goto no_args;
	}

	while ('\0' != *fmt) {
		switch (*fmt) {
			/* i -> integer literal */
			case 'i': {
				int i = va_arg(va, int);
				BUFFER_ENSURE_CAPACITY(&buf, &blen, bidx + 32);
				bidx += sprintf(&buf[bidx], "%+d", i);
				break;
			}

			/* s -> string literal */
			case 's': {
				const char *s = va_arg(va, const char *);
				buffer_append_escaped(&buf, &blen, &bidx, s);
				break;
			}

			/* k -> string key */
			case 'k': {
				const char *k = va_arg(va, const char *);
				size_t len = strlen(k);
				BUFFER_ENSURE_CAPACITY(&buf, &blen, bidx + len + 32);
				buf[bidx++] = '*';
				memcpy(&buf[bidx], k, len);
				bidx += len;
				break;
			}

			/* t -> tmestamp */
			case 't': {
				time_t t = va_arg(va, time_t);
				int i = (int)t;
				BUFFER_ENSURE_CAPACITY(&buf, &blen, bidx + 32);
				bidx += sprintf(&buf[bidx], "%+d", i);
				break;
			}

			/* c -> ASCII character value */
			case 'c': {
				char c = va_arg(va, int);
#ifdef ZOS
				/* The 'c' encoding can only be used for a single ASCII
				 * character.  For z/OS, this means that we need to undo
				 * the EBCDIC escaping.
				 */
				convert_etoa_l(&c, 1);
#endif /* ZOS */
				BUFFER_ENSURE_CAPACITY(&buf, &blen, bidx + 32);
				bidx += sprintf(&buf[bidx], "%+d", c & 0x7F);
			}

			/* l -> long int literal */
			case 'l': {
				long l = va_arg(va, long);
				BUFFER_ENSURE_CAPACITY(&buf, &blen, bidx + 32);
				bidx += sprintf(&buf[bidx], "%+ld", l);
				break;
			}

			/* p -> memory ptr (sent as a string) */
			case 'p': {
				const void *p = va_arg(va, const void *);
				char s[128];
				sprintf(s, "%p", p);
				buffer_append_escaped(&buf, &blen, &bidx, s);
				break;
			}

			/* Anything else is invalid.  As we don't know how to handle
			 * the argument list safely at this point, we have to abort.
			 */
			default: {
				BUFFER_ENSURE_CAPACITY(&buf, &blen, bidx + 32);
				buf[bidx++] = '!';
				buf[bidx++] = *fmt;
				goto done;
			}
		}
		buf[bidx++] = ',';
		++fmt;
	}

done:
	if (',' == buf[bidx - 1]) { --bidx; }
	BUFFER_ENSURE_CAPACITY(&buf, &blen, bidx + 4);
	buf[bidx++] = ']';
	buf[bidx++] = '\n';
no_args:
	buf[bidx] = '\0';
	if (NULL != lenptr) { *lenptr = bidx; }
out_of_memory:
	return buf;
}



#ifdef BUFFER_UNIT_TEST
/* This test text is rendered as escaped UTF-8 bytes to ensure that its
 * content is correct regardless of the platform on which it is compiled.
 * 
 * The first line is simply "{{{".
 * 
 * The second line gives the german sentence "Die B[ae]ume sind gro[ss]!"
 * ("The trees are large!").  In place of "[ae]", the "\xC3\xA4" yields
 * U+00E4 (A WITH DIAERESIS, LATIN SMALL LETTER).  Although called a
 * diaeresis by Unicode, it is used as an umlaut in German.  In place
 * of "[ss]" is the sequence "\xC3\x9F", which produces
 * U+00DF (SHARP S, LATIN SMALL LETTER), also called an Eszett.
 *
 * The next line is the common Japanese greeting "konichiwa" rendered in
 * hiragana.  The symbols are "ko" "n" "ni" "ti" and "ha" followed by the
 * Japanese full stop mark.
 *
 * The next line gives all ASCII control characters except for
 * U+0000 (NULL), U+000A (LINE FEED) and U+000D (CARRIAGE RETURN).
 * Specifically: U+0001 through U+0009, U+000B, U+000C,
 * U+000D through U+001F, U+007F (DELETE).
 *
 * The next line gives all the printable ASCII characters in order.
 *
 * The output from the test is always UTF-8.  On z/OS, the output can
 * be run through "iconv -c -f UTF-8 -t IBM-1047" or "od -t x1" to
 * verify the result.  Obviously, the former will not be able to
 * show the Japanese characters; however, the latter may be used to
 * verify that the output bytes are correct.
 */
static const char *TEST_MESSAGE =
	"\x7B\x7B\x7B"	/* {{{ */
	"\x0D\x0A"

	"\x44\x69\x65\x20\x42\xC3\xA4\x75\x6D\x65\x20"	 /* Die b[ae]ume */
	"\x73\x69\x6E\x64\x20\x67\x72\x6F\xC3\x9F\x21"   /* sind gro[ss]! */
	"\x0D\x0A"

	"\xE3\x81\x93\xE3\x82\x93\xE3\x81\xAB"  /* [ko][n][ni] */
	"\xE3\x81\xA1\xE3\x81\xAF\xE3\x80\x82"	/* [ti][ha][.] */
	"\x0D\x0A"

	"\x01\x02\x03\x04\x05\x06\x07\x08\x09"  /* [^A] - [^I] */
	"\x0B\x0C\x0E\x0F" /* [^K][^L][^N][^O] */
	"\x10\x11\x12\x13\x14\x15\x16\x17"  /* [^P] - [^W] */
	"\x18\x19\x1A\x1B\x1C\x1D\x1E\x1F"  /* [^X] - [^_] */
	"\x7F"	/* [^?] */
	"\x0D\x0A"

	"\x20\x21\x22\x23\x24\x25\x26\x27"  /* [space]!"#$%&' */
	"\x28\x29\x2A\x2B\x2C\x2D\x2E\x2F"  /* ()*+,-./ */
	"\x30\x31\x32\x33\x34\x35\x36\x37"  /* 01234567 */
	"\x38\x39\x3A\x3B\x3C\x3D\x3E\x3F"  /* 89:;<=>? */
	"\x40\x41\x42\x43\x44\x45\x46\x47"  /* @ABCDEFG */
	"\x48\x49\x4A\x4B\x4C\x4D\x4E\x4F"  /* HIJKLMNO */
	"\x50\x51\x52\x53\x54\x55\x56\x57"  /* PQRSTUVW */
	"\x58\x59\x5A\x5B\x5C\x5D\x5E\x5F"  /* XYZ[\]^_ */
	"\x60\x61\x62\x63\x64\x65\x66\x67"  /* `abcdefg */
	"\x68\x69\x6A\x6B\x6C\x6D\x6E\x6F"  /* hijklmno */
	"\x70\x71\x72\x73\x74\x75\x76\x77"  /* pqrstuvw */
	"\x78\x79\x7A\x7B\x7C\x7D\x7E"  /* xyz{|}~ */
	"\x0D\x0A"

	"\x7D\x7D\x7D";	/* }}} */

int main(int argc, char *argv[]) {
	const char *p = TEST_MESSAGE;
	char *s;
#  ifdef ZOS
	size_t len = strlen(p) + 1;
	char *z = malloc(len);

	memcpy(z, p, len);
	convert_atoe_l(z, len);
	p = z;
#  endif /* ZOS */

	s = buffer_format("EXEC", "MessageKey", "iksl",
			-42, "IndirectKey", p, 9876543210L);

#  ifdef ZOS
	free(z);
	convert_etoa(s);
#  endif /* ZOS */

	printf("%s\n", s);
	free(s);
	return 0;
}
#endif /* BUFFER_UNIT_TEST */

