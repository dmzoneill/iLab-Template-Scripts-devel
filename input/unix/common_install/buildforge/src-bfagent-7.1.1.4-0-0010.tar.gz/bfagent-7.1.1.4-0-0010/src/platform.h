/*
Copyright (C)2007-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef PLATFORM_H
#define PLATFORM_H

#ifndef PLATFORM_C
extern int utf8_is_native;
#endif

#include "bfconf.h"

typedef enum {
	CONVERT_UTF8_TO_NATIVE,
	CONVERT_NATIVE_TO_UTF8,
	CONVERT_UTF8_TO_CONSOLE,
	CONVERT_CONSOLE_TO_UTF8
} platform_convert_t;

typedef enum {
	STYLE_MAC,
	STYLE_VMS,
	STYLE_VOS,
	STYLE_UNIX,
	STYLE_WINDOWS,
	STYLE_CYGWIN
} platform_style_t;

typedef enum {
	CPU_ARCH_UNKNOWN,
	CPU_ARCH_ALPHA,
	CPU_ARCH_HPPA,
	CPU_ARCH_IA64,
	CPU_ARCH_MVS,
	CPU_ARCH_PASE,
	CPU_ARCH_PPC,
	CPU_ARCH_S390,
	CPU_ARCH_SPARC,
	CPU_ARCH_VAX,
	CPU_ARCH_X86
} platform_cpu_arch_t;

typedef enum {
	CPU_MANU_UNKNOWN,
	CPU_MANU_AMD,
	CPU_MANU_APPLE,
	CPU_MANU_CYRIX,
	CPU_MANU_DEC,
	CPU_MANU_HP,
	CPU_MANU_IBM,
	CPU_MANU_INTEL,
	CPU_MANU_MOTOROLA,
	CPU_MANU_NEXGEN,
	CPU_MANU_NSC,
	CPU_MANU_RISE,
	CPU_MANU_SIS,
	CPU_MANU_SUN,
	CPU_MANU_TRANSMETA,
	CPU_MANU_UMC,
	CPU_MANU_VIA
} platform_cpu_manufacturer_t;

typedef enum {
	CPU_MODEL_UNKNOWN,

	/* CPU_ARCH_ALPHA */

	/* CPU_ARCH_HPPA */

	/* CPU_ARCH_IA64 */
	CPU_MODEL_IA64_ITANIUM,
	CPU_MODEL_IA64_ITANIUM_2,

	/* CPU_ARCH_MVS */

	/* CPU_ARCH_PASE */

	/* CPU_ARCH_PPC */
	CPU_MODEL_PPC_6XX,
	CPU_MODEL_PPC_POWER,
	CPU_MODEL_PPC_RS64,
	CPU_MODEL_PPC_G3,
	CPU_MODEL_PPC_G4,
	CPU_MODEL_PPC_G5,
	CPU_MODEL_PPC_CELL,

	/* CPU_ARCH_S390 */
	CPU_MODEL_S390_S390,
	CPU_MODEL_S390_S390X,

	/* CPU_ARCH_SPARC */

	/* CPU_ARCH_X86 */
	CPU_MODEL_X86_386,
	CPU_MODEL_X86_486,
	CPU_MODEL_X86_586,
	CPU_MODEL_X86_686,
	CPU_MODEL_X86_64
} platform_cpu_model_t;


typedef struct {
	platform_cpu_arch_t             cpu_arch;
	platform_cpu_manufacturer_t     cpu_manufacturer;
	platform_cpu_model_t            cpu_model;
	int                             cpu_count;
	double                          cpu_load;
	double                          cpu_load1;
	double                          cpu_load5;
	double                          cpu_load15;
	char *                          cpu_serial;
	long                            cpu_speed;
} platform_sysconf_cpu_t;

typedef struct {
	char *                          disk_path;
	double                          disk_total;
	double                          disk_free;
} platform_sysconf_disk_t;

typedef struct {
	long                            mem_page_size;
	double                          mem_total;
	double                          mem_used;
	double                          mem_free;
	double                          mem_load;
} platform_sysconf_mem_t;

#define BF_HW_ADDRSTRLEN (72)

typedef struct {
	char *                          net_iface;
	char *                          net_fqdn;
	char                            net_hwaddr[BF_HW_ADDRSTRLEN];
	int                             net_ipv;
	char                            net_ipv4[ 16 /* INET_ADDRSTRLEN */  ];
	char                            net_ipv6[ 46 /* INET6_ADDRSTRLEN */ ];
	long                            net_speed;
} platform_sysconf_net_t;

typedef struct {
	char *                          os_sysname;
	char *                          os_version;
	char *                          os_release;
	char *                          os_machine;
	char *                          os_hostid;
	int                             os_win_service_pack;
} platform_sysconf_os_t;


/* Implementations that all support OS's need to provide. */
int platform_access(const char *pathname, int mode);
int platform_chdir(const char *path);
int platform_chmod(const char *path, int mode);
int platform_chown(const char *path, int uid, int gid);
size_t platform_convert(
	const char *in, size_t inlen,
	char *out, size_t outlen,
	platform_convert_t mode);
char *platform_default_config_file(void);
char *platform_fgets(char *s, int size, FILE *stream);
FILE *platform_fopen(const char *path, const char *mode);
char *platform_getcwd(char *buf, size_t len);
char *platform_getenv(const char *name);
const char *platform_hostname(void);
const char *platform_id(void);
int platform_mkdir(const char *path, int mode);
int platform_open2(const char *path, int flags);
int platform_open3(const char *path, int flags, int mode);
void platform_set_language(const char *newLang);
int platform_set_user(const char *username, const char *password);
int platform_setenv(const char *name, const char *value, int overwrite);
const char *platform_setlocale(const char *locale);
platform_style_t platform_style(void);
int platform_protocol_oobinline(void);
int platform_protocol_read(void *buf, size_t len);
int platform_protocol_write(const void *buf, size_t len);
int platform_rmdir(const char *path);
int platform_spawn(
	const char *dir, char *cmd,
	int timeout, char *indata,
	char *srclist, int startmsg,
	int *timeout_result, int close_pty);
int platform_stat(const char *path, struct stat *buf);
int platform_tempfd(char **namebuf);
char *platform_tempnam(void);
int platform_unlink(const char *pathname);
int platform_unsetenv(const char *name);
char *platform_update_path(void);
int platform_utime(const char *pathname, struct utimbuf *times);


platform_sysconf_cpu_t *    platform_sysconf_cpu_new(void);
platform_sysconf_disk_t *   platform_sysconf_disk_new(const char *disk_path);
platform_sysconf_mem_t *    platform_sysconf_mem_new(void);
platform_sysconf_net_t *    platform_sysconf_net_new(void);
platform_sysconf_os_t *     platform_sysconf_os_new(void);

/* Macros that help when dealing with IPv6 */
#define BF_SA_TO_IPV4(sa) (& (((const struct sockaddr_in *)(sa))->sin_addr) )
#define BF_SA_TO_IPV6(sa) (& (((const struct sockaddr_in6 *)(sa))->sin6_addr) )
#define BF_IPV4_FROM_IPV6(in6) ( (const struct in_addr *) &((in6)->s6_addr)[12] )

#define BF_IS_SAME_IPV4(i4addr1,i4addr2) \
		(*((uint32_t *)(i4addr1)) == *((uint32_t *)(i4addr2)))
#define BF_IS_SAME_IPV6(i6addr1,i6addr2) \
		( IN6_ARE_ADDR_EQUAL((i6addr1),(i6addr2)) )
#define BF_IS_SAME_IPV4_AS_IPV6(i4addr,i6addr) \
		( BF_IS_SAME_IPV4(i4addr, BF_IPV4_FROM_IPV6(i6addr)) )


#define platform_sysconf_cpu_destroy(x) \
	do { \
		platform_sysconf_cpu_t *sc_cpu = x; \
		if (NULL != sc_cpu) { \
			free(sc_cpu->cpu_serial); \
			free(sc_cpu); \
		} \
	} while (0)

#define platform_sysconf_disk_destroy(x) \
	do { \
		platform_sysconf_disk_t *sc_disk = x; \
		if (NULL != sc_disk) { \
			free(sc_disk->disk_path); \
			free(sc_disk); \
		} \
	} while (0)

#define platform_sysconf_mem_destroy(x) \
	do { \
		platform_sysconf_mem_t *sc_mem = x; \
		if (NULL != sc_mem) { \
			free(sc_mem); \
		} \
	} while (0)

#define platform_sysconf_net_destroy(x) \
	do { \
		platform_sysconf_net_t *sc_net = x; \
		if (NULL != sc_net) { \
			free(sc_net->net_iface); \
			free(sc_net->net_fqdn); \
			free(sc_net); \
		} \
	} while (0)

#define platform_sysconf_os_destroy(x) \
	do { \
		platform_sysconf_os_t *sc_os = x; \
		if (NULL != sc_os) { \
			free(sc_os->os_sysname);	\
			free(sc_os->os_version);	\
			free(sc_os->os_release);	\
			free(sc_os->os_hostid);	\
			free(sc_os->os_machine); \
			free(sc_os);	\
		} \
	} while (0)


/* Implementations that are trivial on one platform or another. */
#ifdef WIN32
BOOL IsOrigUser(void);
extern int win_sock;
#define platform_alarm(delay) /* Not supported */
#define platform_close(fd) _close(fd)
#define platform_closesocket(fd) closesocket(fd)
#define platform_freeenv(val) free(val)
void platform_map_clear(void);
int platform_map_drives(const char *);
#define platform_openpty() (1)
#define platform_protocol_has_socket() (win_sock > 0)
#define platform_read(fd,buf,len) _read(fd,buf,len)
int platform_reexec_client(void);
void platform_reexec_server(void);
void platform_release_credentials(void);
#define platform_signals_catch(who) /* Not needed */
#define platform_signals_release() /* Not needed */
#define platform_sleep(seconds) Sleep((seconds) * 1000)
void platform_unmap_drives(int);
int platform_utf8_is_console(void);
#define platform_utf8_is_native() (BFCONF_EXISTS(disable_transcode))

#else /* not WIN32 */
#define platform_alarm(delay) alarm(delay)
#define platform_close(fd) close(fd)
#define platform_closesocket(fd) close(fd)
#define platform_freeenv(val) /* Not needed */
#define platform_map_clear() /* Not needed */
#define platform_map_drives(mapStr) (0)
int platform_openpty(void);
int platform_protocol_has_socket(void);
#define platform_read(fd,buf,len) read(fd,buf,len)
#define platform_reexec_client() (1)
#define platform_reexec_server() /* Not needed */
#define platform_release_credentials() /* Not needed */
void platform_signals_catch(const char *who);
void platform_signals_release();
#define platform_sleep(seconds) sleep(seconds)
void platform_unmap_drives(int);
#define platform_utf8_is_console() (utf8_is_native)
#define platform_utf8_is_native() (utf8_is_native)

#endif /* WIN32 or not */


#ifndef HAVE_SETENV
int bf_setenv(const char *name, const char *value, int overwrite);
#define setenv(name,value,overwrite) bf_setenv(name,value,overwrite)
#endif /* HAVE_SETENV */


#endif /* PLATFORM_H */

