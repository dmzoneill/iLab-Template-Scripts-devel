/*
Copyright (C)2007-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef REQUEST_H
#define REQUEST_H

/* #define REQUEST_DEBUG */

void request_new(void);
void request_destroy(void);
int request_size(void);
void request_dump(void);
void request_put(const char *, char *);
void request_put_binary(const char *, void *, size_t);
void request_put_stream(const char *, void *, size_t);
int request_del(const char *);
void request_del_creds(void);
int request_has(const char *);
char *request_get(const char *);
void *request_get_binary(const char *, size_t *);
int request_get_stream(const char *);

void *request_serialize(size_t *);
int request_deserialize(const void *);

#endif /* REQUEST_H */
