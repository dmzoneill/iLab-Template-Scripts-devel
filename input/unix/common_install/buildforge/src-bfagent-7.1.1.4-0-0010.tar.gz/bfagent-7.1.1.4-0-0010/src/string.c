/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved.
IBM, Inc. owns the copyright and other intellectual
property rights in this software. Duplication or use of the
Software is not permitted except as expressly provided in a
written agreement between your company and IBM, Inc.
*/

#define BF_USE_REGEX
#include "bf_agent.h"

#define RE_FLAG_BYTES  (1 << 0)
#define RE_FLAG_ICASE  (1 << 1)
#define RE_FLAG_PCRE   (1 << 2)


/* memrchr is usually only available on GNU systems. */
#ifndef HAVE_MEMRCHR
void *bf_memrchr(const void *s, int c, size_t n)
{
	const uint8_t *start = s;
	const uint8_t *p = &start[n];
	while (--p >= start) {
		if (*p == (uint8_t)c)
			return (void *)p;
	}
	return NULL;
}
#endif

/*
 * A (slow) implementation of strdup(3), just in case your C library
 * does not have it.
 */
#ifndef HAVE_STRDUP
char *BFStrDup(const char *src)
{
	size_t len = strlen(src) + 1;
	char *dst = malloc(len);
	memcpy(dst, src, len);
	return dst;
}
#endif /* HAVE_STRDUP */


/*
 *  function to lowercase a string.
 *  modifies the original string and returns it.
 */
char *LowerString(char *src)
{
	if (src) {
		char *p = src;
		while ('\0' != *p) {
			*p = (char)tolower(*p);
			++p;
		}
	}
	return src;
}

/*
 *  function to switch all \'s to /'s
 *  modifies the original string and returns it.
 */
char *toForwardSlashes(char *src)
{
	if (NULL != src) {
		char *p = src;
		while (NULL != ( p = strchr(p, '\\') )) {
			*p++ = '/';
		}
	}
	return src;
}

/*
 *  function to switch all /'s to \'s
 *  modifies the original string and returns it.
 */
char *toBackSlashes(char *src)
{
	if (src) {
		char *p = src;
		while (NULL != ( p = strchr(p, '/') )) {
			*p++ = '\\';
		}
	}
	return src;
}

/*
 *  function to trim ending newline chars
 *  modifies the original string and returns it.
 *  won't chop a string with an embedded newline
 *  that doesn't end in a newline.
 */
char *RemoveTrailingNewline(char *src)
{
	if (NULL != src && '\0' != *src) {
		char *p = &src[strlen(src) - 1];
		while (p >= src && ('\r' == *p || '\n' == *p)) { --p; }
		p[1] = '\0';
	}
	return src;
}

/*
 *  function to trim trailing newline chars
 *  modifies the original string and returns it.
 *  will chop a string on the first newline.
 */
char *RemoveNewline(char *src)
{
	if (NULL != src && '\0' != *src) {
		char *p = strpbrk(src, "\r\n");
		if (NULL != p) { *p = '\0'; }
	}
	return src;
}

/*
 *  function to see if there's an EOL sequence in a string
 *  since any platform will have a NL as part of EOL, we'll
 *  just look for that char. this could be enhanced to handle
 *  EOL differently on windows/unix.
 */
char *HasEOL(char *src)
{
	return strchr(src, '\n');
}

/*
 *  function to change repeated /'s into a single /
 *  modifies the original string and returns it.
 */
char *CollapseSlashes(char *src)
{
	char *p, *q;

	if (NULL == src || '\0' == *src) { return src; }

	p = src;
	while (NULL != ( q = strchr(p, '/') )) {
		p = ++q;
		if ('/' == *q) {
			do { ++q; } while ('/' == *q);
			memmove(p, q, strlen(q) + 1);
		}
	}

	return src;
}

/* strip leading \'s off of a pathname when there is a drive letter
 * involved. If there doesn't appear to be a drive letter, then
 * make sure there are no more than two \'s leading the way.
 * we have to handle windows UNC pathnames as well, which are tedious.
 *
 * Valid:     e:\foo\bar
 * Valid:     \\foo\bar
 * Invalid:   \e:\foo\bar
 * Invalid:   \\foo:\bar
 * Invalid:   \\foo (UNC must have 2 components)
 *
 * also cleans up any doubled backslashes left over in the path names.
 * Invalid paths are returned as-is.
 */
char *clean_win_slashes(char *src) {
	char *p, *q;

	if (NULL == src || '\0' == *src) { return src; }

	p = strchr(src, ':');
	if (NULL != p) {
		if (p == src) { return src; }
		--p;
		if (!isalpha(*p)) { return src; }
		if (p > src) {
			for (q=src; q<p; ++q) {
				if (*q != '\\') { return src; }
			}
			memmove(src, p, strlen(p) + 1);
		}
		p = &src[2];
	} else if ('\\' == *src) {
		/* If the string begins with one or more backslashes, then it
		 * must match the pattern /^\\+[^\\]+\\+[^\\]+/ to be valid.
		 * If it is, then we protect the first backslash such that if
		 * there are 2 or more, then 2 will be kept instead of just 1.
		 */
		p = q = src;
		do { ++q; } while ('\\' == *q);
		q = strchr(q, '\\');
		if (NULL != q) {
			do { ++q; } while ('\\' == *q);
			if ('\0' != *q) { p = &src[1]; }
		}
	} else {
		p = src;
	}

	/* p has been positioned at the first character where we want to
	 * start eliminating doubled slashes.
	 */
	while (NULL != ( q = strchr(p, '\\') )) {
		p = ++q;
		while ('\\' == *q) { ++q; }
		if (q > p) {
			memmove(p, q, strlen(q) + 1);
		}
	}
	return src;
}

/*
 *  function to chomp trailing /'s, as well as \r\n's
 *  modifies the original string and returns it.
 */
char *ChompSlash(char *src)
{
	char *p;
	char sep;

	if (NULL == src || '\0' == *src) { return src; }
	src = RemoveNewline(src);
	sep = PathSeparator();

	p = &src[strlen(src) - 1];
	while (p > src && sep == *p) { --p; }
	p[1] = '\0';
	return src;
}

/*
 *  function to clean up a string and make it a
 *  nice unix pathname.
 *  modifies the original string and returns it.
 */
char *CleanUnixPath(char *src)
{
	if (NULL == src || '\0' == *src) { return src; }
	return ChompSlash(CollapseSlashes( toForwardSlashes(src) ));
}


/*
 *  function to clean up a string and make it a
 *  nice windows pathname.
 *  modifies the original string and returns it.
 */
char *CleanWindowsPath(char *src)
{
	return (NULL != src && '\0' != *src)
		? clean_win_slashes(ChompSlash(toBackSlashes(src)))
		: src;
}

char *CleanCygwinPath(char *src)
{
	if (NULL == src || '\0' == *src) { return src; }
	return toForwardSlashes(clean_win_slashes(ChompSlash(toBackSlashes(src))));
}

/*
 * function to clean up a path for the current platform
 *
 */
char *CleanPath(char *src)
{
	if (NULL == src || '\0' == *src) { return src; }
	switch (platform_style()) {
		case STYLE_WINDOWS:
			return CleanWindowsPath(src);
		case STYLE_CYGWIN:
			return CleanCygwinPath(src);
		default: 
			/* Assume UNIX */
			return CleanUnixPath(src);
	}
}


char PathSeparator(void)
{
	switch (platform_style()) {
		case STYLE_WINDOWS:
			return '\\';
		case STYLE_CYGWIN:
			return '/';
		case STYLE_VOS:
			return '?';
		default:
			/* Assume UNIX */
			return '/';
	}
}

char EnvPathSeparator(void)
{
	return (platform_style() == STYLE_WINDOWS) ? ';' : ':';
}

char *shiftArgs(char **p) {
	int	i;
	char	*arg;

	arg = p[0];
	for (i = 0 ; p[i] ; i++)
		p[i] = p[i+1];
	return arg;
}

void freeArgs(char **p) {
	if (NULL != p) {
		char **q = p;
		while (NULL != *q) { free(*q++); }
		free(p);
	}
}

char *nextQuote(char *src, char ch) {
	while ('\0' != *src) {
		if (*src == ch) { return src; }
		if (*src == '\\') {
			memmove(src, &src[1], strlen(src));
		}
		++src;
	}
	return NULL;
}



static char **getArgsImpl(
		char *cl,
		int num,
		const char *sep,
		int ignore_escapes)
{
    char **result;
	char *p;
	char *mark = cl;
	size_t len;
    int i = 0;

    if (NULL == cl || '\0' == *cl) { return NULL; }
	if (num <= 0 || num > 127) { num = 127; }

    result = calloc(sizeof(char *), (size_t)num + 1);
	--num;

	while (1) {
		/* If we reached the end of the string, then we're done. */
		if ('\0' == *cl) { goto done; }
			
        /* Skip over leading whitespace and mark the location of
		 * the first non-whitespace character we find.
		 */
		while (NULL != strchr(sep, *cl)) {
			++cl;
			if ('\0' == *cl) { goto done; }
		}
		mark = cl;
		len = strlen(cl);

		/* If we only have room for one more arg, then don't split it. */
		if (i == num) { goto last_arg; }

		/* Scan for the end of the current arg. */
		while (1) {
			/* If we hit an unquoted separator, that ends the arg */
			if (NULL != strchr(sep, *cl)) { break; }

			/* If we hit a single-quote ('), then remove it and scan for its
			 * match.  If no match is found, then consume everything that is
			 * left as the last arg.  Otherwise, remove the matching quote
			 * and resume the normal scan.
			 */
			if ('\'' == *cl) {
				memmove(cl, &cl[1], len--);
				p = strchr(cl, '\'');
				if (NULL == p) { goto last_arg; }

				/* Handle matching quote */
				len -= (p - cl);
				cl = p;
				memmove(cl, &cl[1], len--);
				continue;
			}

			/* Double-quote (") behaves identically to single-quote (')
			 * when ignore_escapes is non-zero.  However, when it is zero,
			 * double-quoted sections of the string will interpret
			 * backslash (\) characters as escapes and remove them,
			 * skipping over whatever the next character is.  If the
			 * backslash is the last character, then it is simply
			 * removed.
			 */
			if ('"' == *cl) {
				memmove(cl, &cl[1], len--);
				if (ignore_escapes) {
					p = strchr(cl, '"');
					if (NULL == p) { goto last_arg; }
				} else {
					do {
						p = strpbrk(cl, "\\\"");
						if (NULL == p) { goto last_arg; }
						if ('"' == *p) { break; }

						/* Handle backslash */
						len -= (p - cl);
						cl = p;
						memmove(cl, &cl[1], len--);
						if ('\0' == *cl) { goto last_arg; }
						++cl;
						--len;
						continue;
					} while ('"' != *cl);
				}

				/* Handle matching quote */
				len -= (p - cl);
				cl = p;
				memmove(cl, &cl[1], len--);
				continue;
			}

			/* Nothing special about this char; keep scanning. */
			++cl;
			--len;
		}

		/* Copy the arg's value into the result array.  The cl pointer
		 * indicates where this argument ends.
		 */
		len = (size_t)(cl - mark);
		p = malloc(len + 1);
		if (NULL == p) { goto done; }
		if (len > 0) { memcpy(p, mark, len); }
		p[len] = '\0';
        result[i++] = p;
    }

	/* Save off whatever is left as the last arg. */
last_arg:
	if ('\0' != *mark) { result[i++] = strdup(mark); }

	/* Put a NULL at the end of the arg list */
done:
	result[i] = NULL;
    return result;
}


static const char *SEPS = " \t\n";
char **getArgs(char *cl) {
	return getArgsImpl(cl, 0, SEPS, 0);
}
char **getArgsI(char *cl) {
	return getArgsImpl(cl, 0, SEPS, 1);
}
char **getArgsN(char *cl, int num) {
	return getArgsImpl(cl, num, SEPS, 0);
}
char **getArgsC(char *cl, char c) {
	char seps[2];
	seps[0] = c;
	seps[1] = '\0';
	return getArgsImpl(cl, 0, seps, 0);
}


/* Allocates a string containing the concatenated and cleaned directory
 * name.
 */
char *xlate_build_path(const char *root, const char *tag, const char *dir)
{
	size_t rlen = strlen(root);
	size_t tlen = strlen(tag);
	size_t dlen = strlen(dir);
	char *buf = calloc(1, rlen + tlen + dlen + 16);
	format_message(buf, "%s/%s/%s", root, tag, dir);
	CleanPath(buf);
	return buf;
}

/* part of some string based on content */
char *bf_strpart(char *pstr, char *psub) {
	char *temp;
	char *newstr;

	if (!pstr)
		return NULL;

	if (psub && *psub != '\0') {
		if ((temp = strstr(pstr, psub))) {
			newstr = calloc(1, temp - pstr + 1);
			strncpy(newstr, pstr, temp - pstr);
			return newstr;
		}
	}
	return strdup(pstr);
}

#ifdef HAVE_LIBPCRE
static const unsigned char *pcre_tables = NULL;
static int pcre_has_utf8 = 0;
#endif /* HAVE_LIBPCRE */

void bf_regex_setlocale(void) {
#ifdef HAVE_LIBPCRE
	if (NULL != pcre_tables) {
		/* We cast to discard the const qualifier.  This is
		 * a weirdness with the PCRE API, that it allocates
		 * the tables with pcre_malloc and makes it the
		 * caller's responsibility to free the pointer, but
		 * marks it const because it is not normally something
		 * you would either need or want to do.  In our case,
		 * we don't want to keep this information around if we
		 * are changing locales.
		 */
		pcre_free((void *)pcre_tables);
	}
	pcre_tables = pcre_maketables();
	pcre_config(PCRE_CONFIG_UTF8, &pcre_has_utf8);
#endif /* HAVE_LIBPCRE */
}


static bf_regex_t *bf_regex_compile(
		const char *pattern,
		int flags)
{
	bf_regex_t *re = calloc(1, sizeof(bf_regex_t));
	if (NULL == re) { return NULL; }
	re->re_flags = flags;

	if (flags & RE_FLAG_PCRE) {
#ifdef HAVE_LIBPCRE
		const char *error;
		int erroffset;
		int pcre_flags = 0;

#ifdef PCRE_NEWLINE_ANYCRLF
		pcre_flags |= PCRE_NEWLINE_ANYCRLF;
#endif /* PCRE_NEWLINE_ANYCRLY */

		if (flags & RE_FLAG_ICASE) {
			pcre_flags |= PCRE_CASELESS;
		}
		if (pcre_has_utf8 && !(flags & RE_FLAG_BYTES)) {
			pcre_flags |= PCRE_UTF8;
		}

		re->re_pcre = pcre_compile(
				pattern,
				pcre_flags,
				&error,
				&erroffset,
				pcre_tables);
		if (NULL == re->re_pcre) {
			send_msg("ERROR", "RegexCompileError", "is", erroffset, error);
			free(re);
			return NULL;
		}

#else /* !HAVE_LIBPCRE */
		send_msg("ERROR", "RegexCompileError", "ik", 0, "RegexNoPCRE");
		free(re);
		return NULL;
#endif /* HAVE_LIBPCRE/! */
	} else {
		int posix_flags = REG_EXTENDED;
		int rc;

		if (flags & RE_FLAG_ICASE) {
			posix_flags |= REG_ICASE;
		}
		re->re_posix = calloc(1, sizeof(regex_t));
		if (NULL == re->re_posix) {
			free(re);
			return NULL;
		}

		rc = regcomp(re->re_posix, pattern, posix_flags);
		if (0 != rc) {
			char error[256];
			regerror(rc, re->re_posix, error, 256);
			send_msg("ERROR", "RegexCompileError", "is", rc, error);
			free(re->re_posix);
			free(re);
			return NULL;
		}
	}

	return re;
}


void bf_regex_free(bf_regex_t *srch) {
	if (srch->re_flags & RE_FLAG_PCRE) {
#ifdef HAVE_LIBPCRE
		pcre_free(srch->re_pcre);
#endif /* HAVE_LIBPCRE */
	} else {
		regfree(srch->re_posix);
	}
	free(srch);
}


int bf_regex_prep(
	bf_regex_t **lhs,
	char **spat,
	char **rhs,
	char **target,
	char *buf)
{
	char *repl, *srch, *src, delim;
	int flags = 0;

	/* first char is the delimiter character */
	*lhs = NULL;
	*rhs = *target = NULL;
	srch = buf;
	delim = *srch++;

	/* srch is the start of the regex, now we need to find the start of the replacement */
	/* scan the search pattern for the ending delimiter */
	for (repl=srch; '\0' != *repl && delim != *repl; ++repl) {
		if (*repl == '\\') {
			if ('\0' == *++repl) { break; }
		}
	}

	/* srch string was empty or never terminated */
	if (repl == srch || '\0' == *repl) {
		*target = strdup("RegexBadSrch");
		return -1;
	}

	/* we found the start of the replacement pattern */
	*repl++ = 0;
	*spat = strdup(buf);

	/* scan the replacement pattern for the ending delimiter */
	for (src = repl ; *src && *src != delim ; src++) {
		if (*src == '\\') {
			if ('\0' == *++src) { break; }
		}
	}
	if (!*src) {
		*target = strdup("RegexBadRepl");
		free(*spat);
		*spat = NULL;
		return -1;
	}
	*src++ = 0;

	while ('\0' != *src && !isspace(*src & 0xFF)) {
		switch (*src++) {
			case 'i':
				flags |= RE_FLAG_ICASE;
				break;
			case 'p':
				flags |= RE_FLAG_PCRE;
				break;
		}
	}

	/* eat up source leading whitespace */
	while ('\0' != *src && isspace(*src & 0xFF)) { ++src; }

	/* now expand the source and replacement string for env vars */
	*rhs = env_expand_var(repl, 1);
	*target = env_expand_var(src, 0);

	/* now compile the search string */
	srch = env_expand_var(srch, 0);
	*lhs = bf_regex_compile(srch, flags);
	free(srch);
	if (NULL == *lhs) {
		free(*spat);
		free(*rhs);
		free(*target);
		*spat = *rhs = NULL;
		*target = strdup("RegexBadExpr");
		return -1;
	}
	return 0;
}


/* This performs a regular expression match against a buffer.  The
 * result is either NULL (for a non-match), or an array of POSIX
 * regmatch_t structures.  This format is used even if PCRE is
 * used, as that way the caller only needs to handle one format.
 */
static regmatch_t *bf_regex_match(
		const char *buf,
		const bf_regex_t *srch)
{
#ifdef HAVE_LIBPCRE
	int pcre_groups[MAX_REGEX_SUBSTRINGS * 3];
#endif /* HAVE_LIBPCRE */
	regmatch_t *posix_groups;
	int rc;

	if (srch->re_flags & RE_FLAG_PCRE) {
#ifdef HAVE_LIBPCRE
		int group;
		rc = pcre_exec(
				srch->re_pcre,
				NULL,
				buf,
				(int)strlen(buf),
				0,
				0,
				pcre_groups,
				MAX_REGEX_SUBSTRINGS * 3);
		if (rc <= 0) { return NULL; }

		/* Map the groups returned by PCRE to the POSIX format */
		posix_groups = calloc(MAX_REGEX_SUBSTRINGS, sizeof(regmatch_t));
		for (group = 0; group < rc; ++group) {
			posix_groups[group].rm_so = pcre_groups[group << 1];
			posix_groups[group].rm_eo = pcre_groups[(group << 1) + 1];
		}
		for (group = rc; group < MAX_REGEX_SUBSTRINGS; ++group) {
			posix_groups[group].rm_so = -1;
		}
		return posix_groups;
#else /* !HAVE_LIBPCRE */
		/* PARANOID -- bf_regex_prep should fail, thus preventing this */
		return NULL;
#endif /* HAVE_LIBPCRE */
	}

	posix_groups = calloc(MAX_REGEX_SUBSTRINGS, sizeof(regmatch_t));
	rc = regexec(
			srch->re_posix,
			buf,
			MAX_REGEX_SUBSTRINGS,
			posix_groups,
			0);
	if (0 != rc) {
		free(posix_groups);
		return NULL;
	}
	return posix_groups;
}



char *bf_regex_apply(
		const char *buf,
		const bf_regex_t *srch,
		const char *repl)
{
	regmatch_t *posix_groups = NULL;
	int group, start, len;
	const char *p;
	char c;
	char *out = NULL;
	size_t idx = 0;
	size_t size = 256;

	/*
	 * srch points to a structure that contains either a regex_t
	 * from the POSIX regex functions or a pcre * from the PCRE
	 * library.  If we use PCRE, the group results are mapped
	 * back into the posix groups structure so that we only need
	 * one code path on this side of things.
	 *
	 * repl points to a an expanded replacement pattern
	 *
	 * src points to the expanded source string
	 */
	posix_groups = bf_regex_match(buf, srch);
	if (NULL == posix_groups) { goto out_of_memory; }

	/*
	 * parse the replacement string to substitute \# replacements
	 */

	/* First, alloc a buffer (minimum size 256) and copy the
	 * part of the source string that comes before the part
	 * that matched.
	 */
	idx = posix_groups[0].rm_so;
	while (size < idx) { size <<= 1; }
	out = calloc(1, size);
	if (NULL == out) { goto out_of_memory; }
	memcpy(out, buf, idx);

	while (NULL != ( p = strchr(repl, '\\') )) {
		int len = p - repl;
		if (len > 0) {
			BUFFER_ENSURE_CAPACITY(&out, &size, idx + len);
			memcpy(&out[idx], repl, len);
			idx += len;
		}

		/* Handle malformed replacement string with \ at the end */
		if (*++p == '\0') {
			BUFFER_ENSURE_CAPACITY(&out, &size, idx + 1);
			out[idx] = '\0';
			break;
		}

		/* Check for and handle backrefs like \1 */
		group = *p - '0';
		if (group >= 1 && group <= 9) {
			start = posix_groups[group].rm_so;
			len = posix_groups[group].rm_eo - start;
			if (start < 0 || len <= 0) { continue; }

			BUFFER_ENSURE_CAPACITY(&out, &size, idx + len);
			memcpy(&out[idx], &buf[start], len);
			idx += len;
			continue;
		}

		/* wasn't a \1 pattern, so just dequote it */
		BUFFER_ENSURE_CAPACITY(&out, &size, idx + 1);
		switch (c = *p) {
			case 'a': c = '\a'; break;
			case 'b': c = '\b'; break;
			case 'f': c = '\f'; break;
			case 'n': c = '\n'; break;
			case 'r': c = '\r'; break;
			case 't': c = '\t'; break;
		}
		out[idx++] = c;
	}

	if ('\0' != *repl) {
		len = (int)strlen(repl);
		BUFFER_ENSURE_CAPACITY(&out, &size, idx + len);
		memcpy(&out[idx], repl, len);
		idx += len;
	}

	p = &buf[posix_groups[0].rm_eo];
	len = (int)strlen(p) + 1;
	BUFFER_ENSURE_CAPACITY(&out, &size, idx + len);
	memcpy(&out[idx], p, len);
	idx += len;

out_of_memory:
	if (NULL != posix_groups) { free(posix_groups); }
	return out;
}


/*	OpenBSD: strlcpy.c,v 1.8 2003/06/17 21:56:24 millert Exp	*/

/*
 * Copyright (c) 1998 Todd C. Miller <Todd.Miller@courtesan.com>
 *
 * Permission to use, copy, modify, and distribute this software for any
 * purpose with or without fee is hereby granted, provided that the above
 * copyright notice and this permission notice appear in all copies.
 *
 * THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES
 * WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF
 * MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR
 * ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES
 * WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN
 * ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 */

/*
 * Copy src to string dst of size siz.  At most siz-1 characters
 * will be copied.  Always NUL terminates (unless siz == 0).
 * Returns strlen(src); if retval >= siz, truncation occurred.
 */
#ifndef HAVE_STRLCPY
size_t
strlcpy(char *dst, const char *src, size_t siz)
{
	register char *d = dst;
	register const char *s = src;
	register size_t n = siz;

	/* Copy as many bytes as will fit */
	if (n != 0 && --n != 0) {
		do {
			if ((*d++ = *s++) == 0)
				break;
		} while (--n != 0);
	}

	/* Not enough room in dst, add NUL and traverse rest of src */
	if (n == 0) {
		if (siz != 0)
			*d = '\0';		/* NUL-terminate dst */
		while (*s++)
			;
	}

	return s - src - 1;	/* count does not include NUL */
}
#endif


/*
 * bf_strtok allows the use of strtok_r accross all
 * platforms with a cleaner interface.
 *
 * Called 3 ways:
 *
 *     - initial call (string, delim, &NULL, &NULL); sets up
 *       the dereferenced pointer and makes the initial
 *       call to strtok_r (3rd and 4th param: allocated
 *       char *bf_ptr=NULL; passed &bf_ptr)
 *
 *     - item call    (NULL, delim, &bf_rptr, &bf_sptr); the
 *       non-NULL values in the 3rd and 4th parameters cause
 *       the reuse of the dereferenced 3rd pointer and the
 *       traversing of the original string
 *
 *     - cleanup call (NULL, NULL, NULL, &bf_sptr); the three
 *       NULL parameter values indicate the cleanup mode.
 *
 * NOTE: If delim is NULL but either the 1st or 3rd argument is
 *   not NULL, then nothing happens, and NULL is returned.
 *
 * NOTE: The cleanup of the allocated memory happens automatically
 *   when the returned string is NULL (this means that an explicit
 *   cleanup call is not needed if the entire string is traversed)
 */

#ifndef HAVE_STRTOK_R
#include "strtok_r.c"
#endif

char *bf_strtok(char *s, const char *delim, char **ptrptr, char **saveptr) {
	char *lstr = NULL;

	if (delim == NULL) {
		if (s == NULL && ptrptr == NULL && *saveptr != NULL) {
			free(*saveptr);
			*saveptr = NULL;
		}
		return NULL;
	}

	if (*saveptr == NULL) {
		*saveptr = *ptrptr = calloc(1, strlen(s)+1);
		lstr = strtok_r(s, delim, ptrptr);
	} else {
		lstr = strtok_r(NULL, delim, ptrptr);
	}

	if (lstr == NULL && *saveptr != NULL) {
		free(*saveptr);
		*saveptr=NULL;
	}

	return lstr;
}

char *bf_expose_special_chars(char *str) {
	char	*p;

	p = calloc(1, BFBUFSIZ);
	while (*str) {
		switch (*str) {
			case '\n':
				strcat(p, "<LF>");
				break;
			case '\r':
				strcat(p, "<CR>");
				break;
			case '\t':
				strcat(p, "<^I>");
				break;
			case '\b':
				strcat(p, "<^H>");
				break;
			default:
				if (*str < ' ')
					sprintf(&str[strlen(str)], "%02x", *str);
				else
					p[strlen(p)] = *str;
				break;
		}
		str++;
	}
	return p;
}

/*
#define TEST(fn,in,out) do { \
	strcpy(buf1, in); \
	strcpy(buf2, buf1); \
	fn(buf2); \
	printf("%s %s(\"%s\") -> \"%s\" [exp=\"%s\"]\n", \
			strcmp(buf2, out) ? "FAIL" : "pass", \
			#fn, buf1, buf2, out); \
} while (0)

void string_unit_test(void) {
	char buf1[1024], buf2[1024];
	TEST(ChompSlash, "////abc////def", "////abc////def");
	TEST(ChompSlash, "////abc////def\\", "////abc////def\\");
	TEST(ChompSlash, "////abc////def////", "////abc////def");
	TEST(CollapseSlashes, "////abc////def", "/abc/def");
	TEST(CollapseSlashes, "////abc/\\//def\\\\//", "/abc/\\/def\\\\/");
	TEST(CollapseSlashes, "a////////////b", "a/b");
	TEST(CollapseSlashes, "a\\\\\\\\\\\\b", "a\\\\\\\\\\\\b");
	TEST(toForwardSlashes, "abc", "abc");
	TEST(toForwardSlashes, "////abc////def////", "////abc////def////");
	TEST(toForwardSlashes, "////abc\\\\\\\\def////", "////abc////def////");
	TEST(toForwardSlashes, "\\///abc//\\/def///\\", "////abc////def////");
	TEST(toBackSlashes, "abc", "abc");
	TEST(toBackSlashes, "//abc//def//", "\\\\abc\\\\def\\\\");
	TEST(toBackSlashes, "//abc\\\\def//", "\\\\abc\\\\def\\\\");
	TEST(toBackSlashes, "\\/abc\\/def//\\/", "\\\\abc\\\\def\\\\\\\\");
	TEST(clean_win_slashes, "c:///Program Files//IBM//", "c:///Program Files//IBM//");
	TEST(clean_win_slashes, "C:\\Program Files\\IBM\\", "C:\\Program Files\\IBM\\");
	TEST(clean_win_slashes, "\\\\C:\\abc", "C:\\abc");
	TEST(clean_win_slashes, "\\\\\\C:\\abc\\\\", "C:\\abc\\");
	TEST(clean_win_slashes, "\\\\\\UNC\\\\\\path\\\\\\", "\\\\UNC\\path\\");
	TEST(clean_win_slashes, "\\\\\\INVALID\\", "\\INVALID\\");
	TEST(clean_win_slashes, "\\\\INVALID:\\\\abc\\\\", "\\\\INVALID:\\\\abc\\\\");
}
*/


