/*
Copyright (C)2007-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef CONVERT_H
#define CONVERT_H

/* This placeholder is used for the buffer length to indicate that
 * we want the entire contents of the source buffer, up to and including
 * the terminating NUL character.  That is, specifying CONVERT_ALL is
 * equivalent to specifying strlen(buf)+1 or wcslen(wbuf)+1 as
 * appropriate.
 */
#define CONVERT_ALL ((size_t)-1)

/* Makes certain that this alleged UTF-8 data is strictly well-formed.
 * If replace is non-zero, then each invalid byte is replaced with
 * 0x3F ('?').  The following illegal sequences are detected:
 * - extension byte that isn't part of a well-formed sequence
 * - incomplete multi-byte sequence
 * - overlong encoding (such as 0xE0 0x90 0x80 instead of just 0xD0 0x80)
 * - code point in the UTF-16 surrogate range (U+D800 - U+DFFF)
 * - code point exceeds U+10FFFF
 * - code point is U+xxFFFE or U+xxFFFF
 *
 * On z/OS, this function expects to be given UTF-8 that has been
 * transcoded to EBCDIC.  Since it needs to work on the UTF-8 bytes
 * values directly, it transcodes back to real UTF-8 to perform
 * its processing, then transcodes the result back to EBCDIC.
 *
 * The return value is the number of illegal bytes encountered, or 0 if
 * the data was already well-formed.
 */
unsigned int convert_utf8_clean(char *buf, size_t len, int replace);


/* Converters that operate on a user-supplied buffer.  Most error
 * conditions result in incomplete processing of the buffer.  It is
 * the caller's responsibility to make certain that the data is
 * well-formed and does not end within a character.  Failure to do
 * so may result in a shift phase error when dealing with a native
 * encoding.
 */
#define convert_utf8_to_native(in,inlen,out,outlen) platform_convert(in,inlen,out,outlen,CONVERT_UTF8_TO_NATIVE)
#define convert_native_to_utf8(in,inlen,out,outlen) platform_convert(in,inlen,out,outlen,CONVERT_NATIVE_TO_UTF8)
#define convert_utf8_to_console(in,inlen,out,outlen) platform_convert(in,inlen,out,outlen,CONVERT_UTF8_TO_CONSOLE)
#define convert_console_to_utf8(in,inlen,out,outlen) platform_convert(in,inlen,out,outlen,CONVERT_CONSOLE_TO_UTF8)

/* Given a buffer that contains character data of the specified
 * size, returns the number of bytes that are safe to process as a
 * well-formed unit.  Note that this does not guarantee that the
 */
size_t convert_utf8_find_boundary(const char *in, size_t inlen);
size_t convert_native_find_boundary(const char *in, size_t inlen);
#define convert_console_find_boundary(in, inlen) convert_native_find_boundary(in, inlen)

#ifdef WIN32
/* Windows also has to deal with wide chars and multiple code pages. */

#ifdef CONVERT_USE_STATIC_BUFFER
static wchar_t convert_swbuf[BFBUFSIZ];
#define convert_from_wide(in) (convert_wide_to_utf8(in, CONVERT_ALL, convert_scbuf, BFBUFSIZ), convert_scbuf)
#define convert_to_wide(in) (convert_utf8_to_wide(in, CONVERT_ALL, convert_swbuf, BFBUFSIZ), convert_swbuf)
#endif /* CONVERT_USE_STATIC_BUFFER */

#define convert_utf8_to_wide(in, inlen, out, outlen) (MultiByteToWideChar(CP_UTF8, 0, in, inlen, out, outlen))
#define convert_wide_to_utf8(in, inlen, out, outlen) (WideCharToMultiByte(CP_UTF8, 0, in, inlen, out, outlen, NULL, NULL))
#define convert_native_to_wide(in, inlen, out, outlen) (MultiByteToWideChar(CP_ACP, 0, in, inlen, out, outlen))
#define convert_wide_to_native(in, inlen, out, outlen) (WideCharToMultiByte(CP_ACP, 0, in, inlen, out, outlen, NULL, NULL))
size_t convert_wide_find_boundary(const wchar_t *in, size_t inlen);

/* And just for completeness, here are converters for tchars ... */
#ifdef _UNICODE
#define convert_stbuf convert_swbuf
#define convert_from_tchar(in) (convert_from_wide(in))
#define convert_to_tchar(in) (convert_to_wide(in))
#define convert_utf8_to_tchar(in,inlen,out,outlen) (convert_utf8_to_wide(in,inlen,out,outlen))
#define convert_tchar_to_utf8(in,inlen,out,outlen) (convert_wide_to_utf8(in,inlen,out,outlen))
#define convert_tchar_find_boundary(in,inlen) (convert_wide_find_boundary(in,inlen,out,outlen))
#else /* !_UNICODE */
#define convert_stbuf convert_scbuf
#define convert_from_tchar(in) (convert_from_native(in))
#define convert_to_tchar(in) (convert_to_native(in))
#define convert_utf8_to_tchar(in,inlen,out,outlen) (convert_utf8_to_native(in,inlen,out,outlen))
#define convert_tchar_to_utf8(in,inlen,out,outlen) (convert_native_to_utf8(in,inlen,out,outlen))
#define convert_tchar_find_boundary(in,inlen) (convert_native_find_boundary(in,inlen,out,outlen))
#endif /* _UNICODE */

#endif /* WIN32 */




#ifdef CONVERT_USE_STATIC_BUFFER
static char convert_scbuf[BFBUFSIZ];

/* These are one-shot functions that use the length of the string
 * (including the terminating null) and a static buffer.  The caller
 * must take care to consume the result before any further calls to
 * convert_from_* or convert_to_* functions.
 */
#define convert_to_native(in) (platform_utf8_is_native() ? in : (platform_convert(in, CONVERT_ALL, convert_scbuf, BFBUFSIZ, CONVERT_UTF8_TO_NATIVE), convert_scbuf))
#define convert_from_native(in) (platform_utf8_is_native() ? in : (platform_convert(in, CONVERT_ALL, convert_scbuf, BFBUFSIZ, CONVERT_NATIVE_TO_UTF8), convert_scbuf))
#define convert_to_console(in) (platform_utf8_is_console() ? in : (platform_convert(in, CONVERT_ALL, convert_scbuf, BFBUFSIZ, CONVERT_UTF8_TO_CONSOLE), convert_scbuf))
#define convert_from_console(in) (platform_utf8_is_console() ? in : (platform_convert(in, CONVERT_ALL, convert_scbuf, BFBUFSIZ, CONVERT_CONSOLE_TO_UTF8), convert_scbuf))

#endif /* CONVERT_USE_STATIC_BUFFER */

#ifdef ZOS
void convert_atoe(char *in);
void convert_atoe_l(char *in, size_t len);
void convert_etoa(char *in);
void convert_etoa_l(char *in, size_t len);
#endif /* ZOS */

#endif /* CONVERT_H */

