/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"

/*
 * format a tm struct into a date/time format string
 */
char *formatDate(const char *format, struct tm *when) {
	char *buf = calloc(1, 256);
	strftime(buf, 256, format, when);
	return buf;
}

/*
 * format a stamp into a date/time format string
 */
char *formatDateStamp(const char *format, time_t when) {
	struct tm *tmbuf = localtime(&when);
	return formatDate(format, tmbuf);
}

/*
 * format a stamp into a UTC date/time format string
 */
char *formatUTCDateStamp(const char *format, time_t when) {
	struct tm *tmbuf = gmtime(&when);
	return formatDate(format, tmbuf);
}

/* 
 * expand a .date request into a buffer for an env
 */
char *expandDate(const char *format) {
	time_t now;
	struct tm *tmbuf;

	time(&now);
	tmbuf = localtime(&now);
	return formatDate(format, tmbuf);
}

/* 
 * expand a .gmdate request into a buffer for an env
 */
char *expandGMDate(const char *format) {
	time_t	now;
	struct	tm	*tmbuf;

	time(&now);
	tmbuf = gmtime(&now);
	return formatDate(format, tmbuf);
}

