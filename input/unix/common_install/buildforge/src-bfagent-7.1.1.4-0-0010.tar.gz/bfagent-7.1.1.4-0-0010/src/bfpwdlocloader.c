/*
Copyright (C)2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"
#ifndef WIN32
	#include <dlfcn.h>
#endif

static passwd_locator_ops* myops=NULL;
static int initialized = 0;
static int DEBUG=1;
static char trace_buf[256];
static char* AGENT_FILE = "bfagent.conf";
#ifdef WIN32
typedef passwd_locator_ops* (CALLBACK* InitializationProcedure)(void);
#else 
typedef passwd_locator_ops* (*InitializationProcedure)(void);
#endif

#ifndef WIN32
static int unix_loader_init(const char* prop) {
	InitializationProcedure functionhandle = NULL;
	void *dllhandle=0;
	char function_name[256];
	char *error=NULL, *module_name=NULL, *module_from_conf=NULL, *sep=NULL, *temp=NULL, *word=NULL, *lastword=NULL;

	if (!initialized) {
		strcpy(function_name, prop);
		strcat(function_name, "_locator");
		
		if (DEBUG) {
			sprintf(trace_buf, "Looking for password locator: %s", function_name);
			BFTRACE(trace_buf);
		}

		if (NULL != (module_from_conf = bfconf_get(function_name, NULL))) {

			/* Remove the path to get just "module.dll" */
			sep = "\\/:;=-";
			temp = strdup(module_from_conf);
			for (word = strtok(temp, sep); word; word = strtok(NULL, sep))
				lastword = word;
			
			/* Now remove ".dll" from the end. */
			module_name = strtok(strdup(lastword), ".");
			if (DEBUG) {
				sprintf(trace_buf, "module: %s", module_name);
				BFTRACE(trace_buf);
			}

			/* This allows us to load "module_init" per the struct design. */
			strcpy(function_name, module_name);
			strcat(function_name, "_init");
			
			if (DEBUG) {
				sprintf(trace_buf, "Loading module: %s", module_from_conf);
				BFTRACE(trace_buf);
			}

			/* Try to open the .so library configured. */
			dllhandle = dlopen(module_from_conf, RTLD_NOW);

			if (!dllhandle) {
				/* Try the default */
				dllhandle = dlopen(module_from_conf, RTLD_GLOBAL| RTLD_LAZY);
				if (!dllhandle) {
					if ((error = dlerror()) != NULL)  {
						fputs(error, stderr);
						return -1;
					}
				  return -2;
				}
			}
		
			/* Load the _init method. */
			if (DEBUG) {
				sprintf(trace_buf, "Loading procedure %s.", function_name);
				BFTRACE(trace_buf);
			}
			functionhandle = (InitializationProcedure)dlsym(
					dllhandle, function_name);   
			  
			if (!functionhandle) {
				if ((error = dlerror()) != NULL)  {
					fputs(error, stderr);
					dlclose(dllhandle);
					return -3;
				}
			}
			
			/* Call the function */
			if ((myops = (*functionhandle)()) == NULL) {
				if ((error = dlerror()) != NULL)  {
					fputs(error, stderr);
					dlclose(dllhandle);
					return -4;
				}
			}
		} else {
			if (DEBUG) {
				BFTRACE("No password encryption module is found.");
			}
			return -5;
		}

		initialized = 1;
	}
	return 0;
}
#endif		


#ifdef WIN32
/**
 * This will load the DLL from the configuration.  If it's already been initialized, it should just return.
 **/
static int win_loader_init(const char* prop) {
	HMODULE dllhandle;
	InitializationProcedure  init_func;
	char function_name[256];
	char *module_name=NULL, *module_from_conf=NULL, *sep=NULL, *temp=NULL, *word=NULL, *lastword=NULL;

	if (!initialized) {
		strcpy(function_name, prop);
		strcat(function_name, "_locator");
		
		if (DEBUG) {
			sprintf(trace_buf, "Looking for password locator: %s", function_name);
			BFTRACE(trace_buf);
		}

		if (NULL != (module_from_conf = bfconf_get(function_name, NULL))) {

			if (DEBUG) {
				sprintf(trace_buf, "Module from config: %s", module_from_conf);
				BFTRACE(trace_buf);
			}
            /* remove the path to get just "module.dll" */
            sep = "\\/:;=-";
			temp = strdup(module_from_conf);
			for (word = strtok(temp, sep); word; word = strtok(NULL, sep))
				lastword = word;
			
			if (DEBUG) {
				sprintf(trace_buf, "Lastword: %s", lastword);
				BFTRACE(trace_buf);
			}

            /* now remove ".dll" from the end. */
            module_name = strtok(strdup(lastword), ".");
			if (DEBUG) {
				sprintf(trace_buf, "module: %s", module_name);
				BFTRACE(trace_buf);
			}

            /* this allows us to load "module_init" per the struct design. */
			strcpy(function_name, module_name);
			strcat(function_name, "_init");
			
			if (DEBUG) {
				sprintf(trace_buf, "Loading module: %s", module_from_conf);
				BFTRACE(trace_buf);
			}

            /* load the library and initialize the function. */
			if ((dllhandle = LoadLibrary(module_from_conf)) != NULL)
				init_func = (InitializationProcedure)GetProcAddress(dllhandle, function_name);
			else {
				send_msg("PWCrypt", "PWCryptFailedInitializingDLL", "si", module_from_conf, GetLastError());
				if (DEBUG) {
					sprintf(trace_buf, "Failed loading DLL, error code = %d", GetLastError());
					BFTRACE(trace_buf);
				}
				return GetLastError();
			}

			if (DEBUG) {
				sprintf(trace_buf, "Loading procedure %s.", function_name);
				BFTRACE(trace_buf);
			}

            /* call the function */
			if ((myops = (passwd_locator_ops*)init_func()) == NULL) {
				send_msg("PWCrypt", "PWCryptFailedInitializingFunction", "si", function_name, GetLastError());
				if (DEBUG) {
					sprintf(trace_buf, "Error loading function: %d", GetLastError());
					BFTRACE(trace_buf);
				}
				FreeLibrary(dllhandle);
				return GetLastError();
			}

			initialized = 1;
		}
		
		if (module_from_conf != NULL) free (module_from_conf);
	}

	return 0;
}
#endif



/**
 * This method look up the property specified by "prop", check if a password locator is defined for it by having
 * a similar property with _locator appended.  If it finds a locator, it will be loaded and the getPassword method
 * called with that password returned.   If it does not find a locator, it will decrypt the password from the property
 * and return it.  
 *
 * When specifying a password locator module, it's recommended to fully qualify the path to ensure loading the 
 * correct module for security reasons.
 **/
char* getPasswordFromAgentConfig (const char* prop) {
	int rc=0;
	char *password=NULL, *buf=NULL, *decrypted_password=NULL;
	buf = calloc(1, BFBUFSIZ);

	if (!initialized) { 
#ifdef WIN32
		rc = win_loader_init(prop); 
#else
		rc = unix_loader_init(prop);
#endif
	}

	/* a locator was found for this password property */
	if (myops != NULL) {
		if (DEBUG) {
			sprintf(trace_buf, "Getting password from locator: %s", myops->getName());
			BFTRACE(trace_buf);
		}
		password = myops->getPassword(prop, AGENT_FILE);
	} 
	
	if (password == NULL) {
		if (DEBUG) {
			sprintf(trace_buf, "Looking for password for prop %s from bfagent.conf.", prop);
			BFTRACE(trace_buf);
		}
		if (NULL != (password = bfconf_get(prop, NULL))) {
			rc = decrypt_pwd(&decrypted_password, password);
		}
		password = decrypted_password;
	} 

	return password;
}


