/*
Copyright (C)2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#ifndef BF_IPV6_H
#define BF_IPV6_H

/* This file provides implementations for the newer address
 * resolution functions for really old systems that haven't
 * bothered to update their network stacks since 2001...
 *
 * POSIX compliance requires these functions to be thread-safe.
 * Since the implementations given here just pass through to the
 * old resolver functions without a mutex to guard them, they
 * do not meet this requirement.
 *
 * We are not currently using threads on the Unix agents, and
 * Windows XP+ (what we support) provides these functions, so
 * that is not an issue for us, here... at least, not yet.
 */



/****************************************************************
 * Miscellaneous definitions
 ****************************************************************/

#ifndef AF_UNSPEC
#  define AF_UNSPEC         0
#endif /* !AF_UNSPEC */

#ifndef PF_UNSPEC
#  define PF_UNSPEC         0
#endif /* !PF_UNSPEC */

#ifndef HAVE_IN_ADDR_T
typedef uint32_t in_addr_t;
#endif /* !HAVE_IN_ADDR_T */

#ifndef HAVE_IN_PORT_T
typedef uint16_t in_port_t;
#endif /* !HAVE_IN_PORT_T */

#ifndef HAVE_SOCKLEN_T
typedef int socklen_t;
#endif /* !HAVE_SOCKLEN_T */

#ifndef INADDR_ANY
#  define INADDR_ANY        ((in_addr_t) 0x00000000)
#endif

#ifndef INADDR_LOOPBACK
#  define INADDR_LOOPBACK   ((in_addr_t) 0x7F000001)
#endif

#ifndef INADDR_BROADCAST
#  define INADDR_BROADCAST  ((in_addr_t) 0xFFFFFFFF)
#endif

#ifndef INADDR_NONE
#  define INADDR_NONE       ((in_addr_t) 0xFFFFFFFF)
#endif

#ifndef INET_ADDRSTRLEN
#  define INET_ADDRSTRLEN   (  16)
#endif /* !INET_ADDRSTRLEN */

#ifndef INET6_ADDRSTRLEN
#  define INET6_ADDRSTRLEN  (  46)
#endif /* !INET6_ADDRSTRLEN */

#ifndef NI_MAXHOST
#  define NI_MAXHOST        (1025)
#endif /* !NI_MAXHOST */

#ifndef NI_MAXSERV
#  define NI_MAXSERV        (  32)
#endif /* !NI_MAXSERV */



/****************************************************************
 * inet_addr
 ****************************************************************/
#ifndef HAVE_INET_ADDR
/* Prototypes */
in_addr_t bf_inet_addr(const char *cp);

/* Glue */
#  undef inet_addr
#  define inet_addr bf_inet_addr
#endif

/****************************************************************
 * inet_aton
 ****************************************************************/

#ifndef HAVE_INET_ATON
/* Prototypes */
int bf_inet_aton(const char *cp, struct in_addr *inp);

/* Glue */
#  undef inet_aton
#  define inet_aton bf_inet_aton
#endif /* !HAVE_INET_ATON */



/****************************************************************
 * inet_ntoa
 ****************************************************************/

#ifndef HAVE_INET_NTOA
/* Prototypes */
char *bf_inet_ntoa(struct in_addr in);

/* Glue */
#  undef inet_ntoa
#  define inet_ntoa bf_inet_ntoa
#endif /* !HAVE_INET_NTOA */



/****************************************************************
 * gai_strerror
 ****************************************************************/

#ifndef HAVE_GAI_STRERROR
#  undef EAI_ADDRFAMILY
#  undef EAI_AGAIN
#  undef EAI_BADFLAGS
#  undef EAI_FAIL
#  undef EAI_FAMILY
#  undef EAI_MEMORY
#  undef EAI_NODATA
#  undef EAI_NONAME
#  undef EAI_OVERFLOW
#  undef EAI_SERVICE
#  undef EAI_SOCKTYPE
#  undef EAI_SYSTEM
#  define EAI_ADDRFAMILY    ( 1)
#  define EAI_AGAIN         ( 2)
#  define EAI_BADFLAGS      ( 3)
#  define EAI_FAIL          ( 4)
#  define EAI_FAMILY        ( 5)
#  define EAI_MEMORY        ( 6)
#  define EAI_NODATA        ( 7)
#  define EAI_NONAME        ( 8)
#  define EAI_OVERFLOW      ( 9)
#  define EAI_SERVICE       (10)
#  define EAI_SOCKTYPE      (11)
#  define EAI_SYSTEM        (12)

/* Prototypes */
const char *bf_gai_strerror(int errcode);

/* Glue */
#  undef gai_strerror
#  define gai_strerror bf_gai_strerror

#endif /* !HAVE_GAI_STRERROR */



/****************************************************************
 * getnameinfo
 ****************************************************************/

#ifndef HAVE_GETNAMEINFO

/* Flags */
#  undef NI_DGRAM
#  undef NI_NAMEREQD
#  undef NI_NOFQDN
#  undef NI_NUMERICHOST
#  undef NI_NUMERICSCOPE
#  undef NI_NUMERICSERV
#  define NI_DGRAM          (1<<0)
#  define NI_NAMEREQD       (1<<1)
#  define NI_NOFQDN         (1<<2)
#  define NI_NUMERICHOST    (1<<3)
#  define NI_NUMERICSCOPE   (1<<4)
#  define NI_NUMERICSERV    (1<<5)

/* Prototypes */
int bf_getnameinfo(const struct sockaddr *sa, socklen_t salen,
		char *host, size_t hostlen,
		char *serv, size_t servlen, int flags);

/* Glue */
#  undef getnameinfo
#  define getnameinfo bf_getnameinfo

#endif /* !HAVE_GETNAMEINFO */



/****************************************************************
 * getaddrinfo
 ****************************************************************/

#ifndef HAVE_GETADDRINFO

/* Flags */
#  undef AI_ADDRCONFIG
#  undef AI_ALL
#  undef AI_CANONNAME
#  undef AI_NUMERICHOST
#  undef AI_NUMERICSERV
#  undef AI_PASSIVE
#  undef AI_V4MAPPED
#  define AI_ADDRCONFIG     (1<<0)
#  define AI_ALL            (1<<1)
#  define AI_CANONNAME      (1<<2)
#  define AI_NUMERICHOST    (1<<3)
#  define AI_NUMERICSERV    (1<<4)
#  define AI_PASSIVE        (1<<5)
#  define AI_V4MAPPED       (1<<6)

#  undef AI_DEFAULT
#  define AI_DEFAULT        (AI_V4MAPPED | AI_ADDRCONFIG)

/* Data structures */
struct bf_addrinfo {
	int                 ai_flags;
	int                 ai_family;
	int                 ai_socktype;
	int                 ai_protocol;
	size_t              ai_addrlen;
	struct sockaddr *   ai_addr;
	char *              ai_canonname;
	struct bf_addrinfo *ai_next;
};

/* Prototypes */
int bf_getaddrinfo(const char *node, const char *service,
		const struct bf_addrinfo *hints, struct bf_addrinfo **res);
void bf_freeaddrinfo(struct bf_addrinfo *res);

/* Glue */
#  undef addrinfo
#  undef getaddrinfo
#  undef freeaddrinfo
#  define addrinfo bf_addrinfo
#  define getaddrinfo bf_getaddrinfo
#  define freeaddrinfo bf_freeaddrinfo

#endif /* !HAVE_GETADDRINFO */

/* Even if they have getaddrinfo, they still might not have AI_ADDRCONFIG. */
#ifndef AI_ADDRCONFIG
#  define AI_ADDRCONFIG 0
#endif /* !AI_ADDRCONFIG */


/****************************************************************
 * struct sockaddr_storage
 ****************************************************************/

/* If they don't have the other ipv6 stuff, then they probably won't have
 * this, either...
 */
#ifndef HAVE_STRUCT_SOCKADDR_STORAGE
#  define sockaddr_storage sockaddr
#endif

#endif /* BF_IPV6_H */

