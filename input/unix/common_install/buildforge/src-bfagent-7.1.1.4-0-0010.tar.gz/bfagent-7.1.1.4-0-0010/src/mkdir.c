/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"

int FuncMkdir(void)
{
	char *root, *odir, *dir, *p, *ccroot, *userdata;
	char *buf = NULL;
	int mode, mapfail;
	int timeout = 0;
	size_t userdata_size;
	int ret = 0;

	/*  locate the root element */
	if (NULL == (root = request_get(TAG_ROOT))) {
		send_missing(CMD_MKDIR, TAG_ROOT);
		return 1;
	}
	root = strdup(root);

	/*  locate the dir element */
	if (NULL == (odir = request_get(TAG_DIR))) {
		send_missing(CMD_MKDIR, TAG_DIR);
		free(root);
		return 2;
	}

	/*  locate the userdata element */
	userdata = request_get_binary(TAG_USERDATA, &userdata_size);

	/*  locate the client timeout element */
	if (NULL != (p = request_get(TAG_TIMEOUT))) {
		timeout = atoi(p);
	}

	/*  locate the silent element */
	verbose = !request_has(TAG_SILENT);

	StoreUserData(userdata, userdata_size);

	mapfail = BFCONF_EXISTS(map_drive_is_failure);
	if ((platform_map_drives(defMapStr) != 0 && mapfail) ||
			(platform_map_drives(mapStr) != 0 && mapfail))
	{
		send_msg("MAP", "MapFail", NULL);
		free(root);
		platform_unmap_drives(0);
		FreeUserData();
		return 3;
	}

	ccroot = NULL;
	if (clearcase_view) {
		ccroot = calloc(1, BFBUFSIZ);
		if (BFCONF_EXISTS(cc_suppress_server_root)) {
			format_message(ccroot, "%s/%s", this_view(), clearcase_view);
		} else {
			format_message(ccroot, "%s/%s/%s", this_view(), clearcase_view, root);
		}
		free(root);
		root = ccroot;
		ccroot = NULL;
	}

	/* process the clearcase view/vob start/mount functions */
	CCStartViews(timeout);
	CCMountVobs(timeout);

	ClobberPasswords();
	if (verbose) { DumpEnv(); }


	/*  assemble and clean the final pathname. clean the
	 *  pieces so we can use them individually later. */
	CleanPath(root);
	CleanPath(odir);

	root = env_expand_var((p = root), 0);
	free(p);
	dir = env_expand_var(odir, 0);
	CleanPath(dir);
	if (strcmp(dir, odir)) {
		if (verbose) {
			char *before = xlate_build_path(root, "", odir);
			char *after = xlate_build_path(root, "", dir);
			send_msg("MKDIR", "Xlate", "ss", before, after);
			free(after);
			free(before);
		}
	}

	buf = malloc(BFBUFSIZ);
	format_message(buf, "%s/%s", root, dir);
	CleanPath(buf);

	/*  test to see if it exists already */
	if (isDir(buf)) {
		activity_write(BFHERE "MKDIR exists [%s]", buf);
		send_msg("MKDIR", "MkdirExists", "s", buf);
		goto done;
	}

	/*  locate the mode element. if it wasn't supplied, set a default. */
	mode = 0755;
	p = request_get(TAG_MODE);
	if (p != NULL) {
		sscanf(p, "%o", (unsigned int *)&mode);
	}

	BFCreateDirectory(root, dir, mode);

	/*  now just test to see if the dir is there. if it is, the 
	 *  above code musta worked. */
	if (isDir(buf)) {
		activity_write(BFHERE "MKDIR ok [%s]", buf);
		send_msg("MKDIR", "MkdirOk", "s", buf);
	} else {
		activity_write(BFHERE "MKDIR fail [%s]", buf);
		send_msg("MKDIR", "MkdirFail", "s", buf);
		ret = 4;
	}

done:
	platform_unmap_drives(0);
	free(dir);
	free(buf);
	if (NULL != ccroot) { free(ccroot); }
	free(root);
	FreeUserData();
	return ret;
}

