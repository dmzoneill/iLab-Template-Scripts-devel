/*
 * Copyright (C)2007-2008, IBM, Inc. All rights reserved.
 * IBM, Inc. owns the copyright and other intellectual
 * property rights in this software. Duplication or use of the
 * Software is not permitted except as expressly provided in a
 * written agreement between your company and IBM, Inc.
 */

#if defined(__i386__) || defined(I386) || defined(i386) || defined(_X86_)

#define EFLAGS_AC   (0x00040000)  /* Alignment Check */
#define EFLAGS_ID   (0x00200000)  /* cpuID */
#define FEATURE_PSN (0x00040000)  /* Processor Serial Number */


/* If this is an X86 and the compiler has an inline assembler with
 * a syntax that we know, then use it to produce flag tests, CPUID,
 * and RDTSC.
 */
#ifdef HAVE_X86_ASM

/*----------------------------------------------------------------------
 * AT&T Syntax
 *----------------------------------------------------------------------*/
#  if HAVE_X86_ASM == 1

static int x86_flag_works(const char *flagname, uint32_t flag) {
	uint32_t before, after;
	activity_write(BFHERE
			"X86 ASM (A): x86_flag_works %s (0x%08X)",
			flagname, (unsigned int)flag);
	asm("pushfl\n"
		"pushfl\n"
		"popl %0\n"
		"movl %0,%1\n"
		"xorl %2,%0\n"
		"pushl %0\n"
		"popfl\n"
		"pushfl\n"
		"popl %0\n"
		"popfl\n"
		: "=&r" (before), "=&r" (after)
		: "ir" (flag));
	return ((before ^ after) & flag) != 0;
}

static inline void x86_cpuid(uint32_t cmd, uint32_t *regs) {
	activity_write(BFHERE
			"X86 ASM (A): x86_cpuid 0x%08X",
			(unsigned int)cmd);
	asm (
		"pushl %%eax\n\t"
		"pushl %%ebx\n\t"
		"pushl %%ecx\n\t"
		"pushl %%edx\n\t"
		"cpuid\n\t"
		"movl %%eax, (%%esi)\n\t"
		"movl %%ebx, 4(%%esi)\n\t"
		"movl %%ecx, 8(%%esi)\n\t"
		"movl %%edx, 12(%%esi)\n\t"
		"popl %%edx\n\t"
		"popl %%ecx\n\t"
		"popl %%ebx\n\t"
		"popl %%eax\n\t"
		: : "a" (cmd), "S" (regs) );
}

static inline uint64_t x86_rdtsc(void)
{
	uint32_t hi, lo;
	asm volatile (".byte 0x0F, 0x31" : "=d" (hi), "=a" (lo));
	return (((uint64_t)hi) << 32) | lo;
}

/*----------------------------------------------------------------------
 * Intel Syntax
 *----------------------------------------------------------------------*/
#  elif HAVE_X86_ASM == 2

static int x86_flag_works(const char *flagname, uint32_t flag) {
	uint32_t before, after;
	activity_write(BFHERE
			"X86 ASM (I): x86_flag_works  %s (0x%08X)",
			flagname, (unsigned int)flag);
	__asm {
		pushfd
		pushfd
		pop     eax
		mov     before, eax
		xor     eax, flag
		push    eax
		popfd
		pushfd
		pop     eax
		mov     after, eax
        popfd
	}
	return ((before ^ after) & flag) != 0;
}


static inline void x86_cpuid(uint32_t cmd, uint32_t *regs) {
	activity_write(BFHERE
			"X86 ASM (I): x86_cpuid 0x%08X",
			(unsigned int)cmd);
	__asm {
		mov eax, cmd
		mov esi, regs
		cpuid
		mov [esi], eax
		mov [esi +  4], ebx
		mov [esi +  8], ecx
		mov [esi + 12], edx
	}
}

#ifdef WIN32
static inline uint64_t x86_rdtsc(void)
{
	LARGE_INTEGER x;
	QueryPerformanceCounter(&x);
	return (uint64_t)x.QuadPart;
}
# else
static inline uint64_t x86_rdtsc(void)
{
	uint32_t hi, lo;
	__asm {
		db      0Fh, 31h    ; RDTSC
		mov     hi, edx
		mov     lo, eax
	}
	return (((uint64_t)hi) << 32) | lo;
}
#endif /* WIN32 */

/* Unsupported setting.... how did that happen? */
#  else
#    undef HAVE_X86_ASM
#  endif /* HAVE_X86_ASM value */
#endif /* HAVE_X86_ASM */



#ifdef HAVE_X86_ASM
# ifdef __linux__
#  include <sys/time.h>
# endif /* __linux__ */
static void x86_guess_speed(platform_sysconf_cpu_t *cpu)
{
	uint64_t tsc_before, tsc_after;
	struct timeval tv_before, tv_after;
	long work;

	BFTRACE("X86: x86_guess_speed");
	tsc_before = x86_rdtsc();
	gettimeofday(&tv_before, NULL);

	usleep(100000);

	tsc_after = x86_rdtsc();
	gettimeofday(&tv_after, NULL);

	work = (tv_after.tv_sec - tv_before.tv_sec) * 1000000L
		+ (tv_after.tv_usec - tv_before.tv_usec);
	cpu->cpu_speed = (long)((tsc_after - tsc_before) / work);

	/* Quantize to the nearest 00, 33, 50, or 67 mark. */
	work = cpu->cpu_speed % 100;
	if (work >= 84) {
		work -= 100;
	} else if (work >= 59) {
		work -= 67;
	} else if (work >= 42) {
		work -= 50;
	} else if (work >= 17) {
		work -= 33;
	}
	cpu->cpu_speed -= work;
}
#endif /* HAVE_X86_ASM */



static void x86_cpu_manufacturer(
		platform_sysconf_cpu_t *cpu,
		const char *id,
		uint32_t *max)
{
	if (0 == strcmp(id, "GenuineIntel")) {
		cpu->cpu_manufacturer = CPU_MANU_INTEL;
	} else if (0 == strcmp(id, "AuthenticAMD")
			|| 0 == strcmp(id, "AMDisbetter!"))
	{
		cpu->cpu_manufacturer = CPU_MANU_AMD;
	} else if (0 == strcmp(id, "CyrixInstead")) {
		cpu->cpu_manufacturer = CPU_MANU_CYRIX;
	} else if (0 == strcmp(id, "NexGenDriven")) {
		cpu->cpu_manufacturer = CPU_MANU_NEXGEN;
	} else if (0 == strcmp(id, "Geode by NSC")) {
		cpu->cpu_manufacturer = CPU_MANU_NSC;
	} else if (0 == strcmp(id, "RiseRiseRise")) {
		cpu->cpu_manufacturer = CPU_MANU_RISE;
	} else if (0 == strcmp(id, "SiS SiS SiS ")) {
		cpu->cpu_manufacturer = CPU_MANU_SIS;
	} else if (0 == strcmp(id, "GenuineTMx86")
			|| 0 == strcmp(id, "TransMetaCPU"))
	{
		cpu->cpu_manufacturer = CPU_MANU_TRANSMETA;
	} else if (0 == strcmp(id, "UMC UMC UMC ")) {
		cpu->cpu_manufacturer = CPU_MANU_UMC;
	} else if (0 == strcmp(id, "CentaurHauls")) {
		cpu->cpu_manufacturer = CPU_MANU_VIA;
	} else if (NULL != max && 0x00000500 == (*max & 0xFFFFFF00)) {
		cpu->cpu_manufacturer = CPU_MANU_INTEL;
		*max = 0x00000001;
	}
	activity_write(BFHERE
			"X86: x86_cpu_manufacturer [%s] -> [%d]",
			id,
			cpu->cpu_manufacturer);
}


/* Once we have figured out that the processor supports CPUID and that
 * we have either an asm syntax or (on Windows) the __cpuid intrinsic,
 * we can use the CPUID instruction to find out more about the
 * processor.
 *
 * Call 0x00000000 detects the highest supported call number and
 * reports the vendor identifier, which is returned in EBX:EDX:ECX.
 * This should be reliable CPU manufacturer info for everything
 * except the (formerly IDT) VIA Centaur line, which has the rather
 * annoying property that it can be programmed to lie.  For now, we
 * will not check for that possibility.
 */
#ifdef HAVE_X86_ASM
static void x86_cpu_cpuid(platform_sysconf_cpu_t *cpu) {
	uint32_t sig, max, features;
	uint32_t regs[4];
	int family;

	BFTRACE("X86: x86_cpu_cpuid");
	x86_cpuid(0x00000000, regs);
	max = regs[0];

	/* We have to rearrange this a little bit to make it a string... */
	regs[0] = regs[1];
	regs[1] = regs[3];
	regs[3] = 0;
	x86_cpu_manufacturer(cpu, (char *)regs, &max);

	/* If we can't figure out the manufacturer, or if the CPUID instruction
	 * does not claim support even for request 0x00000001, then there is no
	 * point in hoping that it will give us anything useful.
	 */
	if (CPU_MANU_UNKNOWN == cpu->cpu_manufacturer || max < 0x00000001)
		return;

	/* Get processor information */
	x86_cpuid(0x00000001, regs);
	sig = regs[0];
	features = regs[3];
	family = (regs[0] >> 8) & 0x000F;
	if (0x00 == family || 0x0F == family)
		family += (regs[0] >> 20) & 0x00FF;

	/* Try to figure out the processor level. */
	switch (family) {
		case 0x03:
			cpu->cpu_model = CPU_MODEL_X86_386;
			break;
		case 0x04:
			cpu->cpu_model = CPU_MODEL_X86_486;
			break;
		case 0x05:
			cpu->cpu_model = CPU_MODEL_X86_586;
			break;
		case 0x06:
			cpu->cpu_model = CPU_MODEL_X86_686;
			break;
		case 0x07:
			cpu->cpu_arch = CPU_ARCH_IA64;
			cpu->cpu_model = CPU_MODEL_IA64_ITANIUM;
			break;
		case 0x02:
			cpu->cpu_arch = CPU_ARCH_IA64;
			cpu->cpu_model = CPU_MODEL_IA64_ITANIUM_2;
			break;
		case 0x0F:
			cpu->cpu_model = CPU_MODEL_X86_64;
			break;
		case 0x10:
			if (CPU_MANU_INTEL == cpu->cpu_manufacturer) {
				cpu->cpu_arch = CPU_ARCH_IA64;
				cpu->cpu_model = CPU_MODEL_IA64_ITANIUM_2;
			} else if (CPU_MANU_AMD == cpu->cpu_manufacturer) {
				cpu->cpu_model = CPU_MODEL_X86_64;
			}
			break;
	}

	/* Check whether or not the Processor Serial Number is available.  This
	 * requires that call 0x00000003 and that the PSN feature bit is set.
	 * Additionally, we have to know how the manufacturer actually encodes
	 * it, as the few that do did not standardize it.
	 */
	if (max >= 0x00000003 && 0 != (features & FEATURE_PSN)) {
		x86_cpuid(0x00000003, regs);
		switch (cpu->cpu_manufacturer) {
			/* Intel: SIGH-SIGL-EDXH-EDXL-ECXH-ECXL */
			case CPU_MANU_INTEL:
				BFTRACE("Inter serial");
				cpu->cpu_serial = malloc(30);
				sprintf(cpu->cpu_serial,
						"%04X-%04X-%04X-%04X-%04X-%04X",
						sig >> 16, sig & 0xFFFF,
						regs[3] >> 16, regs[3] & 0xFFFF,
						regs[2] >> 16, regs[2] & 0xFFFF);
				break;

			/* TransMeta: Format depends on processor model */
			case CPU_MANU_TRANSMETA:
				BFTRACE("TransMeta serial");
				/* TransMeta Crusoe: SIGH-SIGL-EBXH-EBXL */
				if (((sig >> 4) & 0xF) >= 4) {
					cpu->cpu_serial = malloc(20);
					sprintf(cpu->cpu_serial,
							"%04X-%04X-%04X-%04X",
							sig >> 16, sig & 0xFFFF,
							regs[1] >> 16, regs[1] & 0xFFFF);
					break;
				}

				/* TransMeta Efficeon: SIGH-SIGL-EAXH-EAXL-EBXH-EBXL */
				cpu->cpu_serial = malloc(30);
				sprintf(cpu->cpu_serial,
						"%04X-%04X-%04X-%04X-%04X-%04X",
						sig >> 16, sig & 0xFFFF,
						regs[0] >> 16, regs[0] & 0xFFFF,
						regs[1] >> 16, regs[1] & 0xFFFF);
				break;

			/* Don't know how to get the serial number on this platform */
			default:
				cpu->cpu_serial = NULL;
		}
	}

	x86_guess_speed(cpu);
}
#endif /* HAVE_X86_ASM */
#endif /* __i386__ || I386 || i386 || _X86_ */



#ifdef __linux__

static void linux_cpu_details(platform_sysconf_cpu_t *cpu)
{
	char *buf, *p, *value;
	size_t len = BFBUFSIZ;
	FILE *f;

	if (NULL == cpu) { return; }
	if (NULL == (buf = malloc(len))) {
		len = 1024;
		buf = malloc(len);
		if (NULL == buf) { return; }
	}

	f = fopen("/proc/cpuinfo", "r");
	if (NULL == f) {
		free(buf);
		return;
	}

	BFTRACE("LINUX: linux_cpu_details");
	while (NULL != fgets(buf, len, f)) {
		p = strchr(buf, ':');
		if (NULL == p) { continue; }
		value = &p[1];
		while (' ' == *value) { ++value; }

		do {
			--p;
		} while (p > buf && (*p == ' ' || *p == '\t'));
		p[1] = '\0';

		p = strchr(value, '\n');
		if (NULL != p) { *p = '\0'; }

		if (cpu->cpu_speed <= 0 && 0 == strcmp("cpu MHz", buf)) {
			cpu->cpu_speed = (long)atof(value);
			continue;
		}
	}

	fclose(f);
	free(buf);
}
#endif /* __linux__ */



/* MacOS */
#ifdef __APPLE__
#include <mach/machine.h>
#include <sys/sysctl.h>

#include "platform/frameworks.h"

#ifdef HAVE_FRAMEWORKS
void apple_serial(platform_sysconf_cpu_t *cpu)
{
	CFIndex got = -1;
	CFTypeRef cf_serial = NULL;
	io_service_t io_expert =
			IOServiceGetMatchingService(kIOMasterPortDefault,
			IOServiceMatching("IOPlatformExpertDevice"));

	BFTRACE("MACOS: apple_serial");
	if (!io_expert) { goto done; }

	cf_serial = IORegistryEntryCreateCFProperty(
			io_expert,
			CFSTR(kIOPlatformSerialNumberKey),
			kCFAllocatorDefault,
			0);
	if (NULL == cf_serial) { goto done; }

	cpu->cpu_serial = malloc(64);
	if (NULL == cpu->cpu_serial) { goto done; }

	CFStringGetBytes(
			cf_serial,
			CFRangeMake(0, CFStringGetLength(cf_serial)),
			kCFStringEncodingUTF8,
			'?',
			false,
			(UInt8 *)cpu->cpu_serial,
			64,
			&got);
	if (got > 63)
		got = 63;
	cpu->cpu_serial[got] = '\0';

done:
	if (NULL != cf_serial) { CFRelease(cf_serial); }
	if (io_expert) { IOObjectRelease(io_expert); }
}
#endif /* HAVE_FRAMEWORKS */


static int apple_sysctl(const char *name, void *buf, size_t *buflen) {
	size_t len = 16;
	int mib[16];
	int ret = sysctlnametomib(name, mib, &len);
	return (0 != ret)
		? ret
		: sysctl(mib, len, buf, buflen, NULL, 0);
}

static void apple_cpu_details(platform_sysconf_cpu_t *cpu)
{
	cpu_type_t      cpu_type;
	cpu_subtype_t   cpu_subtype;
	int             speed = 0, ncpu = 0;
	size_t          len;

	BFTRACE("MACOS: apple_cpu_details");
	len = sizeof(ncpu);
	if (0 == apple_sysctl("hw.physicalcpu", &ncpu, &len) && ncpu > 1) {
		cpu->cpu_count = ncpu;
	} else {
		len = sizeof(ncpu);
		if (0 == apple_sysctl("hw.ncpu", &ncpu, &len) && ncpu > 1) {
			cpu->cpu_count = ncpu;
		} else {
			cpu->cpu_count = 1;
		}
	}

	len = sizeof(speed);
	if (0 == apple_sysctl("hw.cpufrequency_max", &speed, &len))
		cpu->cpu_speed = (long)((speed + 500000L) / 1000000L);

	len = sizeof(cpu_type);
	if (0 == apple_sysctl("hw.cputype", &cpu_type, &len)) {
		switch (cpu_type) {
#ifdef CPU_TYPE_ALPHA
			case CPU_TYPE_ALPHA:
				cpu->cpu_arch = CPU_ARCH_ALPHA;
				cpu->cpu_manufacturer = CPU_MANU_DEC;
				break;
#endif
#ifdef CPU_TYPE_HPPA
			case CPU_TYPE_HPPA:
				cpu->cpu_arch = CPU_ARCH_HPPA;
				cpu->cpu_manufacturer = CPU_MANU_HP;
				break;
#endif
#ifdef CPU_TYPE_VAX
			case CPU_TYPE_VAX:
				cpu->cpu_arch = CPU_ARCH_VAX;
				cpu->cpu_manufacturer = CPU_MANU_DEC;
				break;
#endif
			case CPU_TYPE_I386:
				/* Get the info from CPUID, not here. */
				break;
#ifdef CPU_TYPE_POWERPC
			case CPU_TYPE_POWERPC:
#endif
#ifdef CPU_TYPE_POWERPC64
			case CPU_TYPE_POWERPC64:
#endif
#if defined(CPU_TYPE_POWERPC) || defined(CPU_TYPE_POWERPC64)
				cpu->cpu_arch = CPU_ARCH_PPC;
				len = sizeof(cpu_subtype);
				if (0 == apple_sysctl("hw.cpusubtype", &cpu_subtype, &len)) {
					switch (cpu_subtype) {
						case CPU_SUBTYPE_POWERPC_601:
						case CPU_SUBTYPE_POWERPC_602:
						case CPU_SUBTYPE_POWERPC_603:
						case CPU_SUBTYPE_POWERPC_603e:
						case CPU_SUBTYPE_POWERPC_603ev:
						case CPU_SUBTYPE_POWERPC_604:
						case CPU_SUBTYPE_POWERPC_604e:
						case CPU_SUBTYPE_POWERPC_620:
							cpu->cpu_model = CPU_MODEL_PPC_6XX;
							break;
						case CPU_SUBTYPE_POWERPC_750:
							cpu->cpu_model = CPU_MODEL_PPC_G3;
							break;
						case CPU_SUBTYPE_POWERPC_7400:
						case CPU_SUBTYPE_POWERPC_7450:
							cpu->cpu_model = CPU_MODEL_PPC_G4;
							cpu->cpu_manufacturer = CPU_MANU_MOTOROLA;
							break;
						case CPU_SUBTYPE_POWERPC_970:
							cpu->cpu_model = CPU_MODEL_PPC_G5;
							cpu->cpu_manufacturer = CPU_MANU_IBM;
							break;
					}
				}
				break;
#endif /* CPU_TYPE_POWERPC || CPU_TYPE_POWERPC64 */
#ifdef CPU_TYPE_SPARC
			case CPU_TYPE_SPARC:
				cpu->cpu_arch = CPU_ARCH_SPARC;
				cpu->cpu_manufacturer = CPU_MANU_SUN;
#endif
		}
#if defined(HAVE_FRAMEWORK_CF) && defined(HAVE_FRAMEWORK_IOKIT)
		apple_serial(cpu);
#endif /* HAVE_FRAMEWORK_CF && HAVE_FRAMEWORK_IOKIT */
	}
}
#endif /* HAVE_MACH_MACH_H */



#ifdef WIN32
static void win32_cpu_details(platform_sysconf_cpu_t *cpu) {
	/* Assume that CPUID will get us what we need */
}
#endif


static void platform_sysconf_cpu_details(platform_sysconf_cpu_t *cpu) {
	/* OS-specific things to try */
#if defined(__linux__)
	linux_cpu_details(cpu);
# elif defined(__APPLE__)
	apple_cpu_details(cpu);
# elif defined(WIN32)
	win32_cpu_details(cpu);
#endif

	/* Architecture-specific things to try */
#if defined(I386) || defined(__i386__)
	cpu->cpu_arch = CPU_ARCH_X86;
#  ifdef HAVE_X86_ASM
	if (x86_flag_works("ID", EFLAGS_ID))
		x86_cpu_cpuid(cpu);
#  endif /* HAVE_X86_ASM */
# elif defined(__hppa__)
	cpu->cpu_arch = CPU_ARCH_HPPA;
	cpu->cpu_manufacturer = CPU_MANU_HP;
# elif defined(PASE)
	cpu->cpu_arch = CPU_ARCH_PASE;
	cpu->cpu_manufacturer = CPU_MANU_IBM;
# elif defined(__PPC64) \
		|| defined(__PPC64__)
	cpu->cpu_arch = CPU_ARCH_PPC;
# elif defined(__ppc__) \
		|| defined(__powerpc__) \
		|| defined(__PPC__) \
		|| defined(_POWER)
	cpu->cpu_arch = CPU_ARCH_PPC;
# elif defined(__sparc__)
	cpu->cpu_arch = CPU_ARCH_SPARC;
	cpu->cpu_manufacturer = CPU_MANU_SUN;
# elif defined(__MVS__)
	cpu->cpu_arch = CPU_ARCH_MVS;
	cpu->cpu_manufacturer = CPU_MANU_IBM;
# elif defined(__s390__)
	cpu->cpu_arch = CPU_ARCH_S390;
	cpu->cpu_manufacturer = CPU_MANU_IBM;
#  ifdef __s390x__
	cpu->cpu_model = CPU_MODEL_S390_S390X;
#  else /* !__s390x__ */
	cpu->cpu_model = CPU_MODEL_S390_S390;
#  endif /* __s390x__/! */
# elif defined(__alpha__)
	cpu->cpu_arch = CPU_ARCH_ALPHA;
	cpu->cpu_manufacturer = CPU_MANU_DEC;
#endif
}


#ifdef WIN32
/*================================================================
 * Windows Implementation
 *----------------------------------------------------------------*/
platform_sysconf_cpu_t *platform_sysconf_cpu_new(void) {
	platform_sysconf_cpu_t *cpu = NULL;
	SYSTEM_INFO sysinfo;
	HANDLE mapHandle = NULL;
	HKEY hKey;

	cpu = calloc(1, sizeof(*cpu));
	if (NULL == cpu) { return NULL; }

	cpu->cpu_load = cpu->cpu_load1 = cpu->cpu_load5 = cpu->cpu_load15 = -1.0;

	mapHandle = OpenFileMapping(FILE_MAP_READ, FALSE, "BFAgentLoadAVG");
	if (NULL != mapHandle && INVALID_HANDLE_VALUE != mapHandle) {
		struct _loadavg	*pavg = (struct _loadavg *)MapViewOfFile(
				mapHandle, FILE_MAP_READ, 0, 0, sizeof(struct _loadavg));
		if (NULL != pavg) {
			cpu->cpu_load = pavg->cpuload;
			cpu->cpu_load1 = pavg->loadavg1;
			cpu->cpu_load5 = pavg->loadavg5;
			cpu->cpu_load15 = pavg->loadavg15;
			UnmapViewOfFile(pavg);
		}
		CloseHandle(mapHandle);
	}

	BFTRACE("WIN32: GetSystemInfo");
	GetSystemInfo(&sysinfo);
	cpu->cpu_count = sysinfo.dwNumberOfProcessors;
	switch (sysinfo.wProcessorArchitecture) {
		case PROCESSOR_ARCHITECTURE_INTEL:
			cpu->cpu_arch = CPU_ARCH_X86;
			switch (sysinfo.dwProcessorType) {
				case PROCESSOR_INTEL_386:
					cpu->cpu_model = CPU_MODEL_X86_386;
					break;
				case PROCESSOR_INTEL_486:
					cpu->cpu_model = CPU_MODEL_X86_486;
					break;
				case PROCESSOR_INTEL_PENTIUM:
					cpu->cpu_model = CPU_MODEL_X86_586;
					break;
				case PROCESSOR_AMD_X8664:
					cpu->cpu_model = CPU_MODEL_X86_64;
					break;
			}
			break;
		case PROCESSOR_ARCHITECTURE_IA64:
			cpu->cpu_arch = CPU_ARCH_IA64;
			cpu->cpu_model = CPU_MODEL_IA64_ITANIUM;
			break;
		case PROCESSOR_ARCHITECTURE_AMD64:
			cpu->cpu_arch = CPU_ARCH_X86;
			cpu->cpu_model = CPU_MODEL_X86_64;
			break;
	}

	BFTRACE("WIN32: RegOpenKeyEx");
	if (ERROR_SUCCESS == RegOpenKeyEx(HKEY_LOCAL_MACHINE,
				"HARDWARE\\DESCRIPTION\\System\\CentralProcessor\\0",
				0,
				KEY_READ,
				&hKey))
	{
		char buf[_MAX_PATH];
		DWORD dwMHz = 0;
		DWORD sz;

		sz = sizeof(buf);
		if (ERROR_SUCCESS == RegQueryValueEx(
					hKey, "VendorIdentifier", NULL, NULL,
					(LPBYTE)buf, &sz))
		{
			buf[sz >= _MAX_PATH ? (_MAX_PATH - 1) : sz] = '\0';
			x86_cpu_manufacturer(cpu, buf, NULL);
		}

		sz = sizeof(dwMHz);
		RegQueryValueEx(hKey, "~MHz", NULL, NULL,
				(LPBYTE)&dwMHz, &sz);
		cpu->cpu_speed = (long)dwMHz;
	}
	return cpu;
}

#else /* !WIN32 */
/*================================================================
 * UNIX Implementation
 *----------------------------------------------------------------*/
platform_sysconf_cpu_t *platform_sysconf_cpu_new(void) {
	platform_sysconf_cpu_t *cpu = calloc(1, sizeof(platform_sysconf_cpu_t));
#ifdef HAVE_GETLOADAVG
	double	loadavg[3];
#endif

	if (NULL != cpu) {
		cpu->cpu_count = -1;
		cpu->cpu_speed = -1;
		cpu->cpu_load = -1.0;
		cpu->cpu_load1 = cpu->cpu_load5 = cpu->cpu_load15 = -1.0;

#ifdef _SC_NPROCESSORS_ONLN
		cpu->cpu_count = sysconf(_SC_NPROCESSORS_ONLN);
#elif defined(_SC_NPROCESSORS_CONF)
		cpu->cpu_count = sysconf(_SC_NPROCESSORS_CONF);
#endif
#ifdef HAVE_GETLOADAVG
		if (getloadavg(loadavg, 3)) {
			cpu->cpu_load1  = loadavg[0];
			cpu->cpu_load5  = loadavg[1];
			cpu->cpu_load15 = loadavg[2];
		}
#endif
		platform_sysconf_cpu_details(cpu);
	}
	return cpu;
}

#endif /* WIN32/! */


