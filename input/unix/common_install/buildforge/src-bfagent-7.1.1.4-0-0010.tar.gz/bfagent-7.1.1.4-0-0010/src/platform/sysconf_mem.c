/*
 * Copyright (C)2003-2008, IBM, Inc. All rights reserved.
 * IBM, Inc. owns the copyright and other intellectual
 * property rights in this software. Duplication or use of the
 * Software is not permitted except as expressly provided in a
 * written agreement between your company and IBM, Inc.
 */

#ifdef WIN32
/*================================================================
 * Windows Implementation
 *----------------------------------------------------------------*/
platform_sysconf_mem_t *platform_sysconf_mem_new(void)
{
	platform_sysconf_mem_t *mem;
	SYSTEM_INFO sysinfo;
	MEMORYSTATUSEX mstatex;

	mstatex.dwLength = sizeof(mstatex);
	BFTRACE("WIN32: GlobalMemoryStatusEx");
	if (!GlobalMemoryStatusEx(&mstatex)) { return NULL; }
	mem = calloc(1, sizeof(*mem));
	if (NULL == mem) { return NULL; }
	GetSystemInfo(&sysinfo);

	mem->mem_page_size = (long)sysinfo.dwPageSize;
	mem->mem_total = (double)mstatex.ullTotalPhys;
	mem->mem_free = (double)mstatex.ullAvailPhys;
	mem->mem_load = 1.0 - mem->mem_free / mem->mem_total;
	return mem;
}

#else /* !WIN32 */
/*================================================================
 * UNIX Implementation
 *----------------------------------------------------------------*/

/* Make sure we don't try to do this AIX-specific stuff under PASE,
 * as it seems to always crash.
 */
#ifdef ISERIES_AGENT
#  undef HAVE_VMGETINFO

/* AIX -- make sure we have an implementation for vmgetinfo.  If the
 * function isn't published, then try to get it from the kernel.
 */
#elif defined(_AIX)
#  if defined(HAVE_SYS_VMINFO_H) && !defined(HAVE_VMGETINFO)
#    ifdef HAVE_DLFCN_H
typedef int (*vmgetinfo_fn)(void *, int, int);
static int bf_vmgetinfo(void *out, int command, int arg) {
static int (*vmgetinfo_ksym)(void *, int, int) = NULL;
	vmgetinfo_fn fn = NULL;
	int ret = -1;
	void *ksyms = dlopen("/unix", RTLD_NOW | RTLD_GLOBAL);

	if (NULL != ksyms) {
		fn = (vmgetinfo_fn)dlsym(ksyms, "vmgetinfo");
		if (NULL != fn) {
			BFTRACE("bf_vmgetinfo");
			ret = (*fn)(out, command, arg);
		}
		dlclose(ksyms);
	}

	return ret;
}
#      undef vmgetinfo
#      define vmgetinfo bf_vmgetinfo
#      define HAVE_VMGETINFO 1
#    endif /* HAVE_DLFCN_H */
#  endif /* HAVE_SYS_VMINFO_H && !HAVE_VMGETINFO */
#endif /* ISERIES_AGENT or _AIX */


static void get_mem_info(platform_sysconf_mem_t *mem)
{
#ifdef HAVE_MACH_MACH_H /* MacOS */
	mach_port_t port;
	unsigned int count = HOST_VM_INFO_COUNT;
	vm_statistics_data_t vm;

	mem->mem_total = mem->mem_used = mem->mem_free = mem->mem_load = -1.0;

	BFTRACE("mach (*BSD/MacOS)");
	port = mach_host_self();
	if (host_statistics(port, HOST_VM_INFO, (host_info_t)&vm, &count) == KERN_SUCCESS) {
		mem->mem_used = (double)(vm.active_count + vm.inactive_count + vm.wire_count) * mem->mem_page_size;
		mem->mem_free = (double)vm.free_count * mem->mem_page_size;
		mem->mem_total = mem->mem_used + mem->mem_free;
		mem->mem_load = mem->mem_used / mem->mem_total;
		return;
	}
	/* Fall back on sysconf */
#elif defined(HAVE_VMGETINFO) /* AIX */
	struct vminfo vm;

	BFTRACE("vmgetinfo (AIX)");
	if (vmgetinfo(&vm, VMINFO, sizeof(vm)) == 0) {
		mem->mem_used = (double)(vm.numwseguse + vm.numpseguse + vm.numclseguse) * mem->mem_page_size;
		mem->mem_free = (double)vm.numfrb * mem->mem_page_size;
		mem->mem_total = (double)vm.memsizepgs * mem->mem_page_size;
		mem->mem_load = mem->mem_used / mem->mem_total;
		return;
	}
	/* Fall back on sysconf */
#endif /* MacOS or AIX */

	/* Try to get the memory usage info from sysconf */
#ifdef _SC_AVPHYS_PAGES
	BFTRACE("sysconf _SC_AVPHYS_PAGES");
	mem->mem_free = (double)sysconf(_SC_AVPHYS_PAGES) * mem->mem_page_size;
#endif /* _SC_AVPHYS_PAGES */

#ifdef _SC_PHYS_PAGES
	BFTRACE("sysconf _SC_PHYS_PAGES");
	mem->mem_total = (double)sysconf(_SC_PHYS_PAGES) * mem->mem_page_size;
	if (mem->mem_free >= 0.0f && mem->mem_total >= mem->mem_free) {
		mem->mem_used = mem->mem_total - mem->mem_free;
		mem->mem_load = mem->mem_used / mem->mem_total;
	}
#endif /* _SC_PHYS_PAGES */
}

platform_sysconf_mem_t *platform_sysconf_mem_new(void) {
	platform_sysconf_mem_t *mem = calloc(1, sizeof(platform_sysconf_mem_t));
	long mem_page_size = 4096;
	char *p;

	if (NULL == mem)
		return NULL;

	if (NULL != ( p = bfconf_get("memory_page_size", NULL) )) {
		int i = atoi(p);
		if (i > 0) { mem_page_size = i; }
		free(p);
	}

#ifdef _SC_PAGE_SIZE
	{
		long value;
		if ((value = sysconf(_SC_PAGE_SIZE)) > 0) {
			mem_page_size = value;
		}
	}
#endif /* _SC_PAGE_SIZE */
	if (mem_page_size <= 0)
		mem_page_size = 4096;

	mem->mem_page_size = mem_page_size;
	get_mem_info(mem);
	return mem;
}

#endif /* WIN32/! */

