/*
 * Copyright (C)2003-2008, IBM, Inc. All rights reserved.
 * IBM, Inc. owns the copyright and other intellectual
 * property rights in this software. Duplication or use of the
 * Software is not permitted except as expressly provided in a
 * written agreement between your company and IBM, Inc.
 */

#ifdef WIN32
/*================================================================
 * Windows Implementation
 *----------------------------------------------------------------*/
platform_sysconf_disk_t *platform_sysconf_disk_new(const char *disk_path)
{
	__int64 bytes_free, bytes_total;
	platform_sysconf_disk_t *disk;

	if (NULL == disk_path || '\0' == *disk_path)
		return NULL;
	if (NULL == ( disk = calloc(1, sizeof(*disk)) ))
		return NULL;

	disk->disk_path = strdup(disk_path);
	BFTRACE("GetDiskFreeSpaceEx (Win32)");
	/* i64 ints need a special format code on windows so the report message for this is unique */
	if (GetDiskFreeSpaceEx(
				disk_path,
				(PULARGE_INTEGER)&bytes_free,
				(PULARGE_INTEGER)&bytes_total,
				NULL))
	{
		disk->disk_free = (double)bytes_free;
		disk->disk_total = (double)bytes_total;
	}
	return disk;
}

#else /* !WIN32 */
/*================================================================
 * UNIX Implementation
 *----------------------------------------------------------------*/
platform_sysconf_disk_t *platform_sysconf_disk_new(const char *disk_path)
{
#if defined(HAVE_STATVFS) || defined(HAVE_STATFS)
	platform_sysconf_disk_t *disk = calloc(1, sizeof(platform_sysconf_disk_t));
	long disk_block_size = 0;
#ifdef HAVE_STATVFS
	struct statvfs fsb;
#else
	struct statfs fsb;
#endif

	if (NULL == disk) { return NULL; }

	activity_write(BFHERE "disk=[%s]", disk);

#ifdef HAVE_STATVFS
	if (statvfs(disk_path, &fsb) == 0)
		disk_block_size = fsb.f_frsize;
#else
	if (statfs(disk_path, &fsb) == 0)
		disk_block_size = fsb.f_bsize;
#endif
	if (disk_block_size <= 0) {
		free(disk);
		return NULL;
	}

	disk->disk_path = strdup(disk_path);
	disk->disk_total = (double)disk_block_size * (double)fsb.f_blocks;
	disk->disk_free = (double)disk_block_size * (double)((0 != getuid())
				? fsb.f_bavail
				: fsb.f_bfree );
	return disk;
#else /* !(HAVE_STATVFS || HAVE_STATFS) */
	return NULL;
#endif /* (HAVE_STATVFS || HAVE_STATFS)/! */
}

#endif /* WIN32/! */

