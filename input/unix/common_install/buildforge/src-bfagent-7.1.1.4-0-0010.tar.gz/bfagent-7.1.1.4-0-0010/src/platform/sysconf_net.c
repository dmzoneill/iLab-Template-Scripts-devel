/*
 * Copyright (C)2007-2008, IBM, Inc. All rights reserved.
 * IBM, Inc. owns the copyright and other intellectual
 * property rights in this software. Duplication or use of the
 * Software is not permitted except as expressly provided in a
 * written agreement between your company and IBM, Inc.
 */

int is_same_addr(const struct sockaddr *sa1, const struct sockaddr *sa2) {
	if (sa1 == NULL || sa2 == NULL) {
		return 0;
	}

	switch (sa1->sa_family) {
		case AF_INET:
			if (AF_INET == sa2->sa_family) {
				const struct in_addr *ia1 = BF_SA_TO_IPV4(sa1);
				const struct in_addr *ia2 = BF_SA_TO_IPV4(sa2);
				return BF_IS_SAME_IPV4(ia1, ia2);
			}
#ifdef AF_INET6
			if (AF_INET6 == sa2->sa_family) {
				const struct in6_addr *in6 = BF_SA_TO_IPV6(sa2);
				if (IN6_IS_ADDR_V4MAPPED(in6) || IN6_IS_ADDR_V4COMPAT(in6)) {
					const struct in_addr *in4 = BF_SA_TO_IPV4(sa1);
					return BF_IS_SAME_IPV4_AS_IPV6(in4, in6);
				}
			}
#endif /* AF_INET6 */
			return 0;

#ifdef AF_INET6
		case AF_INET6:
			if (AF_INET == sa2->sa_family) {
				const struct in6_addr *in6 = BF_SA_TO_IPV6(sa1);
				if (IN6_IS_ADDR_V4MAPPED(in6) || IN6_IS_ADDR_V4COMPAT(in6)) {
					const struct in_addr *in4 = BF_SA_TO_IPV4(sa2);
					return BF_IS_SAME_IPV4_AS_IPV6(in4, in6);
				}
			}

			if (AF_INET6 == sa2->sa_family) {
				const struct in6_addr *ia1 = BF_SA_TO_IPV6(sa1);
				const struct in6_addr *ia2 = BF_SA_TO_IPV6(sa2);
				return BF_IS_SAME_IPV4(ia1, ia2);
			}
			return 0;
#endif /* AF_INET6 */

#if defined(AF_LINK) && defined(HAVE_STRUCT_SOCKADDR_DL)
        case AF_LINK: {
			const struct sockaddr_dl *a1 = (const struct sockaddr_dl *)sa1;
			const struct sockaddr_dl *a2 = (const struct sockaddr_dl *)sa2;
			if (AF_LINK == sa2->sa_family &&
					a1->sdl_nlen == a2->sdl_nlen &&
					a1->sdl_alen == a2->sdl_alen &&
					0 == memcmp(a1->sdl_data, a2->sdl_data,
							a1->sdl_nlen + a1->sdl_alen) )
			{
				return 1;
			}
			return 0;
		}
#endif /* AF_LINK && HAVE_STRUCT_SOCKADDR_DL */

#if defined(AF_PACKET) && defined(HAVE_STRUCT_SOCKADDR_LL)
        case AF_PACKET: {
			const struct sockaddr_ll *a1 = (const struct sockaddr_ll *)sa1;
			const struct sockaddr_ll *a2 = (const struct sockaddr_ll *)sa2;
			if (AF_PACKET == sa2->sa_family &&
					a1->sll_halen == a2->sll_halen &&
					0 == memcmp(a1->sll_addr, a2->sll_addr,
							a1->sll_halen) )
			{
				return 1;
			}
			return 0;
		}
#endif /* AF_PACKET && HAVE_STRUCT_SOCKADDR_LL */
	}
	return 0;
}



static void decode_hwaddr(
		char *buf,
		size_t buflen,
		const unsigned char *hwaddr,
		int hwaddrlen)
{
	char *p = buf;
	int limit = (int)(buflen / 3);
	int i;

	if (NULL == buf || buflen <= 0) { return; }
	if (hwaddrlen > limit) { hwaddrlen = limit; }
	if (0 == hwaddrlen) {
		*buf = '\0';
		return;
	}
	p += sprintf(p, "%02X", *hwaddr++);
	for (i=1; i<hwaddrlen; ++i) {
		p += sprintf(p, ":%02X", *hwaddr++);
	}
}


static void get_net_addr(
		platform_sysconf_net_t *net,
		const struct sockaddr *sa,
		socklen_t sa_len)
{
	switch (sa->sa_family) {
		case AF_INET:
			if ('\0' != *net->net_ipv4) { break; }
			if (sa_len == 0) { sa_len = sizeof(struct sockaddr_in); }
			if (0 == getnameinfo(sa, sa_len,
					net->net_ipv4, INET_ADDRSTRLEN,
					NULL, 0, NI_NUMERICHOST) )
			{
				BFTRACE("IPv4 <- getnameinfo(AF_INET)");
			}
			break;

#ifdef AF_INET6
		case AF_INET6:
			if ('\0' != *net->net_ipv6) { break; }
			if (sa_len == 0) { sa_len = sizeof(struct sockaddr_in6); }
			if (0 == getnameinfo(sa, sa_len,
					net->net_ipv6, INET6_ADDRSTRLEN,
					NULL, 0, NI_NUMERICHOST) )
			{
				BFTRACE("IPv6 <- getnameinfo(AF_INET6)");
			}
			break;
#endif /* AF_INET6 */

#ifdef AF_LINK
		case AF_LINK:
			if ('\0' != *net->net_hwaddr) { break; }
#  ifdef HAVE_STRUCT_SOCKADDR_DL
			if (sa_len == 0) { sa_len = sizeof(struct sockaddr_dl); }
#  endif
			if (sa_len != 0 && 0 == getnameinfo(sa, sa_len,
					net->net_hwaddr, BF_HW_ADDRSTRLEN,
					NULL, 0, NI_NUMERICHOST))
			{
				BFTRACE("hwaddr <- getnameinfo(AF_LINK)");
				break;
			}
#  ifdef HAVE_STRUCT_SOCKADDR_DL
			{
				struct sockaddr_dl *sdl = (struct sockaddr_dl *)sa;
				const unsigned char *hwaddr =
					((const unsigned char *)sdl->sdl_data) + sdl->sdl_nlen;
				BFTRACE("hwaddr <- struct sockaddr_dl");
				decode_hwaddr(
						net->net_hwaddr, BF_HW_ADDRSTRLEN,
						hwaddr, sdl->sdl_alen );
			}
#  endif /* HAVE_STRUCT_SOCKADDR_DL */
			break;
#endif /* AF_LINK */

#ifdef AF_PACKET
		case AF_PACKET:
			if ('\0' != *net->net_hwaddr) {
				break;
			}
#  ifdef HAVE_STRUCT_SOCKADDR_LL
			if (sa_len == 0) { sa_len = sizeof(struct sockaddr_ll); }
#  endif
			if (sa_len != 0 && 0 == getnameinfo(sa, sa_len,
					net->net_hwaddr, BF_HW_ADDRSTRLEN,
					NULL, 0, NI_NUMERICHOST))
			{
				BFTRACE("hwaddr <- getnameinfo(AF_PACKET)");
				break;
			}
#  ifdef HAVE_STRUCT_SOCKADDR_LL
			{
				struct sockaddr_ll *sll = (struct sockaddr_ll *)sa;
				const unsigned char *hwaddr =
					(const unsigned char *)sll->sll_addr;
				BFTRACE("hwaddr <- struct sockaddr_ll");
				decode_hwaddr(
						net->net_hwaddr, BF_HW_ADDRSTRLEN,
						hwaddr, sll->sll_halen );
			}
#  endif /* HAVE_STRUCT_SOCKADDR_LL */
			break;
#endif /* AF_PACKET */
	}
}



/*======================================================================
 * WINDOWS
 *======================================================================*/
#ifdef WIN32

/* Look for alternate address.  If we know our IPv4, look for IPv6.
 * If we know our IPv6, look for IPv4...
 */
static void get_net_details_gaa(
		platform_sysconf_net_t *net,
		DWORD idx)
{
	PIP_ADAPTER_ADDRESSES ifaces = NULL;
	PIP_ADAPTER_ADDRESSES iface;
	PIP_ADAPTER_UNICAST_ADDRESS addr;
	ULONG len = 0;
	DWORD ret = 0;
	int i;

	BFTRACE("WIN32: GetAdaptersAddresses");
	for (i=0; i<8; ++i) {
		ret = (DWORD)GetAdaptersAddresses(AF_UNSPEC, 0, NULL, ifaces, &len);
		if (ERROR_BUFFER_OVERFLOW != ret)
			break;
		if (NULL != ifaces)
			free(ifaces);
		ifaces = malloc(len);
	}
	if (NO_ERROR != ret)
		goto done;

	BFTRACE("interface <- GetAdaptersAddresses");

	for (iface = ifaces; NULL != iface; iface = iface->Next) {
		if (idx == iface->IfIndex) {
			for (addr = iface->FirstUnicastAddress;
					NULL != addr;
					addr = addr->Next)
			{
				get_net_addr(net,
						addr->Address.lpSockaddr,
						addr->Address.iSockaddrLength);
			}
			break;
		}
	}

done:
	if (NULL != ifaces)
		free(ifaces);
}


static void get_net_details_gbi(
		platform_sysconf_net_t *net,
		const struct sockaddr *saddr,
		socklen_t sa_len)
{
	struct sockaddr saddr_peer;
	int saddr_peer_len = sizeof(saddr_peer);
	MIB_IFROW ifrow;
	ULONG ret = 0;

	/* Find the address of our peer. */
	if (0 != getpeername(hRemote, &saddr_peer, &saddr_peer_len))
		return;

	/* Find the matching interface */
	ZeroMemory(&ifrow, sizeof(ifrow));

	BFTRACE("WIN32: GetBestInterfaceEx");
	ret = GetBestInterfaceEx(&saddr_peer, &ifrow.dwIndex);
	if (NO_ERROR != ret) {
		if (AF_INET == saddr->sa_family) {
			struct sockaddr_in *peer = (struct sockaddr_in *) &saddr_peer;
			BFTRACE("WIN32: GetBestInterface");
			ret = GetBestInterface(peer->sin_addr.S_un.S_addr, &ifrow.dwIndex);
		}
		if (NO_ERROR != ret)
			return;
	}

	/* Get the interface's details */
	BFTRACE("WIN32: GetIfEntry");
	if (NO_ERROR != GetIfEntry(&ifrow)) {
		if (NULL == net->net_iface) {
			net->net_iface = malloc(16);
			sprintf(net->net_iface, "%lu", ifrow.dwIndex);
		}
		goto no_if_entry;
	}

	if (NULL == net->net_iface) {
		int wlen = wcslen(ifrow.wszName) + 1;
		if (wlen > 1) {
			net->net_iface = malloc(wlen << 1);
			convert_wide_to_utf8(
				ifrow.wszName, wlen,
				net->net_iface, wlen << 1);
		} else {
			wlen = (int)ifrow.dwDescrLen;
			if (wlen > 0) {
				net->net_iface = malloc(wlen << 2);
				wlen = convert_native_to_utf8(
					(const char *)ifrow.bDescr, wlen,
					net->net_iface, wlen << 2);
				net->net_iface[wlen] = '\0';
			}
		}
		BFTRACE("interface <- GetBestInterfaceEx");
	}

	if ('\0' == *net->net_hwaddr) {
		/* FIXME - we should probably check dwType instead of or
		 * in addition to dwPhysAddrLen ...
		 */
		if (ifrow.dwPhysAddrLen <= 6) {
			BFTRACE("hwaddr <- GetBestInterfaceEx");
			decode_hwaddr(
					net->net_hwaddr,
					BF_HW_ADDRSTRLEN,
					(const unsigned char *)ifrow.bPhysAddr,
					(int)ifrow.dwPhysAddrLen);
		}
	}

	net->net_speed = ifrow.dwSpeed / 1000000;

no_if_entry:
	get_net_details_gaa(net, ifrow.dwIndex);
}
#endif /* WIN32 */

/*======================================================================*/

/*======================================*/
/* Get network info by using getifaddrs */
/*======================================*/

#ifdef HAVE_GETIFADDRS
void get_net_details_ifaddrs(
		platform_sysconf_net_t *net,
		const struct sockaddr *saddr,
		socklen_t sa_len)
{
	struct ifaddrs *ifa_head, *ifa;

	BFTRACE("getifaddrs");

	/* Look for alternate address.  If we know our IPv4, look for IPv6.
	 * If we know our IPv6, look for IPv4...
	 */
	if (0 != getifaddrs(&ifa_head))
		return;

	/* First pass: find the matching interface name */
	if (NULL == net->net_iface) {
		for (ifa = ifa_head; NULL != ifa; ifa = ifa->ifa_next) {
			if (is_same_addr(saddr, ifa->ifa_addr)) {
				BFTRACE("interface <- getifaddrs");
				net->net_iface = strdup(ifa->ifa_name);
				break;
			}
		}
	}

	if (NULL == net->net_iface)
		BFTRACE("interface <- getifaddrs: No match!");

#if defined(AF_INET6) || defined(AF_LINK) || defined(AF_PACKET)
	/* Second pass: find other addresses */
	if (NULL != net->net_iface) {
		for (ifa = ifa_head; NULL != ifa; ifa = ifa->ifa_next) {
			if (0 == strcmp(ifa->ifa_name, net->net_iface))
				get_net_addr(net, ifa->ifa_addr, 0);
		}
	}
#endif /* AF_INET6 || AF_LINK || AF_PACKET */

	freeifaddrs(ifa_head);
}


/*===========================================*/
/* Get network info by using SIOCGIFCONF     */
/* (getifaddrs is preferred, if we have it.) */
/*===========================================*/
#elif defined(SIOCGIFCONF)
static struct ifconf *get_ifconf(void) {
	struct ifconf *ifc = calloc(1, sizeof(struct ifconf));
	size_t len;

#ifdef SIOCGSIZIFCONF
	len = 0;
	if (ioctl(hRemote, SIOCGSIZIFCONF, &len) >= 0 && len > 0) {
		++len;
	} else {
		len = (sizeof(struct ifreq) + 1) << 3;
	}
#else
	len = (sizeof(struct ifreq) + 1) << 3;
#endif /* SIOCGSIZIFCONF */

	if (NULL == ( ifc->ifc_req = malloc(len) )) {
		free(ifc);
		return NULL;
	}

	while (1) {
		ifc->ifc_len = len;
		BFTRACE("ioctl SIOCGIFCONF");
		if (ioctl(hRemote, SIOCGIFCONF, ifc) < 0) {
			BFTRACE("ioctl SIOCGIFCONF failed");
			free(ifc->ifc_req);
			free(ifc);
			return NULL;
		}
		if (ifc->ifc_len < len)
			break;
		len <<= 1;
		ifc->ifc_req = realloc(ifc->ifc_req, len);
		if (NULL == ifc->ifc_req) {
			free(ifc);
			return NULL;
		}
	}

	if (ifc->ifc_len > 0) {
		ifc->ifc_req = realloc(ifc->ifc_req, ifc->ifc_len);
		if (NULL == ifc->ifc_req) {
			free(ifc);
			return NULL;
		}
	}

	return ifc;
}



static void get_net_details_ifconf(
		platform_sysconf_net_t *net,
		const struct sockaddr *saddr,
		socklen_t sa_len)
{
	const char *cp, *cp_end;
	struct ifconf *ifc;
	struct ifreq *ifr;

	if (NULL == ( ifc = get_ifconf() ))
		return;

	/* First pass: find the matching interface name */
	if (NULL == net->net_iface) {
		cp = (const void *)ifc->ifc_req;
		cp_end = &cp[ifc->ifc_len];
		while (cp < cp_end) {
			ifr = (struct ifreq *)cp;
			if (is_same_addr(saddr, &ifr->ifr_addr)) {
				BFTRACE("interface <- ioctl SIOCGIFCONF");
				net->net_iface = strdup(ifr->ifr_name);
				break;
			}
			cp += sizeof(ifr->ifr_name) + BF_SA_LEN(&ifr->ifr_addr);
		}
		cp = (const void *)ifc->ifc_req;
	}

#if defined(AF_INET6) || defined(AF_LINK) || defined(AF_PACKET)
	/* Second pass: find other addresses */
	if (NULL != net->net_iface) {
		cp = (const void *)ifc->ifc_req;
		cp_end = &cp[ifc->ifc_len];
		while (cp < cp_end) {
			ifr = (struct ifreq *)cp;
			get_net_addr(net, &ifr->ifr_addr, 0);
			cp += sizeof(ifr->ifr_name) + BF_SA_LEN(&ifr->ifr_addr);
		}
	}
#endif /* AF_INET6 || AF_LINK || AF_PACKET */

	free(ifc->ifc_req);
	free(ifc);
	return;
}

#endif /* HAVE_GETIFADDRS / SIOCGIFCONF / misc ioctls */


/*
 * This is a last resort to try to get the MAC address from the interface
 * name if we have the latter and the appropriate SIOCGIFHWADDR ioctl is
 * available.
 */
#ifdef SIOCGIFHWADDR
static void get_net_details_hwaddr(
	platform_sysconf_net_t *net,
	const struct sockaddr *saddr,
	socklen_t sa_len)
{
	struct ifreq ifr;
	if (NULL == net->net_iface || '\0' != *net->net_hwaddr)
		return;
	strcpy(ifr.ifr_name, net->net_iface);
	BFTRACE("ioctl SIOCGIFHWADDR");
	if (ioctl(hRemote, SIOCGIFHWADDR, &ifr) >= 0) {
		BFTRACE("hwaddr <- ioctl SIOCGIFHWADDR");
		decode_hwaddr(
				net->net_hwaddr, 
				BF_HW_ADDRSTRLEN,
				(const unsigned char *)ifr.ifr_addr.sa_data,
				6);
		return;
	}
}
#endif /* SIOCGIFHWADDR */


platform_sysconf_net_t *platform_sysconf_net_new(void) {
	platform_sysconf_net_t *net;
	struct sockaddr_storage ss;
	struct sockaddr *sa = (struct sockaddr *)&ss;
	socklen_t sa_len = sizeof(ss);
	char *p = NULL;

	if (!platform_protocol_has_socket())
		return NULL;
	if (getsockname(hRemote, sa, &sa_len) < 0)
		return NULL;
	if (NULL == ( net = calloc(1, sizeof(*net)) ))
		return NULL;

	switch (sa->sa_family) {
		case AF_INET:
			net->net_ipv = 4;
			getnameinfo(sa, sa_len,
					p = net->net_ipv4, INET_ADDRSTRLEN,
					NULL, 0, NI_NUMERICHOST);
			break;

#ifdef AF_INET6
		case AF_INET6: {
			const struct in6_addr *in6 = BF_SA_TO_IPV6(sa);
			net->net_ipv = ( IN6_IS_ADDR_V4MAPPED(in6)
					|| IN6_IS_ADDR_V4COMPAT(in6) ) ? 4 : 6;
			getnameinfo(sa, sa_len,
					p = net->net_ipv6, INET6_ADDRSTRLEN,
					NULL, 0, NI_NUMERICHOST);
			break;
		}
#endif /* AF_INET6 */

		default:
			free(net);
			return NULL;
	}

	/* Maybe we got lucky and getnameinfo returned the interface name... */
	if (NULL != p && '\0' != *p) {
		p = strrchr(p, '%');
		if (NULL != p) {
			*p++ = '\0';
			if ('\0' != *p) {
				BFTRACE("interface <- getnameinfo");
				if (NULL != net->net_iface)
					free(net->net_iface);
				net->net_iface = strdup(p);
			}
		}
	}

	/* Get the Fully Qualified Domain Name of this machine. */
	net->net_fqdn = malloc(NI_MAXHOST);
	if (NULL != net->net_fqdn) {
		if (0 != getnameinfo(sa, sa_len,
				net->net_fqdn, NI_MAXHOST,
				NULL, 0, 0))
		{
			BFTRACE("fqdn: getnameinfo failed");
			free(net->net_fqdn);
			net->net_fqdn = NULL;
		} else {
			BFTRACE("fqdn <- getnameinfo");
		}
	}

	/*
	 * Finally, try several crazy tricks to find a matching interface
	 * and its accompanying alternate address.  Unfortunately, there
	 * is no clean way to do this ...
	 */

#ifdef WIN32
	/* On Windows, GetBestInterfaceEx should give us what we want. */
	if (platform_level_xp()) {
		get_net_details_gbi(net, sa, sa_len);
	}
#endif /* WIN32 */

#ifdef HAVE_GETIFADDRS
	/* If we have getifaddrs, as is normally the case for Linux,
	 * Mac OS/X, and *BSD, then we can brute force through the
	 * interface list to try to find a matching interface.
	 */
	get_net_details_ifaddrs(net, sa, sa_len);

#elif defined(SIOCGIFCONF)
	/* If we have the SIOCGIFCONF ioctl, we can try brute forcing our
	 * way through that.  Unfortunately, it probably won't have IPv6.
	 * The getifaddrs function is much better, so we don't bother
	 * trying this if getifaddrs is there.
	 */
	get_net_details_ifconf(net, sa, sa_len);
#endif /* HAVE_GETIFADDRS / SIOCGIFCONF */


#ifdef SIOCGIFHWADDR
	/* If we still don't have a MAC address, this might get it for
	 * us.  It needs the interface name, though.
	 */
	get_net_details_hwaddr(net, sa, sa_len);
#endif /* SIOCGIFHWADDR */
	return net;
}

