/*
 * Copyright (C)2003-2008, IBM, Inc. All rights reserved.
 * IBM, Inc. owns the copyright and other intellectual
 * property rights in this software. Duplication or use of the
 * Software is not permitted except as expressly provided in a
 * written agreement between your company and IBM, Inc.
 */

#ifdef WIN32
/*================================================================
 * Windows Implementation
 *----------------------------------------------------------------*/
platform_sysconf_os_t *platform_sysconf_os_new(void)
{
	char buf[32];
	platform_sysconf_os_t *os;

	if (NULL != ( os = calloc(1, sizeof(*os)) )) {
		os->os_machine = strdup("x86");
		os->os_sysname = strdup(platform_id());
		sprintf(buf, "%ld", osvi.dwMajorVersion);
		os->os_release = strdup(buf);
		sprintf(buf, "%ld", osvi.dwMinorVersion);
		os->os_version = strdup(buf);
		os->os_win_service_pack = (int)osvi.wServicePackMajor;
	}
	return os;
}


#else /* !WIN32 */
/*================================================================
 * UNIX Implementation
 *----------------------------------------------------------------*/
platform_sysconf_os_t *platform_sysconf_os_new(void) {
#ifdef HAVE_SYS_UTSNAME_H
	platform_sysconf_os_t *os = calloc(1, sizeof(platform_sysconf_os_t));
	if (NULL != os) {
		struct utsname ut;

		BFTRACE("uname");
		if (uname(&ut) < 0) {
			free(os);
			return NULL;
		}
		os->os_sysname = strdup(ut.sysname);
		os->os_release = strdup(ut.release);
		os->os_version = strdup(ut.version);
		os->os_machine = strdup(ut.machine);
#ifdef HAVE_GETHOSTID
		os->os_hostid = malloc(2 * sizeof(long) + 1);
		sprintf(os->os_hostid, "%08lx", gethostid());
#endif /* HAVE_GETHOSTID */
	}
	return os;
#else /* !HAVE_SYS_UTSNAME_H */
	return NULL;
#endif /* HAVE_SYS_UTSNAME_H/! */
}

#endif /* WIN32/! */

