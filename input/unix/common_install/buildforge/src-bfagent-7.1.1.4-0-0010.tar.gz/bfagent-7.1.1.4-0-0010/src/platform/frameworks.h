/*
 * Copyright (C)2007-2008, IBM, Inc. All rights reserved.
 * IBM, Inc. owns the copyright and other intellectual
 * property rights in this software. Duplication or use of the
 * Software is not permitted except as expressly provided in a
 * written agreement between your company and IBM, Inc.
 */

#ifndef PLATFORM_FRAMEWORKS_H
#define PLATFORM_FRAMEWORKS_H

#if defined(HAVE_FRAMEWORK_CF) && defined(HAVE_FRAMEWORK_IOKIT)
#define HAVE_FRAMEWORKS
#include <CoreFoundation/CoreFoundation.h>
#include <IOKit/IOKitLib.h>
#endif /* HAVE_FRAMEWORK_CF && HAVE_FRAMEWORK_IOKIT */

#endif /* PLATFORM_FRAMEWORKS_H */
