/*
Copyright (C)2005-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"

/*
 *
 * function to start clearcase views when _CLEARCASE_VIEWS is set
 * returns an alloc'd buffer that contains a valid pathname for 
 * the first view started.
 *
 */
static char *first_cc_view = NULL;
char *CCStartViews(int timeout) {
	char *sptr = NULL;
	char *rptr = NULL;
	char *cmd = NULL;
	char *view;
	int timeout_result, rc;
	size_t cmdlen = 0;
	char *viewlist = platform_getenv("_CLEARCASE_VIEWS");

	if (NULL == viewlist) { return NULL; }
	if (NULL != first_cc_view) {
		free(first_cc_view);
		first_cc_view = NULL;
	}
	sptr = rptr = NULL;

	/* we'll build a list of things to do in the cmd buffer and feed it
	 * to platform_spawn() ...
	 */
	cmd = calloc(1, BFBUFSIZ);
	rc = BFBUFSIZ;

	view = bf_strtok(viewlist, ";:,", &rptr, &sptr);
	while (view) {
		/* if the buffer isn't big enough (that's a LOT of views!) grow it */
		if ((size_t) rc < strlen(cmd) + (strlen(view) * 2) + 55) {
			rc += BFBUFSIZ;
			cmd = realloc(cmd, rc);
		}

		activity_write(BFHERE "CCASE cleartool startview %s", view);
		cmdlen += format_message(&cmd[cmdlen],
				"echo EXEC: cleartool startview %s\ncleartool startview %s\n",
				view, view);

		if (!first_cc_view) {
			const char *tv = this_view();
			size_t len = strlen(tv) + strlen(view) + 2;
			first_cc_view = calloc(1, len << 1);
			len = format_message(first_cc_view, "%s/%s", this_view(), view);
			CleanPath(first_cc_view);
			first_cc_view = realloc(first_cc_view, len + 1);
			send_msg("EXEC", "CCStartViewPath", "s",
					first_cc_view);
		}
		view = bf_strtok(NULL, ";:,", &rptr, &sptr);
	}
	bf_strtok(NULL, NULL, NULL, &sptr);

	/* the command input script has been generated, go run it! */
	if ('\0' != *cmd) {
		rc = platform_spawn(
				".", cmd, timeout,
				NULL, NULL, 0,
				&timeout_result, 0);
	}

	free(cmd);

	/* free the original env pointer if necessary */
	platform_freeenv(viewlist);
	return first_cc_view;
}

/*
 *
 * function to mount clearcase vobs when _CLEARCASE_VOBS is set
 *
 */
int CCMountVobs(int timeout) {
	char	*voblist, *vob, *sptr, *rptr, *cmd, *sbuf;
	int 	rc, timeout_result;
	struct stat	sb;

	if (NULL == (voblist = platform_getenv("_CLEARCASE_VOBS")))
		return -1;

	sptr = rptr = NULL;
	vob = bf_strtok(voblist, ";:,", &rptr, &sptr);
	cmd = calloc(1, BFBUFSIZ);
	sbuf = calloc(1, BFBUFSIZ);
	rc = BFBUFSIZ;

	while (vob) {
		/* if the buffer isn't big enough (that's a LOT of vobs!) grow it */
		if ((size_t)rc < strlen(cmd) + (strlen(vob) * 2) + 55) {
			rc += BFBUFSIZ;
			cmd = realloc(cmd, rc);
		}

		if (first_cc_view) {
			format_message(sbuf, "%s/%s/%s", this_view(), first_cc_view, vob);
			CleanPath(sbuf);
		}
		if (!first_cc_view || stat(sbuf, &sb) != 0) {
			/* mount the vob identified by 'vob' */
			activity_write(BFHERE "CCASE cleartool mount %s", vob);
			format_message(&cmd[strlen(cmd)],
					"echo EXEC: cleartool mount %s\ncleartool mount %s\n",
					vob, vob);
		}
		vob = bf_strtok(NULL, ";:,", &rptr, &sptr);
	}
	bf_strtok(NULL, NULL, NULL, &sptr);
	free(sbuf);

	/* the command input script has been generated, go run it! */
	if (*cmd != '\0')
		rc = platform_spawn(
				".", cmd, timeout,
				NULL, NULL, 0,
				&timeout_result, 0);

	/* free the original env pointer if necessary */
	free(cmd);
	platform_freeenv(voblist);
	return rc;
}
