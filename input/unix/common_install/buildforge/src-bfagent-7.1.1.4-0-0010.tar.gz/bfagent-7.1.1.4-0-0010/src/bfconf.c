/*
Copyright (C)2007-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#define BFCONF_C
#include "bf_agent.h"

static hash_ctx *ctx = NULL;
static hash_table *ht = NULL;

static char *bfconf_file = NULL;
static int bfconf_errno = 0;

static const char *magic_login = "magic_login";
static const char *update_path = "update_path";
static const char *password_prop = "_password";
static const char *locator_prop = "_locator";

extern int agent_re_exec;

bfconf_data_t bfconf_data;

void bfconf_refresh(void) {
	FILE    *f;
	char    *buf, *key, *value;
	char    *bf_rptr=NULL;
	char    *bf_sptr=NULL;
	int 	i;

	/* Start with a clean slate */
	hash_clear(ht);
	bfconf_errno = 0;

	f = platform_fopen(bfconf_get_path(), "r");
	if (f == NULL) {
		bfconf_errno = errno;
		return;
	}
	buf = malloc(BFBUFSIZ);

	while (platform_fgets(buf, BFBUFSIZ, f) != NULL) {
		bf_strtok(NULL, NULL, NULL, &bf_sptr);
		if (NULL != (key = bf_strtok(buf, " \t\r\n", &bf_rptr, &bf_sptr))) {
			if (*key == '\0' || *key == '#') continue;
			LowerString(key);
			i = strlen(key) + 1;	/* include the null in the key */
			if (hash_contains_key(ht, key, i)) continue;
			value = bf_strtok(NULL, "\t\r\n", &bf_rptr, &bf_sptr);
			hash_put(ht, strdup(key), i, strdup(value == NULL ? "" : value));
		}
	}

	bf_strtok(NULL, NULL, NULL, &bf_sptr);
	free(buf);
	fclose(f);

#undef REFRESH_EXISTS
#define REFRESH_EXISTS(x) bfconf_data.x = hash_contains_key_str(ht, #x)
	REFRESH_EXISTS(activity_log);
	REFRESH_EXISTS(cc_suppress_server_root);
	REFRESH_EXISTS(cygwin);
	REFRESH_EXISTS(disable_cleanup_during_exit);
	REFRESH_EXISTS(disable_telnet_support);
	REFRESH_EXISTS(disable_transcode);
	REFRESH_EXISTS(enable_agent_dll);
	REFRESH_EXISTS(enable_deprecated_path_mapping);
	REFRESH_EXISTS(fail_if_dot_source_fails);
	REFRESH_EXISTS(fail_if_log_file_fails);
	REFRESH_EXISTS(getaddrinfo_use_addrconfig);
	REFRESH_EXISTS(ignore_clearcase_view);
	REFRESH_EXISTS(leave_tmp_file);
	REFRESH_EXISTS(map_drive_is_failure);
	REFRESH_EXISTS(nologonshell);
	REFRESH_EXISTS(no_preparse_command);
	REFRESH_EXISTS(no_pty);
	REFRESH_EXISTS(shell_compatible_undef_vars);
	REFRESH_EXISTS(shellarg);
	REFRESH_EXISTS(win_reexec_after_auth);
	REFRESH_EXISTS(password_encrypt_module);
	REFRESH_EXISTS(password_encrypt_config);
#ifdef WIN32
	if (agent_re_exec)
		bfconf_data.disable_transcode = 1;
#endif
}

static void bfconf_init(void) {
	if (ctx == NULL) {
		ctx = hash_ctx_new();
		ht = hash_new(ctx, 89);
		memset(&bfconf_data, '\0', sizeof(bfconf_data));
	} else {
		/* Free any strings */
	}
	bfconf_refresh();
}


void bfconf_set_path(const char *path) {
	if (NULL != bfconf_file)
		free(bfconf_file);
	bfconf_file = NULL != path ? strdup(path) : platform_default_config_file();
	bfconf_init();
}

const char *bfconf_get_path(void) {
	if (NULL == bfconf_file)
		bfconf_set_path(NULL);
	return bfconf_file;
}

int bfconf_get_errno(void) {
	return bfconf_errno;
}

char *bfconf_get(const char *key, const char *def) {
	const char *value;

	if (ctx == NULL) bfconf_init();
	value = hash_get_str(ht, key);
	if (value == NULL) value = def;
	return value == NULL ? NULL : strdup(value);
}

int bfconf_exists(const char *key) {
	if (ctx == NULL) bfconf_init();
	return hash_contains_key_str(ht, key);
}

int FuncDumpConf(void)
{
	const char *key, *value;
	char *buf = malloc(BFBUFSIZ);
	hash_iter *hi;
	int debug = request_has(TAG_DEBUG);
	int len;

	ClobberPasswords();

	if (ctx == NULL) bfconf_init();
	if (bfconf_errno != 0) {
		bfconf_refresh();
		if (bfconf_errno != 0) {
			send_msg("EXEC", "ConfFail", "si",
					bfconf_file, bfconf_errno);
			return 1;
		}
	}

	/* In debug mode, dump the settings.  The magic_login value
	 * is suppressed for security reasons, and the update_path
	 * setting is suppressed entirely so it can be reported last.
	 */
	if (debug) {
		hi = hash_iter_new(ht);
		while (hash_iter_next(hi)) {
			key = hi->entry->key;
			value = hi->entry->value;

			if (0 == strcmp(key, magic_login)) { value = "*****"; }
			if (NULL != strstr(key, password_prop) && NULL == strstr(key, locator_prop)) { value = "*****"; }
			else if (0 == strcmp(key, update_path)) { continue; }
			else if (value == NULL) { value = ""; }

			len = strlen(key);
			memcpy(buf, key, len);
			buf[len++] = '=';
			strcpy(&buf[len], value);
			send_log("CONF", buf);
		}
		hash_iter_destroy(hi);
	}

	/* Provide the update_path setting. */
	value = platform_update_path();
	format_message(buf, "%s=%s", update_path, value);
	send_log("CONF", buf);
	free(buf);

	send_msg("EXEC", "ShowDone", NULL);
	return 0;
}

