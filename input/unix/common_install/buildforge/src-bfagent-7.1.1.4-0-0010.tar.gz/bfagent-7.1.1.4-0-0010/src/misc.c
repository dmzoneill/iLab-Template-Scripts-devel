/*
Copyright (C)2003-2008, IBM, Inc. All rights reserved. 
IBM, Inc. owns the copyright and other intellectual 
property rights in this software. Duplication or use of the 
Software is not permitted except as expressly provided in a 
written agreement between your company and IBM, Inc.
*/

#include "bf_agent.h"
#include <fcntl.h>
#include "md5.h"

#ifdef WIN32
#include <direct.h>
#endif

extern FILE *log_file;
FILE *activity_file = NULL;

#ifndef WIN32
extern int     errno;
#endif

/*
 * function to close an open logfile
 */
void log_close(void)
{
	if (log_file) { fclose(log_file); }
	log_file = NULL;
}

/*
 * function to open a log file if one is specified in a request
 *
 * Return value: non-zero for failure, 0 for success (or not logging)
 */
int log_open(void)
{
	char *file, *s;
	int err = 0;

	log_close();
	file = platform_getenv("BF_LOG");
	if (NULL == file) { file = platform_getenv("_LOG"); }
	if (NULL == file || '\0' == *file) { return 0; }

	CleanPath(file);
	if (*file != PathSeparator() && file[1] != ':') {
		s = malloc(BFBUFSIZ);
		platform_getcwd(s, BFBUFSIZ);
		sprintf(&s[strlen(s)], "%c%s", PathSeparator(), file);
		platform_freeenv(file);
		file = s;
	} else {
		s = strdup(file);
		platform_freeenv(file);
		file = s;
	}
	CleanPath(file);

	log_file = platform_fopen(file, "a");
	if (NULL != log_file) {
		setbuf(log_file, NULL);
		send_msg("LOG", "LogPath", "s", file);
	} else {
		err = errno;
		send_msg("LOG", "LogPathFail", "s", file);
	}
	free(file);
	return err;
}

/*
 * function to log a data block when logging is enabled
 */
void log_write(const char *msg)
{
	char	*s;

	if (msg) {
		s = strdup(msg);
		RemoveTrailingNewline(s);
		if (NULL != log_file) { fprintf(log_file, "%s\n", s); }
		free(s);
	}
}

int BFCreateDirectory(char *root, char *dir, int mode)
{
	CleanPath(root);
	errno = 0;
	if (platform_chdir(root) != 0) {
		send_msg("MKDIR", "ChdirFail", "si", root, errno);
		return -1;
	}
	return BFCreateDirectoryRelative(dir, mode);
}

int BFCreateDirectoryRelative(char *dir, int mode)
{
	char    *buf, *p, *usedir, *root;
	char    *bf_rptr=NULL;
	char    *bf_sptr=NULL;
	wchar_t *tmpbuf;

	if (mode == 0)
		mode = 0755;
	root = calloc(sizeof(*root), BFBUFSIZ);
	buf = calloc(sizeof(*buf), BFBUFSIZ);
	tmpbuf = calloc(sizeof(*tmpbuf), BFBUFSIZ);

	platform_getcwd(root, BFBUFSIZ);
	CleanUnixPath(root);
	strcpy(buf, root);
	usedir = strdup(dir);
	CleanUnixPath(usedir);
	p = bf_strtok(usedir, "/", &bf_rptr, &bf_sptr);
	while (p) {
		strcat(buf, "/");
		strcat(buf, p);
		if (!isDir(buf) && platform_mkdir(buf, mode) != 0)
			break;
		p = bf_strtok(NULL, "/", &bf_rptr, &bf_sptr);
	}
	bf_strtok(NULL, NULL, NULL, &bf_sptr);
	free(usedir);
	free(root);
	free(tmpbuf);
	if (isDir(buf)) {
		free(buf);
		return 0;
	}
	free(buf);
	return -1;
}

/* 
 *  function to test a pathname to see if it's a directory. 
 *  doesn't alter path at all. 
 */
#ifndef S_ISDIR
#define S_ISDIR(x)	((x & S_IFDIR) == S_IFDIR)
#endif
int isDir(const char *path)
{
	struct 	stat sb;
	return (platform_stat(path, &sb) == 0 && S_ISDIR(sb.st_mode)) ? 1 : 0;
}

/* 
 *  function to test a pathname to see if it's a regular file. 
 *  doesn't alter path at all. 
 */
#ifndef S_ISREG
#define S_ISREG(x)	((x & S_IFREG) == S_IFREG)
#endif
int isFile(const char *path)
{
	struct 	stat sb;
	return (platform_stat(path, &sb) == 0 && S_ISREG(sb.st_mode)) ? 1 : 0;
}

static const char *hex_code = "0123456789ABCDEF0123456789abcdef";
int hex_encode(char *buf, const uint8_t *src, int bytes) {
	unsigned char *p = (unsigned char *)buf;
	int i;

	for (i=0; i<bytes; ++i) {
		*p++ = hex_code[(*src >> 4) & 0x0F];
		*p++ = hex_code[*src++ & 0x0F];
	}
	*p = '\0';
	return (int)(p - (unsigned char *)buf);
}


int hex_decode(uint8_t *result, const char *src) {
	unsigned int x;
	int i=0;

	while ('\0' != *src && '\0' != src[1]) {
		result[i] = (1 == sscanf(src, "%2x", &x))
				? (unsigned char)x
				: (unsigned char)'?';
		++i;
		src = &src[2];
	}

	return i;
}



void cleanMyCruft(char *path) {
	if (path) {
		if (BFCONF_EXISTS(leave_tmp_file)) {
			send_msg("EXEC", "LeavingTemp", "s", path);
		} else {
			platform_unlink(path);
		}
	}
}


void StoreUserData(char *data, size_t bytes) {
	char *e;
	FILE *f;

	if (data && NULL != (e = platform_getenv("_USERDATA"))) {
		if (NULL != (f = platform_fopen(e, "w"))) {
			fwrite(data, 1, bytes, f);
			fclose(f);
		}
		platform_freeenv(e);
	}
}

void FreeUserData(void) {
	char *e;

	if (NULL != (e = platform_getenv("_USERDATA"))) {
		platform_unlink(e);
		platform_freeenv(e);
	}
}



/* The magic_login is intended to increase the security of the agent.
 * Its behavior depends on the agent configuration, as follows:
 *
 * Running as root (Unix) or a member of the Administrators group (Windows):
 * - magic_login is ignored
 * - user must provide valid login credentials
 *
 * Running as an ordinary user:
 * - The credentials must match the magic login
 * - If no magic login is defined, then the credentials must be left blank
 *
 * Return value:
 * 		SU_OK           = Success
 * 		SU_OK_NOACCOUNT = Not applicable (no magic_login defined)
 * 		SU_ILLEGAL      = Denied - no login specified
 * 		SU_UNKNOWNUSER  = Denied - username or password mismatch
 */
int auth_magic = 0;
int check_magic_login(const char *username, const char *password) {
	char *p;
	char *magic_login = NULL;
	int ret = SU_UNKNOWNUSER;

	magic_login = bfconf_get("magic_login", NULL);
	if (NULL == magic_login) {
		BFTRACE("AUTH user mode (Insecure!)");
		return SU_OK_NOACCOUNT;
	}
	if (username == NULL || *username == '\0'
			|| password == NULL || *password == '\0')
	{
		BFTRACE("AUTH failed (magic login required)");
		free(magic_login);
		return SU_ILLEGAL;
	}

	p = strrchr(magic_login, ':');
	if (p != NULL) *p++ = '\0';

	if (strcmp(username, magic_login) == 0) {
		size_t len = strlen(password);
#ifdef ZOS
		char *pass = strdup(password);
		convert_etoa_l(pass, len);
		password = pass;
#endif
		if (smd5_check(p, (const md5_byte_t *)password, len) == 0) {
			auth_magic = 1;
			ret = SU_OK;
		}
#ifdef ZOS
		free(pass);
#endif
	}

	free(magic_login);
	return ret;
}


void activity_open(void) {
	char *activity_log = bfconf_get("activity_log", NULL);
	activity_close();
	if (NULL != activity_log) {
		activity_file = platform_fopen(activity_log, "a+");
		free(activity_log);
	} else if (agent_debug_flag) {
		int fd = dup(2);
		activity_file = fdopen(fd, "a+");
	}
}

static const char NL = '\n';
void activity_write(const char *file, int line, const char *fmt, ...) {
	const char *p;
	va_list va;
	size_t len;

	if (!bf_debug && NULL == activity_file) { return; }
	while (NULL != ( p = strpbrk(file, "/\\") )) { file = ++p; }

	va_start(va, fmt);
	if (bf_debug) {
		len = sprintf(bf_debug, BFTRACE_FORMAT, (int)getpid(), file, line);
		len += vsprintf(&bf_debug[len], fmt, va);
		send_debug(bf_debug);
		if (NULL != activity_file) {
			bf_debug[len++] = '\n';
			fwrite(bf_debug, 1, len, activity_file);
			fflush(activity_file);
		}
	} else if (NULL != activity_file) {
		fprintf(activity_file, BFTRACE_FORMAT, (int)getpid(), file, line);
		vfprintf(activity_file, fmt, va);
		fwrite(&NL, 1, 1, activity_file);
		fflush(activity_file);
	}
	va_end(va);
}

void activity_close(void) {
	if (NULL != activity_file) {
		fclose(activity_file);
		activity_file = NULL;
	}
}

